##' Calculates utilization density estimates and home ranges
##' from bighorn sheep telemetry points.
##'
##' \tabular{ll}{
##' Package:  \tab BHSkde\cr
##' Type:     \tab Package\cr
##' Version:  \tab 1.13\cr
##' Date:     \tab 2016-01-26\cr
##' License:  \tab GPL (>= 2)\cr
##' LazyLoad: \tab yes\cr
##' }
##'
##' Using the R package \pkg{ks}, \pkg{BHSkde} estimates kernel
##' smooothing parameters utilization distributions, and isopleths, in
##' order to estimate the extent of Core Herd Home Ranges
##'
##' \code{\link{kdeAllAnimals}} selects bandwidths and calculates
##' kernel density estimates for one or more bighorn sheep in a single
##' herd.
##'
##' @name BHSkde-package
##' @aliases BHSkde
##' @docType package
##' @title Calculates bighorn sheep Core Herd Home Ranges.
##' @author Josh O'Brien \email{joshmobrien@@gmail.com}
##' @keywords package
##' @import sp
##' @import rgeos
NULL


##' @importFrom ks Hpi kde
NULL
