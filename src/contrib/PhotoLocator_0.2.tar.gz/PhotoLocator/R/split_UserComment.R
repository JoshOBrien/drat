split_UserComment <- function(x) {
    x <- stri_replace_all_regex(x,
                                c("PROJECT NAME: ", "WATERMARK:.*"),
                                c("", ""),
                                vectorize_all = FALSE)
    x <- stri_split_fixed(x, pattern = " DESCRIPTION: ")
    x <- data.frame(do.call(rbind, x), stringsAsFactors = FALSE)[1:2]
    names(x) <- c("ProjectName", "Description")
    x
}
