ui <- fluidPage(
  useShinyjs(),    ## for shinyjs (e.g. hidden())
  titlePanel(h1("PhotoLocator", align = "center")),

  verticalLayout(
    ## Select files to be processed
    mainPanel(
      id = "fileSelection",
      div("1: ",
          shinyFilesButton(
            id = "file_selection",
            label = "Select photo files",
            title = "Please select one or more files",
            multiple = TRUE),
          style = "font-size:30px;"),
      tags$hr()
    ),

    ## Select path to output file
    hidden(mainPanel(
      id = "outfileSelection",
      div("2: ",
          shinySaveButton("save", "Name output file",
                          "Save file as ...",
                          filename = "PhotoCoordinates",
                          filetype = list(csv = "csv")),
          style = "font-size:30px;")
    )),

    ## Display processing button
    hidden(mainPanel(
      id = "coordinateExtraction",
      br(),
      verbatimTextOutput("outfile_path"),
      hr(),
      div("3: ",
          actionButton("do_extract", "Extract photo coordinates"),
          style = "font-size:30px;")
    )),

    ## Display of selected files
    hidden(mainPanel(
      id = "selectedFileDisplay",
      hr(),
      br(),
      br(),
      tags$h4("Files with coordinates to be extracted:"),
      verbatimTextOutput("imagefile_paths")
    ))

  )
)



## // Local Variables:
## // ess-indent-offset: 2
## // End:
