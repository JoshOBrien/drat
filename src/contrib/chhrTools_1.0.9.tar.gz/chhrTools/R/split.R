##' Split sf POINTS object into n parts
##'
##' @title  Split sf POINTS object into n parts
##' @param sf An sf POINTS object
##' @param n An integer giving the number of splits to make
##' @return A list of \code{n} smaller POINTS objects
##' @export
##' @author Joshua O'Brien
split_sf_n <- function(sf, n) {
    ii <- sort(rep(seq_len(n), length.out = nrow(sf)))
    lapply(seq_len(n), function(i) slice(sf, which(ii == i)))
}


##' Split sf POINTS object into two subsets of given size
##'
##' @title Split sf POINTS object into two subsets
##' @param sf An sf POINTS object
##' @param p A number between 0 and 1, giving the proportion of points
##'     in the first partition of points
##' @return A list of two POINTS objects
##' @export
##' @author Joshua O'Brien
split_sf_p <- function(sf, p = 0.5) {
    n <- nrow(sf)
    i <- floor(p*n)
    sf_1 <- sf[seq(1, i, by = 1), ]
    sf_2 <- sf[seq(i+1, n, by = 1), ]
    list(sf_1, sf_2)
}
