##' Convert sf object to an amt package track object
##'
##' @title Convert an sf object to an amt package track object
##' @param sf An \pkg{sf} \code{MULTIPOINTS} object of class \code{sf}.
##' @param x Character, indicating column with x-coordinate.
##' @param y Character, indicating column with y-coordinate.
##' @param t Character, indicating column with timestamp.
##' @return An object of class \code{track}, as defined in the
##'     \pkg{amt} package.
##' @importFrom spatialToolsJOB sf_to_df
##' @export
##' @author Joshua O'Brien
sf_to_track <- function (sf, x = "X", y = "Y", t = "dtime")
{
    muffle <- function(X) suppressWarnings(suppressMessages(X))
    sf <- sf[order(sf[[t]]), ] ## Ensure the obs are in time order
    muffle(myCRS <- crs(as(sf, "Spatial")))
    df <- sf_to_df(sf)
    muffle(make_track(df, .x = x, .y = y, .t = t, crs = myCRS))
}


##' Compute kLoCoH polygon from an sf MULTIPOINTS object
##'
##' @title Compute kLoCoH Polygon From an sf MULTIPOINTS Object
##' @param X An \pkg{sf} \code{MULTIPOINTS} object that can be
##'     converted to a \code{track} object by \code{sf_to_track()}
##' @param n Passed on to \code{n} in \code{hr_locoh()}. Default value
##'     is 10.
##' @param levels Vector of numbers between 0 and 1 specifying
##'     isopleth(s) of contour to be drawn. Default value is 0.95.
##' @return An \pkg{sf} \code{MULTIPOLYGON} object.
##' @importFrom tlocoh xyt.lxy lxy.nn.add lxy.lhs lhs.iso.add
##'     isopleths
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
KLOCOH <- function(X, n = 10, levels = 0.95) {
    XY <- st_coordinates(X)
    p4s <- CRS(proj4string(as(X, "Spatial")))
    lxy <- xyt.lxy(XY, id = "ID_1", proj4string = p4s)
    ## Compute local hulls (here using 10 nearest pts)
    hh <- lxy.lhs(lxy.nn.add(lxy, k = n), k = n)
    ## Add (at least two) isopleths, & convert 95% isopleth to sf object
    HH <-  lhs.iso.add(hh, iso.levels = c(0.0, levels))
    ISO <- st_as_sf(isopleths(HH)[[1]])[-1,]
    ISO <- st_sf(level = levels, st_geometry(ISO))
    ISO <- st_transform(ISO, st_crs(X))
    ISO
}

## ## Former implementation, abandoned because hr_locoh() isn't working
## ## correctly
## KLOCOH <- function(X, n = 10, levels = 0.95) {
##     track <- sf_to_track(X)
##     XX <- hr_locoh(track, n = n, levels = levels)
##     XX <- XX$locoh["level"]
##     suppressWarnings(st_crs(XX) <- st_crs(X))
##     XX
## }


##' Compute minimum convex polygon from an sf MULTIPOINTS object
##'
##' @title Compute Minimum Convex Polygon From an sf MULTIPOINTS
##'     Object.
##' @param X An \pkg{sf} \code{MULTIPOINTS} object that can be
##'     converted to a \code{track} object by \code{sf_to_track()}
##' @param levels Vector of numbers between 0 and 1 specifying
##'     isopleth(s) of contour to be drawn. Default value is 0.95.
##' @return An \pkg{sf} \code{MULTIPOLYGON} object.
##' @export
##' @author Joshua O'Brien
MCP <- function(X, levels = 0.95) {
    track <- sf_to_track(X)
    XX <- hr_mcp(track, levels = levels, keep.data = FALSE)
    XX <- XX$mcp["level"]
    suppressWarnings(st_crs(XX) <- st_crs(X))
    XX
}
