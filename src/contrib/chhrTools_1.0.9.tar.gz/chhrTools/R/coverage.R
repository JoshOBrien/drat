##------------------------------------------------------------------------------
## Compute coverages
##------------------------------------------------------------------------------

##' Given a \code{MULTIPOLYGONS} and a \code{POINTS} sf object,
##' compute the proportion of points contained with the polygon.
##'
##' @title Compute Coverage of a Set of Points by a Multipolygon
##' @param POL A \code{MULTIPOLYGONS} object.
##' @param PTS A \code{POINTS} object
##' @param digits The number of digits to which to round the returned
##'     value.
##' @return A number giving the proportion of points covered by the
##'     multipolygon.
##' @export
##' @author Joshua O'Brien
HR_coverage <- function(POL, PTS, digits=3) {
    suppressWarnings(st_crs(POL) <- st_crs(PTS))
    n_within <- sum(st_intersects(PTS, POL, sparse = FALSE))
    n_total <- nrow(PTS)
    round(n_within/n_total, digits)
}

##' Given a \code{data.table} and the names of list columns containing
##' \code{MULTIPOLYGONS} and \code{POINTS} objects, compute coverages
##' for each row.
##'
##' @title Compute Coverage Proportions for Columns of MULTIPOLYGONS
##'     and POINTS
##' @param X A \code{data.table}
##' @param POL A character string giving the name of a column of
##'     \code{MULTIPOLYGONS} objects.
##' @param PTS A character string giving the name of a column of
##'     \code{POINTS} objects.
##' @param digits The number of digits to which returned value will be
##'     rounded.
##' @return A numeric vector or proportions.
##' @export
##' @author Joshua O'Brien
HR_coverage_DT <- function(X = DT, POL = "IID_1", PTS = "PTS_2",
                           digits = 3) {
    cols <- c(POL, PTS)
    X <- setnames(X[, ..cols], c("POL", "PTS"))
    ii <- seq_len(nrow(X))
    X[, HR_coverage(dt_to_spatial(POL), dt_to_spatial(PTS),
                    digits = digits),
      by = ii][[2]]
}
