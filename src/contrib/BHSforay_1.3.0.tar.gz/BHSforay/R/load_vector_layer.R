load_vector_layer <- function(obj) {
    if (inherits(obj, "sf")) {
        return(obj)
    }
    if (is.character(obj)) {
        if (length(obj) == 1) {
            return(st_read(obj))
        }
        if (length(obj) == 2) {
            return(read_GDB(obj[1], obj[2]))
        }
    }
    stop("obj must be either an object of class 'sf' or a character vector",
         "giving the path to a shapefile or gdb directory and layer")
}
