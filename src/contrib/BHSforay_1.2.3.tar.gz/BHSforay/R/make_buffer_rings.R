##' \code{make_buffer_rings} creates \code{n} 1-km wide buffering
##' rings around a polygon, typically a CHHR.
##'
##' Setting \code{n = 2} will (for example) return a
##' \code{\link[sf:sf]{sf::sf()}} object consisting of \code{POLYGON}
##' or \code{MULTIPOLYGON} rings extending from 0 km to 1 km and from
##' 1 km to 2 km from its borders.
##' @title Make Rings Surrounding a CHHR
##' @param poly An \code{sf::sf()} object, typically representing a
##'     CHHR.
##' @param n The number of successive 1-km wide rings to return.
##' @return An \code{sf::sf()} object consisting of \code{n} rings
##'     around \code{poly}.
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
make_buffer_rings <- function (poly, n) {
    ## Make n+1 disks
    make_disk <- function(dist) {
        st_buffer(poly, dist, nQuadSegs = 100, endCapStyle = "ROUND")
    }
    DD <- lapply((seq(0, n) * 1000), make_disk)
    ## Make n rings
    make_ring <- function(i) {
        suppressWarnings(X <- st_difference(DD[[i + 1]], DD[[i]]))
    }
    RR <- lapply(seq_len(n), make_ring)
    ## Combine rings into a single sf object
    RR <- do.call(rbind, RR)
    st_sf(Ring = seq_len(n), geometry = st_geometry(RR))
}
