##' Use \code{\link[sf:st_read]{sf::st_read()}} and
##' \code{\link[gdalUtilities:ogr2ogr]{gdalUtilities::ogr2ogr()}} to
##' read polygon layers from a file geodatabase. Unlike using
##' \code{\link[sf:st_read]{sf::st_read()}} alone, this converts any
##' \code{POLYGON} and (more importantly) \code{MULTISURFACE} type
##' vector objects to \code{MULTIPOLYGON} type objects.
##'
##' @title Read polygon layer from a geodatabase as MULTIPOLYGON
##' @param dsn Path to a geodatabase `file' (a directory with
##'     extension \code{*.gdb}). Abbreviation stands for `data source
##'     name' as noted in help page for
##'     \code{\link[sf:st_read]{sf::st_read()}}, on which this
##'     function relies.
##' @param layer Character string giving name of layer to be
##'     selected. For behavior when \code{layer} is missing, see the
##'     \code{\link[sf:st_read]{sf::st_read()}} help page.
##' @param ... Additional arguments to be passed on to
##'     \code{\link[sf:st_read]{sf::st_read()}}.
##' @return
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
read_GDB <- function(dsn, layer, ...) {
    temp_dir <- tempdir()
    ## Avoid collisions between several gpkg files written to temp_dir
    chars <- c(sample(c(LETTERS, letters, 1:10), 10, replace = TRUE))
    temp_GPKG <- paste(c(chars, ".gpkg"), collapse="")
    temp_GPKG <- file.path(temp_dir, temp_GPKG)
    ## Convert GDB to GPKG
    ogr2ogr(dsn, temp_GPKG,
            layer = layer,
            f = "GPKG",
            nlt = "MULTIPOLYGON")
    # Read geodatabase layer for attributes
    x <- st_read(dsn = dsn, layer = layer)
    ## Read geopackage for the geometry
    y <- st_read(temp_GPKG)
    ## Combine GDB attributes with GPKG spatial column
    st_sf(st_drop_geometry(x), geom = st_geometry(y))
}
