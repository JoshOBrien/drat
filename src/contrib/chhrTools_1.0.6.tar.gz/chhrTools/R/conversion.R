

##' Convert sf object to telemetry object used by ctmm package
##'
##' @title Convert sf object to telemetry object used by ctmm package
##' @param X An sf object
##' @param id Character string giving name of id column
##' @param time Character string giving name of the time column
##' @param p4s PROJ.4 projection argument passed on to
##'     \code{as.telemetry()}'s \code{projection} and \code{datum}
##'     arguments.
##' @return A telemetry object of type used by ctmm package
##' @importFrom ctmm as.telemetry
##' @importFrom spTools sf_to_df
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' X <- head(spData::cycle_hire)
##' X$TIME <- Sys.time() + (1:6)*7200
##' X$id <- 33
##' X <- st_transform(X, 32630)
##' sf_to_telemetry(X, id = "id", time = "TIME")
##' sf_to_telemetry(X)
##' }
sf_to_telemetry <- function(X, id = NULL, time = NULL,
                            p4s = st_crs(X)$proj4string) {
    DF <- sf_to_df(X)
    if (is.null(id)) {
        id <- "id_"
        DF$id_ <- "animal"
    }
    if (is.null(time)) {
        time <- names(X)[sapply(X, inherits, "POSIXt")]
        if (length(time) != 1) {
              stop("Must specify time column")
        }
    }
    df <- data.frame(
        individual.local.identifier = DF[[id]],
        location.long = DF[["X"]],
        location.lat = DF[["Y"]],
        timestamp = DF[[time]])
    suppressWarnings(as.telemetry(df, datum = p4s, projection = p4s))
}
