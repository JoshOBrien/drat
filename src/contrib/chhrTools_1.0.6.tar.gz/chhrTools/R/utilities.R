
##' Useful for converting a single-row data.table of list columns
##' (whose elements need to be plucked out via \code{x[[1]][[1]]} or
##' \code{x[[1]]}) to a list.
##'
##' @title Extract SpatialObject Contained in Element of a data.table
##'     List Column.
##' @param x An spatial (\code{RasterLayer} or \code{sf}) object
##'     singly or doubly nested in a list. (See examples for a
##'     demonstration of how these objects arise when extracting
##'     elements from \code{data.table} list columns.)
##' @return An spatial object.
##' @export
##' @author Joshua O'Brien
##' @examples
##' ## Mechanics of constructing list columns
##' MC <- data.table(mtcars, keep.rownames = TRUE)
##' MC[, dummy := .(.(.(mpg, carb))), by=rn]
##' nc <- st_read(system.file("shape/nc.shp", package="sf"))
##' MC[, dummy_sf := .(.(nc)), by=rn]
##'
##' ## Difference between direct & indirect extraction
##'
##' ## Non-spatial example
##' x <- MC[1, dummy]
##' jj <- "dummy"
##' y <- MC[1, ..jj]
##' x[[1]]
##' y[[1]][[1]]
##'
##' ## Spatial example
##' x <- MC[1, dummy_sf]
##' jj <- "dummy_sf"
##' y <- MC[1, ..jj]
##' x[[1]]
##' y[[1]][[1]]
##' dt_to_spatial(x)
##' dt_to_spatial(y)
dt_to_spatial <- function(x) {
    spatial_classes <- c("sf", "RasterLayer")
    if(inherits(x, spatial_classes)) {
        return(x)
    } else {
        x_1 <- x[[1]]
    }
    if(inherits(x_1, spatial_classes)) {
        return(x_1)
    } else {
        x_2 <- x_1[[1]]
    }
    if(inherits(x_2, spatial_classes)) {
        return(x_2)
    } else {
        stop("Does 'x' really contain a spatial object?")
    }
}
