
## Among other places, the code comes from:
## C:/Josh/Projects/BHS/Other/2021-Foray-animations/helpers/helpers.R
##
## It was first saved as a box module in:
## C:/gitRepos/1-my-packages/box/spatial/BHS_animation.R

##' Create trajectories of line segments from sf POINTS objects,
##' treating each animal in the sf object separately. I save these
##' trajectories to a geopackage and use them to create animations with
##' QGIS and ffmpeg.
##'
##' @title Create trajectories for all animals in a herd
##' @param PTS An \pkg{sf} \code{POINTS} object, with attribute
##'     columns giving animal ID and time of each observation.
##' @param ID Name of column in \code{PTS} containing animal IDs.
##' @param time Name of column in \code{PTS} containing observation
##'     timestamps.
##' @return
##' @importFrom spTools st_points_to_segments
##' @importFrom sf st_as_sf
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
herd_trajectories <- function(PTS, ID = "sheepID", time = "dtime") {
    X <- data.table(PTS, key = c(ID, time))
    st_as_sf(X[, st_points_to_segments(st_as_sf(.SD)), by = ID])
}
