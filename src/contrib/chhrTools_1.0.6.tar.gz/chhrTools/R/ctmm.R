


ensure_telemetry <- function(X) {
    if (inherits(X, "telemetry")) {
        return(X)
    } else if (inherits(X, "sf")) {
        sheepID <- ifelse("sheepID" %in% names(X), "sheepID", "ndowid")
        X <- sf_to_telemetry(X, id = sheepID, time = "dtime")
        return(X)
    } else {
        stop("Telemetry data must provided in object of class 'sf' or 'telemetry'.")
    }
}


##------------------------------------------------------------------------------
## (1) Model fitting
##------------------------------------------------------------------------------

##' Wrapper for Fitting a ctmm Model
##'
##' @title Wrapper for Fitting a ctmm Model
##' @param telem Either a \code{"telemetry"} object or an \code{"sf"}
##'     \code{"MULTIPOINTS"} object that can be converted to a
##'     \code{"telemetry"} object.
##' @param method A character vector specifying the \pkg{ctmm}
##'     movement model used to fit the data. One of \code{"guess"},
##'     \code{"IID"} (independent and identically distributed),
##'     \code{"BM"} (Brownian motion), \code{"OU"}
##'     (Ornstein-Uhlenbeck), or \code{"OUF"} (Ornstein-Uhlenbeck with
##'     foraging). If \code{"guess"} (the default), the function
##'     \code{ctmm.guess()} is used to guess the best movement model.
##' @return A fitted movement model of class \code{"ctmm"}.
##' @export
##' @author Joshua O'Brien
CTMM <- function(telem, method = c("guess", "IID", "BM", "OU", "OUF")) {
    telem <- ensure_telemetry(telem)
    method <- match.arg(method)
    if (method == "guess") {
        m.guess <- ctmm.guess(telem, interactive = FALSE) ## automated model guess
        M <- ctmm.fit(telem, m.guess) ## 41 seconds
    } else if (method == "IID") {
        M <- ctmm.fit(telem)
    } else if (method == "BM") {
        M <- ctmm.fit(telem, CTMM = ctmm(tau = Inf))
    } else if (method == "OU") {
        M <- ctmm.fit(telem, CTMM = ctmm(tau = c(10 %#% "day")))
    } else if (method == "OUF") {
        M <- ctmm.fit(telem, CTMM = ctmm(tau = c(10 %#% "day", 1 %#% "hour")))
    }
    M
}


##------------------------------------------------------------------------------
## (2) Home range estimation
##------------------------------------------------------------------------------

##' Fit a UD to Telemetry Data
##'
##' @title Fit a UD to Telemetry Data
##' @inheritParams CTMM
##' @param model A fitted movement model of class \code{"ctmm"}.
##' @return A named list containing elements \code{"telem"} (a
##'     \code{"telemetry"} object), \code{"model"} (a \code{"ctmm"}
##'     object), and \code{"UD"}.
##' @export
##' @author Joshua O'Brien
AKDE <- function(telem,
                 model = NULL,
                 method = c("guess", "IID", "BM", "OU", "OUF")) {
    method <- match.arg(method)
    telem <- ensure_telemetry(telem)
    if (is.null(model)) {
        M <- CTMM(telem, method)
    } else {
        M <- model
    }
    UD <- akde(telem, M, weights = TRUE, debias = TRUE,
               grid = list(dr = c(100, 100), align.to.origin = TRUE))
    list(telem = telem, model = M, UD = UD)
}

##' Fit UD and CHHR to Telemetry Data, Returning sf and raster Objects
##'
##' @title Fit UD and CHHR to Telemetry Data, Returning sf and raster Objects
##' @inheritParams CTMM
##' @param model A fitted movement model of class \code{"ctmm"}.
##' @param UD Boolean. Should \code{RasterLayer} objects containing
##'     the fitted utilization distributions be returned? Default is
##'     \code{FALSE}.
##' @return A named list containing elements \code{"pts"},
##'     \code{"model"}, \code{"CHHR"}, and (optionally) \code{"UD"}
##'     and \code{"UD_CDF"}.  The spatial objects are of class
##'     \code{"sf"} or \code{"RasterLayer"}, while the \code{"model"}
##'     object is of class \code{"ctmm"}.
##' @export
##' @author Joshua O'Brien
AKDE_sf <- function(telem,
                    model = NULL,
                    method = c("guess", "IID", "BM", "OU", "OUF"),
                    UD = FALSE) {
    method <- match.arg(method)
    telem <- ensure_telemetry(telem)
    ctmm_list <- AKDE(telem, model = model, method = method)
    M <- ctmm_list[["model"]]
    suppressWarnings(CHHR <- st_as_sf(SpatialPolygonsDataFrame.UD(ctmm_list[["UD"]])))
    suppressWarnings(pts <- st_as_sf(SpatialPoints.telemetry(ctmm_list[["telem"]])))
    res <- list(pts = pts, model = M, CHHR = CHHR)
    if (UD) {
        res[["UD"]] <- raster(ctmm_list[["UD"]], DF = "PDF")
        res[["UD_CDF"]] <- raster(ctmm_list[["UD"]])
    }
    res
}



##------------------------------------------------------------------------------
## (3) Other
##------------------------------------------------------------------------------

##' Extract crossing times (in days) from a fitted ctmm movement model
##'
##' @title Extract Crossing Times from a ctmm Model
##' @param model A \code{ctmm} model object
##' @return A number giving crossing time in days
##' @export
##' @author Joshua O'Brien
crossing_time <- function(model) {
    secs_per_day <- 60 * 60 * 24
    CI <- summary(model, units = FALSE)[["CI"]]
    i <- grep("[position] (seconds)", rownames(CI), fixed = TRUE)
    secs <- CI[i, 2]
    round(secs/secs_per_day, 2)
}



##' Extract the UD raster implied by a set of telemetry points and an
##' associated ctmm movement model.
##'
##' @title Extract the UD Raster from telemetry points and ctmm model
##' @param telem A \code{telem} object (of the class defined by
##'     \pkg{ctmm} and returned by \code{sf_to_telemetry}).
##' @param model A \code{ctmm} movement model.
##' @return A RasterLayer giving the PDF an animal's utilization
##'     distribution.
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
compute_UD <- function(telem, model, sheepID = "ndowid") {
    telem <- sf_to_telemetry(telem, id = sheepID, time = "dtime")
    UD <- akde(telem, model, weights = TRUE, debias = TRUE,
               grid = list(dr = c(100, 100), align.to.origin = TRUE))
    raster(UD, DF = "PDF")
}
## DT[1, compute_UD(PTS_1[[1]], m_IID_1[[1]])]

