##' Overlay plot of first- and second-half points and home ranges
##'
##' @title Overlay plot of points and home ranges
##' @param PTS_1 An sf POINTS object with points from first half of
##'     animal's record.
##' @param PTS_2 An sf POINTS object with points from second half of
##'     animal's record.
##' @param POL_1 An sf MULTIPOLYGONS object representing home range
##'     computed from first half of animal's record.
##' @param POL_2 An sf MULTIPOLYGONS object representing home range
##'     computed from second half of animal's record.
##' @param poly_half An integer vector containing one, two, or none of
##'     the integers 1 or two. Indicates which MULTIPOLYGONS object(s)
##'     to plot. Default is 1, which prints POL_1.
##' @param points_half An integer vector containing one, two, or none
##'     of the integers 1 or two. Indicates which POINTS object(s) to
##'     plot. Default is 1, which prints POL_1.
##' @param col1 A valid color string to be applied to first half of
##'     data.
##' @param col2 A valid color string to be applied to second half of
##'     data.
##' @return Called for its side effect, a plot.
##' @importFrom grDevices adjustcolor
##' @importFrom sf st_geometry st_drop_geometry st_coordinates st_crs
##' @importFrom spTools st_envelope
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' ## Create a local wrapper function that uses hardwired lists of
##' ## points and polygons, plus an index to select which to plot
##' plot_halves_kls <- function(i, poly_half = 1, points_half = 2) {
##'     PTS_1 <- ALL_list_1[[i]]
##'     PTS_2 <- ALL_list_2[[i]]
##'     POL_1 <- KLS_1[[i]]
##'     POL_2 <- KLS_2[[i]]
##'     plot_halves(PTS_1 = PTS_1, PTS_2 = PTS_2,
##'                 POL_1 = POL_1, POL_2 = POL_2,
##'                 poly_half = poly_half, points_half = points_half)
##' }
##' par(mfcol = c(2,2))
##' lapply(1:4, plot_halves_kls)
##' }
plot_halves <- function(PTS_1, PTS_2, POL_1, POL_2,
                        poly_half = 1, points_half = 2,
                        col1 = "deepskyblue3",
                        col2 = "darkorange3") {
    col1_pts <- adjustcolor(col1, alpha.f = 0.5)
    col2_pts <- adjustcolor(col2, alpha.f = 0.5)
    col1_fill <- adjustcolor(col1, alpha.f = 0.1)
    col2_fill <- adjustcolor(col2, alpha.f = 0.1)
    plot(st_geometry(st_envelope(PTS_1, PTS_2, POL_1, POL_2)), border=NA)
    if (1 %in% poly_half) {
        plot(st_geometry(POL_1), add = TRUE,
             border = col1, col = col1_fill, lwd = 2)
    }
    if (2 %in% poly_half) {
        plot(st_geometry(POL_2), add = TRUE,
             border = col2, col = col2_fill, lwd = 2)
    }
    if (1 %in% points_half) {
        plot(st_geometry(PTS_1), add = TRUE,
             col = col1_pts, pch = "+")
    }
    if (2 %in% points_half) {
        plot(st_geometry(PTS_2), add = TRUE,
             col = col2_pts, pch = "+")
    }
}
