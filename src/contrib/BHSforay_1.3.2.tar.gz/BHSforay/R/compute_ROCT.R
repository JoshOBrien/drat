##' Combines (most of) foray and contact tab functionality in one
##' function.
##'
##' @title Compute Risk of Contact Table from Habitat, CHHR, and
##'     Allotment layers
##' @param CHHR An \code{sf} object representing a bighorn sheep core
##'     herd home range, or a length-one or length-two character
##'     vector that points to a file and or layer from which such an
##'     object can be read in by \code{sf::st_read()}. A length-one
##'     vector should give the path to a shapefile. A length-two
##'     character vector should give the path to a file geodatabase
##'     and the name of layer to be read from it, in that order.
##' @param ALLOTS An \code{sf} object whose \code{POLYGON} and/or
##'     \code{MULTIPOLYGON} geometries represent the allotments to be
##'     analyzed; or a length-one or length-two character vector that
##'     points to a file and or layer from which such an object can be
##'     read in by \code{sf::st_read()}. A length-one vector should
##'     give the path to a shapefile. A length-two character vector
##'     should give the path to a file geodatabase and the name of
##'     layer to be read from it, in that order.
##' @param HAB Categorical or continuous-valued habitat raster mapping
##'     the distribution of habitat, or a character string giving the
##'     path to a file from which such a raster can be read in by
##'     \code{raster::raster()}. Most typically, this will be a
##'     categorical raster with cell values 1, 2, and 5, representing
##'     ``habitat'', ``connectivity habitat'', and ``non-habitat''.
##' @param nRing Integer giving the number of 1-km wide rings to be
##'     analyzed.
##' @param allot_id_col Character string giving the name of the column
##'     in \code{ALLOTS} to be used uniquely identify each
##'     allotment. Defaults value is \code{"Allotment"}.
##' @param is_categorical_habitat Boolean. Should the \code{HAB}
##'     raster be treated as categorical, with cell values
##'     representing habitat types whose relative habitat preference
##'     is given in \code{HabPrefTable}? If \code{FALSE}, the raster
##'     cell values will instead be treated as themselves representing
##'     the relative preference for each cell. Default is \code{TRUE}.
##' @param HabPrefTable A \code{data.frame}, a \code{data.table}, or a
##'     character string giving the path to a \code{*.csv} file with
##'     columns named \code{"ID"} and \code{"VAL"}. The table should
##'     give the relative habitat preference corresponding to each
##'     habitat type in the supplied categorical habitat raster. If no
##'     table is supplied (and if \code{is_categorical_raster =
##'     TRUE}), it is assumed that the habitat raster uses the same
##'     habitat type coding and relative preferences as were used in
##'     the Payette analyses. In that case, a table giving relative
##'     habitat preferences of \code{c(1, 0.177, 0.029)} for
##'     categorical raster levels \code{c(1, 2, 5)} is used, in which
##'     the ID levels are codes for ``habitat'', ``connectivity
##'     habitat'', and ``non-habitat'' respectively.
##' @param FP_ram Ram foray probability. A number between 0 and 1
##'     giving the annual or seasonal probability that any given ram
##'     will leave the CHHR on a foray. Default value is \code{0.141}.
##' @param FP_ewe Ewe foray probability. Default value is
##'     \code{0.015}.
##' @param FD_ram Path to a \code{*.csv} file with columns named
##'     \code{"Distance"} and \code{"ForayProb"} giving the
##'     probability that a foraying ram will reach rings at
##'     \code{"Distance"} km from its CHHR. Defaults to
##'     \code{system.file("defaults/Ram_summer_foray_dist_35.csv",
##'     package = "BHSforay")}, which gives the distance distribution
##'     observed for rams in the Payette NF analyses.
##' @param FD_ewe Path to a \code{*.csv} file with columns named
##'     \code{"Distance"} and \code{"ForayProb"} giving the
##'     probability that a foraying ewe will reach rings at
##'     \code{"Distance"} km from its CHHR. Defaults to
##'     \code{system.file("defaults/Ewe_summer_foray_dist_35.csv",
##'     package = "BHSforay")}, which gives the distance distribution
##'     observed for ewes in the Payette NF analyses.
##' @param HerdSize The total number of adult animals in the herd.
##' @param RamProp The number or proportion of adult animals in the
##'     herd that are rams.
##' @param EweProp The number or proportion of adult animals in the
##'     herd that are ewes.
##' @param return_all_allots Boolean. Should the returned RoC Table
##'     include a row for every supplied allotment, even those more
##'     than \code{n} km from the CHHR? Default value is \code{FALSE}.
##' @param foray_prob_raster_dir Character string giving the directory
##'     into which two GeoTiff files containing ram and ewe foray
##'     probability rasters should be written. If no directory path is
##'     provided (the default), foray probability rasters will not be
##'     saved and will not even be computed.
##' @return A ``Risk of Contact table'', a \code{data.table} giving
##'     the estimated individual- and herd-level risks of contact for
##'     ewes and rams to each of the allotments in \code{ALLOTS}. In
##'     addition, if a \code{foray_prob_raster_dir} is provided,
##'     GeoTiff files containing ram and ewe foray probability rasters
##'     are computed saved to disk.
##' @importFrom rasterDT crosstabDT fasterizeDT subsDT zonalDT
##' @importFrom rasterDT cat_to_val
##' @export
##' @import raster
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
compute_ROCT <- function(CHHR,
                         ALLOTS,
                         HAB,
                         nRing = 35,
                         allot_id_col = "Allotment",
                         is_categorical_habitat = TRUE,
                         HabPrefTable,
                         FP_ram = 0.141,
                         FP_ewe = 0.015,
                         FD_ram,
                         FD_ewe,
                         HerdSize,
                         RamProp = 35,
                         EweProp = 65,
                         return_all_allots = FALSE,
                         foray_prob_raster_dir = NULL) {
    ##------------------------##
    ## (0) Prepare input data ##
    ##------------------------##
    ## Read in spatial layers, if their file paths were supplied
    CHHR <- load_vector_layer(CHHR)
    ALLOTS <- load_vector_layer(ALLOTS)
    HAB <- load_raster_layer(HAB)
    ## Ensure that vector layers are in same CRS as habitat layer
    if (!compareCRS(st_crs(CHHR)$proj4string, st_crs(HAB)$proj4string)) {
        CHHR <- st_transform(CHHR, st_crs(HAB))
    }
    if (!compareCRS(st_crs(ALLOTS)$proj4string, st_crs(HAB)$proj4string)) {
        ALLOTS <- st_transform(ALLOTS, st_crs(HAB))
    }

    ## Habitat raster
    if (is_categorical_habitat) {
        if (missing(HabPrefTable)) {
            HabPrefTable <- system.file("defaults/Payette-habitat-prefs.csv",
                                        package = "BHSforay")
        }
        if (is.character(HabPrefTable)) {
            HabPrefTable <- fread(HabPrefTable, key = "ID")
        } else if (is.data.frame(HabPrefTable)) {
            HabPrefTable <- data.table(HabPrefTable, key = "ID")
        }
        ## Ensure that raster is marked as factor with proper levels
        levels(HAB) <- data.frame(HabPrefTable)
    } else {
        ## Ensure that raster is treated as continuous
        HAB@data@isfactor <- FALSE
        HAB@data@attributes <- list()
    }
    ## Foray Distance probs
    if (missing(FD_ram)) {
        FD_ram <- system.file("defaults/Ram_summer_foray_dist_35.csv",
                              package = "BHSforay")
    }
    if (missing(FD_ewe)) {
        FD_ewe <- system.file("defaults/Ewe_summer_foray_dist_35.csv",
                              package = "BHSforay")
    }
    FD_ram <- fread(FD_ram, key = "Distance")
    FD_ewe <- fread(FD_ewe, key = "Distance")
    ## Ram and ewe count computations
    nRam <- if (is.null(HerdSize)) {
        RamProp
    }
    else {
        HerdSize * RamProp/(RamProp + EweProp)
    }
    nEwe <- if (is.null(HerdSize)) {
        EweProp
    }
    else {
        HerdSize * EweProp/(RamProp + EweProp)
    }
    ## Allotments object
    ALLOTS <- ALLOTS[allot_id_col]
    names(ALLOTS)[1] <- "Allotment"

    ##--------------------------------------##
    ## (1) Create ring polygons around CHHR ##
    ##--------------------------------------##
    RINGS <- make_buffer_rings(CHHR, n = nRing)
    ## Crop habitat raster (ensuring one cell buffer)
    ee <- extent(RINGS) + res(HAB)
    HAB <- crop(HAB, ee)

    ##-------------------------------------------------------##
    ## (2) Perform core computations giving probability that ##
    ## foraying animal will contact each allotment           ##
    ##-------------------------------------------------------##
    PROBS <-
        ring_allot_contact_probs(ALLOTS, RINGS, HAB, HabPrefTable,
                                 FD_ram, FD_ewe)

    ## (4) Create foray preference rasters
    if (!is.null(foray_prob_raster_dir)) {
        foray_prob_rasters(RINGS, HAB, FD_ram, FD_ewe,
                           foray_prob_raster_dir)
    }

    ##-----------------------##
    ## (3) Prepare RoC Table ##
    ##-----------------------##
    PROBS[, ramContactProb := prob * FP_ram * FD_ram[Ring, "ForayProb"]]
    PROBS[, eweContactProb := prob * FP_ewe * FD_ewe[Ring, "ForayProb"]]
    PROBS[, Ring := as.character(Ring)]
    PROBS[, allRamsContactRate := nRam * ramContactProb]
    PROBS[, allEwesContactRate := nEwe * eweContactProb]
    PROBS[, herdContactRate := allRamsContactRate + allEwesContactRate]
    ## For each allotment, only keep ring with maximum allotment
    ## contact probability
    PROBS <- PROBS[, .SD[which.max(herdContactRate), ], by = "Allotment"]
    PROBS[, prob := NULL]

    ## Add back allotments that don't intersect any rings
    setkey(PROBS, "Allotment")
    PROBS <- PROBS[data.table(Allotment = ALLOTS[["Allotment"]]), ]
    contact_cols <- c("ramContactProb", "eweContactProb",
                      "allRamsContactRate", "allEwesContactRate",
                      "herdContactRate")
    PROBS[is.na(Ring), (contact_cols) := 0]

    ## Process any allotments that intersect CHHR
    ii <- apply(st_intersects(ALLOTS, CHHR, sparse = FALSE), 1, any)
    PROBS[ii, (contact_cols) := Inf]
    PROBS[ii, Ring := "CHHR"]

    ## Return RoC Table
    if(!return_all_allots) {
        PROBS <- PROBS[!is.na(Ring), ]
    }
    PROBS[]
}
