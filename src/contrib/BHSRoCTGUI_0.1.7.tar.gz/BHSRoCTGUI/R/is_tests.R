##' @export
is_GDB <- function(path) {
    tryCatch(
    {
        ## Might this test work just as well?:
        ## st_layers(gdb)[["driver"]] == "OpenFileGDB"
        ##
        capture.output(st_read(path,
                               st_layers(path)[["name"]][1],
                               drivers = "OpenFileGDB"),
                       tempfile())
        return(TRUE)
    },
    error = function(e) {
        ## message("Handling error: ", conditionMessage(e))
        return(FALSE)
    })
}


##' @export
is_valid_GDB_layer <- function(gdb, layerName) {
    tryCatch(
    {
        capture.output({
            ## Is this a readable GDB layer?
            shp <- read_GDB(gdb, layerName)
            ## Can it be projected into UTM coordinates?
            zone <- find_UTM_zone(shp)
            shp <- project2UTM(shp, zone)

        },
            tempfile())
        return(TRUE)
    },
    error = function(e) {
        ## message("Handling error: ", conditionMessage(e))
        return(FALSE)
    })
}


##' @export
is_valid_SHP <- function(path) {
    tryCatch(
    {
        capture.output({
            ## Is this a readable shapefile?
            shp <- st_read(path, drivers = "ESRI Shapefile")
            ## Can it be projected into UTM coordinates?
            zone <- find_UTM_zone(shp)
            shp <- project2UTM(shp, zone)
        },
        tempfile())
        return(TRUE)
    },
    error = function(e) {
        ## message("Handling error: ", conditionMessage(e))
        return(FALSE)
    })
}


##' @export
is_sf <- function(obj) {
    inherits(obj, "sf")
}


## Tests, among other things, for a `character(0)` returned when user
## backs out of `fileChooser()` without selecting a file.
##' @export
is_valid_csv <- function(path) {
    tryCatch(
    {
        data.table::fread(path)
        return(TRUE)
    },
    error = function(e) {
        return(FALSE)
    })
}


## is_raster_file()
##
## A nice approach to reading in part of a raster at
## https://stackoverflow.com/a/50839673/980833
##
## GDALinfo() might also be a nice way to test for
##
## gdalDrivers() for the full set of raster-readable formats
##
## Might want to do tryCatch, returning FALSE if not a good file, and
## assigning the value to RV$HAB, so we just read the raster in once

##' @export
is_raster_file <- function(filePath) {
    tryCatch(class(suppressWarnings(GDALinfo(filePath)))=="GDALobj",
             error = function(e) {FALSE})
}

##' @export
is_raster <- function(obj) {
    inherits(obj, "RasterLayer")
}

