

##' Find an sf spatial object's UTM zone.
##'
##' The key UTM computation here follow my answer to
##' \href{http://stackoverflow.com/questions/9186496/determining-utm-zone-to-convert-from-longitude-latitude/9188972#9188972}{this SO question}. See the comments below the answer for a few caveats.
##' @title Get UTM zone that contains a longitude.
##' @param obj An \code{sf} object
##' @return A number representing the UTM zone containing the centroid of
##' \code{obj}
##' @export
##' @author Josh O'Brien
find_UTM_zone <- function(obj) {
    centroid <-
        st_centroid(st_geometry(obj)) %>%
        st_transform(4326) %>%
        st_coordinates()
    long <- centroid[1]
    ##  Compute UTM zone in which the centroid falls
    (floor((long + 180)/6) %% 60) + 1
}


##' Reproject spatial data into the UTM coordinate system.
##'
##' To learn which UTM zone is most appropriate for a given dataset,
##' look at the map on
##' \href{http://en.wikipedia.org/wiki/Universal_Transverse_Mercator_coordinate_system}{Wikipedia's
##' UTM page} or use this package's \code{\link{long2UTM}} function.
##' @title Project spatial data into UTM coordinates.
##' @param obj An \code{sf} object for which
##'     \code{\link[sf]{st_transform}} provides a method.
##' @param zone An integer between \code{1} and \code{60}, giving the
##'     UTM zone into which projection should take place.
##' @return A \code{Spatial*} object containing the data in \code{obj}
##'     reprojected into the projected planar UTM coordinate system.
##' @export
##' @author Josh O'Brien
##' @examples
##' ## Following example here http://stackoverflow.com/a/26308889/980833
##' p <- shapefile(system.file("external/lux.shp", package="raster"))
##' zone <- round(mean(long2UTM(coordinates(p))))
##' pUTM <- project2UTM(obj=p, zone=zone)
project2UTM <- function(obj, zone) {
    STR <- "+proj=utm +zone=%d +datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"
    crs <- CRS(sprintf(STR, zone))
    st_transform(obj, crs)
}
