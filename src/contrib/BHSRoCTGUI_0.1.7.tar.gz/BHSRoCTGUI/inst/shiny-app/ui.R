shinyUI(
  navbarPage("RoC Tool",
  ## theme = "tabs.css",
  id = "tab_being_displayed", ## (Sets input$tab_being_displayed)

  ##---------------------##
  ##   DATA UPLOAD TABS  ##
  ##---------------------##
  tabPanel("Load data",
    navlistPanel(
      widths = c(3, 9),
      ## ui/CHHRUI.R
      source(file.path("ui", "CHHRUI.R"), local = TRUE)$value,
      ## ui/AllotmentsUI.R
      source(file.path("ui", "AllotmentsUI.R"), local = TRUE)$value,
      ## ui/HabitatUI.R
      source(file.path("ui", "HabitatUI.R"), local = TRUE)$value
  )),

  ##---------------------##
  ##   CONFIG TABS       ##
  ##---------------------##
  tabPanel("Configure",
    navlistPanel(
      widths = c(3, 9),
      ## ui/DemographyUI.R
      source(file.path("ui", "DemographyUI.R"), local = TRUE)$value,
      ## ui/BehaviorUI.R
      source(file.path("ui", "BehaviorUI.R"), local = TRUE)$value
  )),

  ##---------------------##
  ##  COMPUTE RoCT TAB   ##
  ##---------------------##
  ## ui/RoCTUI.R
  source(file.path("ui", "RoCTUI.R"), local = TRUE)$value,


  ##---------------------##
  ##   LEAFLET MAP TAB   ##
  ##---------------------##
  ## ui/MapUI.R
  source(file.path("ui", "MapUI.R"), local = TRUE)$value
  )
)


## // Local Variables:
## // ess-indent-offset: 2
## // End:
