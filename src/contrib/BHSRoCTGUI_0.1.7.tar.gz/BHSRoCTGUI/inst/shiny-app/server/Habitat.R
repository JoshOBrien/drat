##------------------------##
##   HABITAT UPLOAD TAB   ##
##------------------------##

##------------------------------------------------------------------------------
## TIF layer upload
##------------------------------------------------------------------------------

observeEvent(input$upload_HAB_tif, {
  filePath <- fileChooser("~", filter = "tif")
  if (is_raster_file(filePath)) {
    ## Spinner started here is removed in "Map.R", after call to
    ## `addRasterImage(RV$HAB_image, ...)`
    show_modal_spinner(text = "Uploading and preparing habitat raster for display")
    RV$HAB_file_path <- filePath
    RV$HAB_image <- raster_warp(filePath)
    ## If this isn't the 1st uploaded raster, resets downstream values
    RV$HAB_raster_type <- ""
    RV$HAB_pref_file_path <- ""
    if (!is.null(input$HAB_raster_type)) {
      updateRadioButtons(session, "HAB_raster_type", selected = "class_file")
    }
  } else {
    ## TODO: Needs to silently handle non-choice
    ## (`identical(filePath,character(0))`), and pop up a warning
    ## for bad file choice.
  }
})


## Ask user whether raster is categorical or continuous
observeEvent(RV$HAB_file_path, {
  toggle(id = "set_hab_prefs",
         condition = nchar(RV$HAB_file_path))
}, ignoreInit = TRUE)


observeEvent(input$HAB_raster_type, {
  RV$HAB_raster_type <- input$HAB_raster_type
})

## Present the appropriate widget for inputing habitat class preferences
observeEvent({RV$HAB_file_path; RV$HAB_raster_type}, {

  RV$HAB_is_categorical <-
    RV$HAB_raster_type %in% c("class_file", "class_interactive")

  ## Hide/show subsidiary widgets depending on raster type
  toggle(id = "upload_HAB_pref_csv",
         condition = RV$HAB_raster_type == "class_file")
  toggle(id = "hot_HAB_pref",
         condition = RV$HAB_raster_type == "class_interactive")

  ## Handle three possible habitat raster styles:
  if (RV$HAB_raster_type == "class_file") {
    ## (CASE 1)
  } else if (RV$HAB_raster_type == "class_interactive") {
    ## (CASE 2) Categorical, with habitat prefs from interactive input
    show_modal_spinner(text = "Extracting unique habitat classes from raster")
    r <- raster(RV$HAB_file_path)
    ids <- sort(unique(r))
    DF <- data.frame(ID = ids, VAL = rep("", length(ids)))
    RV$DF <- DF
    remove_modal_spinner()
  } else if  (RV$HAB_raster_type == "preference") {
    ## (CASE 3) Raster is a habitat preference file
  }
})


## (CASE 1) Categorical, with habitat prefs from file
observeEvent(input$upload_HAB_pref_csv, {
  filePath <- fileChooser("~", filter = "csv")
  if (is_valid_csv(filePath) &&
      c("ID", "VAL") %in% names(read.csv(filePath))) {
    RV$HAB_pref_file_path <- filePath
  } else {
    if (length(filePath)) {
      msg <-
        paste('The habitat preference file must be a CSV file',
              'with columns named ID and VAL.')
      shinyalert(title = "Problem reading habitat preference file",
                 text = msg,
                 type = "error")
    }
  }
})

## (CASE 2)
observeEvent(RV$DF, {
  output$hot_HAB_pref <- renderRHandsontable({
    DF <- RV$DF
    if (!is.null(DF))
      if (!all.equal(DF$ID, as.integer(DF$ID))) {
        stop("Factor raster contains non-integer values")
      } else {
        DF$ID <- as.integer(DF$ID)
      }
    ## rhandsontable(DF, width = 400, rowHeaderWidth = 0) %>%
    rhandsontable(DF, width = 400) %>%
      hot_col("ID", readOnly = TRUE) %>%
      hot_col("VAL", type = "numeric")
  })
})

## Continuously update R data.frame reflecting table's contents
observeEvent({input$hot_HAB_pref}, {
  if (!is.null(input$hot_HAB_pref)) {
    RV$DF <- hot_to_r(input$hot_HAB_pref)
  }
})


##------------------------------------------------------------------------------
## Report info on currently loaded Habitat layer
##------------------------------------------------------------------------------

observeEvent(RV$HAB_file_path, {
  toggle("HAB_info", condition = nchar(RV$HAB_file_path))
  output$HAB_info <-
    renderPrint(rasterLayerSummary(RV))
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Conditionally hide/show check marks
##------------------------------------------------------------------------------

observeEvent(RV$HAB_file_path, {
  toggle("dash_HAB_tif", condition = !nchar(RV$HAB_file_path))
  toggle("check_HAB_tif", condition = nchar(RV$HAB_file_path))
})


## Do we know how to interpret cell values in the habitat raster?
observe({
  ## (Handle default inital value, `character(0)`)
  type <- input$HAB_raster_type
  type <- ifelse(length(type) == 0, "", type)
  ## Validity tests depends on type of raster
  OK$Habitat <-
    switch(type,
           ## Habitat preference file
           class_file = is_valid_csv(RV$HAB_pref_file_path),
           ## User-entered habitat preference in rhandsontable
           class_interactive = {
             length(as.character(RV$DF[["VAL"]])) > 0 &&
               !any(is.na(as.numeric(as.character(RV$DF[["VAL"]]))))
           },
           ## Non-categorical habitat raster
           preference = TRUE,
           ## No choice
           FALSE)
  toggle("dash_HAB_pref", condition = !OK$Habitat)
  toggle("check_HAB_pref", condition = OK$Habitat)
})



## // Local Variables:
## // ess-indent-offset: 2
## // End:
