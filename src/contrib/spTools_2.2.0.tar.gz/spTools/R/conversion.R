
##' Convert a two-column x-y matrix to a SpatialLines object.
##'
##' \code{sp::SpatialPoints()} will convert an x-y matrix to a
##' SpatialPoints object.  This function takes an x-y matrix and
##' returns a SpatialLines object.
##' @title SpatialLines from a two-column matrix
##' @param xy A two-column matrix of x-y coordinates, like that
##'     accepted as an argument by the \code{SpatialLines} function.
##' @param prj A \code{CRS} object, as specified by the sp package.
##' @param id A value for the \code{Lines} object's \code{ID} slot. If
##'     no value of \code{id} is provided (the default), the slot will
##'     be given a random 10 character name.
##' @return A \code{SpatialLines} object containing a single line.
##' @import sp
##' @import raster
##' @export
##' @author Joshua O'Brien
xy2SL <- function(xy, prj = CRS("+proj=longlat"), id = NULL) {
    if(is.null(id)) {
        id <- paste0(sample(letters, 10), collapse = "")
    }
    linesList <- list(Lines(Line(xy), ID = id))
    SpatialLines(linesList, proj4string = prj)
}


##' Convert a two-column x-y matrix to a SpatialPolygons object.
##'
##' \code{sp::SpatialPoints()} will convert an x-y matrix to a
##' \code{SpatialPoints} object.  This function takes an x-y matrix
##' and returns a \code{SpatialPolygons} object.
##' @title SpatialPolygons from a two-column matrix
##' @param xy A two-column matrix of x-y coordinates, like that
##'     accepted as an argument by the \code{SpatialLines}
##'     function. If the final row does not equal the first row, the
##'     first row is automatically appended to close the polygon.
##' @param prj A \code{CRS} object, as specified by the sp package.
##' @param id A value for the \code{Polygons} object's \code{ID}
##'     slot. If no value of \code{id} is provided (the default), the
##'     slot will be given a random 10 character name.
##' @return A \code{SpatialPolygons} object containing a single
##'     polygon.
##' @export
##' @author Joshua O'Brien
##' @examples
##' tri <- xy2SP(matrix(rnorm(6), ncol=2))
##' plot(tri)
##' ll <- replicate(5, xy2SP(matrix(rnorm(6), ncol=2)))
##' tris <- Reduce(rbind, ll)
##' plot(tris, col=colorRampPalette(blues9)(length(tris)))
xy2SP <- function(xy, prj = CRS("+proj=merc"), id = NULL) {
    if(is.null(id)) {
        id <- paste0(sample(letters, 10), collapse = "")
    }
    if(!identical(xy[1,], xy[nrow(xy),])) {
        xy <- rbind(xy, xy[1,])
    }
    SpatialPolygons(list(Polygons(list(Polygon(xy)), ID = id)),
                    proj4string = prj)
}


##' A utility function to simplify converting \code{SpatialPolygons} to
##' \code{SpatialPolygonsDataFrame} objects.
##'
##' \code{spplot()} has no \code{SpatialPolygons} method, and instead
##' needs a \code{SpatialPolygonsDataFrame}, even if its attributes
##' aren't used in the plot. This function makes plotting a
##' \code{SpatialPolygons} object \code{SP} as simple as doing
##' \code{spplot(SPl2SPlDF(SP))}. (It might eventually be nice to wrap
##' this up as an \code{as} method for \code{SpatialPolygons}
##' objects. Alternatively, take a leaf from the \code{raster}
##' package's definition of an \code{spplot()} method for
##' \code{SpatialPoints}, details in its \code{"R/spplot.R"} source
##' file.)
##' @title Convert a SpatialPolygons object to a
##'     SpatialPolygonsDataFrame object.
##' @param SP A \code{SpatialPolygons} object.
##' @return A \code{SpatialPolygonsDataFrame} object.
##' @export
##' @author Joshua O'Brien
##' @examples
##' X <- shapefile(system.file("external/lux.shp", package="raster"))
##' X <- as(X, "SpatialPolygons")
##' spplot(SPl2SPlDF(X), colorkey = FALSE, fill = "transparent",
##'        par.settings = list(axis.line = list(col=0)))
SPl2SPlDF <- function(SP) {
    nms <- sapply(SP@polygons, function(x) x@ID)
    DATA <- data.frame(val = rep(1, length(nms)), row.names = nms)
    SPDF <- SpatialPolygonsDataFrame(SP, data=DATA)
    SPDF
}


##' A utility function to simplify converting \code{SpatialLines} to
##' \code{SpatialLinesDataFrame} objects.
##'
##' \code{spplot()} has no \code{SpatialLines} method, and instead
##' needs a \code{SpatialLinesDataFrame}, even if its attributes
##' aren't used in the plot. This function makes plotting a
##' \code{SpatialLines} object \code{SL} as simple as doing
##' \code{spplot(SL2SLDF(SP))}.
##' @title Convert a SpatialLines object to a SpatialLinesDataFrame
##'     object.
##' @param SL A \code{SpatialLines} object.
##' @return A \code{SpatialLinesDataFrame} object.
##' @export
##' @author Joshua O'Brien
##' @examples
##' a <- SL2SLDF(xy2SL(matrix(rnorm(10), ncol=2)))
##' b <- SL2SLDF(xy2SL(matrix(rnorm(10), ncol=2)))
##' spplot(rbind(a,b), zcol=1,
##'        sp.layout=list(list("sp.lines", rbind(a,b))), colorkey=FALSE)
SL2SLDF <- function(SL) {
    nms <- sapply(SL@lines, function(x) x@ID)
    DATA <- data.frame(val = seq_along(nms), row.names = nms)
    SLDF <- SpatialLinesDataFrame(SL, data=DATA)
    SLDF
}


##' Find the combined bounding box of an arbitrarily large set of
##' Spatial objects.
##'
##' This function is meant to make plotting a group of \code{Spatial*}
##' objects a bit easier.
##' @title Find bounding box of multiple objects.
##' @param ... Two or more \code{bbox} matrices.
##' @param buffer The proportion by which each side of the bounding
##'     \code{bbox} should be extended. Defaults to \code{0}.
##' @return A \code{bbox} matrix.
##' @importMethodsFrom sp bbox
##' @export
##' @author Joshua O'Brien
##' @examples
##' ll <- SPobjects()
##' do.call(bboxCascaded, ll)
bboxCascaded <- function(..., buffer=0) {
    bb <- bbox(Reduce(union, lapply(list(...), extent)))
    bb + tcrossprod(apply(bb,1,diff), buffer*c(-1,1))
}


##' Make a possibly buffered clipping polygon from a Spatial object
##'
##' The code used here is adapted from this SO answer.
##' @title Make a clipping polygon
##' @param obj Any Spatial object with an \code{extent} method.
##' @param buffer Proportion by which each edge of \code{extent(obj)}
##'     should be buffered.
##' @return A rectangular SpatialPolygons object marking the (possibly
##'     buffered) extent of \code{obj}.
##' @export
##' @author Joshua O'Brien
##' @importFrom methods as
##' @examples
##' ## Make SpatialPoints object meuse in .GlobalEnv
##' example(meuse)
##' ## SPl2SPlDF() needed to feed SpatialPolygons object to spplot().
##' spplot(SPl2SPlDF(makeCP(meuse)),
##'        colorkey = FALSE, fill = "white",
##'        ## par.settings = list(axis.line = list(col = "white")),
##'        sp.layout = list("sp.points", meuse))
makeCP <- function(obj, buffer = 0) {
    ee <- extent(obj)*(2*buffer + 1)
    CP <- as(ee, "SpatialPolygons")
    crs(CP) <- crs(obj)
    CP
}


##' A simple wrapper around unionSpatialPolygons that allows
##' SpatialPolygonsDFs to keep their associated data.
##'
##' See page 3 of \code{vignette("combine_maptools")} for a good
##' example of what this function does and how it does it.
##'
##' Note that (like \code{\link[maptools]{unionSpatialPolygons}}), it
##' reorders component \code{Polygons} objects into alphabetical order
##' based on their value of \code{IDs}.
##'
##' Note also this function in no way aggregates \code{data.frame}
##' rows in the object's \code{data} slot. Instead, simply keeps the
##' first row associated with any muli-part polygon.
##' @title Aggregate Polygons in a SpatialPolygonsDataFrame object.
##' @param SPDF A \code{SpatialPolygonsDataFrame}, possibly with more
##'     than one row having the same level of \code{IDs}.
##' @param IDs A vector defining the output Polygons objects. (For
##'     full details, see documentation for
##'     \code{\link[maptools]{unionSpatialPolygons}} in the
##'     \pkg{maptools} package.)
##' @return A \code{SpatialPolygonsDataFrame}, \code{obj}, with one
##'     \code{Polygons} object (i.e. one element in
##'     \code{obj@@polygons} and one row in \code{data.frame(obj)})
##'     for each unique level of \code{IDs}.
##' @importFrom maptools unionSpatialPolygons
##' @export
##' @author Joshua O'Brien
##' @examples
##' ## Read in data
##' nc90 <- shapefile(system.file("shapes/co37_d90.shp", package = "maptools"))
##' proj4string(nc90) <- CRS("+proj=longlat +datum=NAD27")
##' nc90$STCO <- paste0(nc90$ST, nc90$CO)
##'
##' ## See the problem
##' try(spChFIDs(nc90, nc90$STCO))
##'
##' ## Fix it up, plus show another way to unionSpatialPolygons
##' a <- table(nc90$STCO)
##' dups <- names(a)[a>1] ## "37055" "37095"
##' SP <- subset(nc90, STCO %in% dups)
##' SP2 <- maptools::unionSpatialPolygons(SP, IDs=paste(SP$ST, SP$CO, sep=""))
##' SP3 <- maptools::unionSpatialPolygons(SP, IDs=rep("A", 6))
##'
##' sixCols <- c('red', 'blue', 'yellow', 'green', 'purple', 'grey')
##' par(mfrow=c(2,2), mar = c(0,0,0,0))
##' plot(SP, col = sixCols)
##' plot(SP2, col = sixCols)
##' plot(SP3, col = sixCols)
unionSpatialPolygonsDF <- function(SPDF, IDs) {
    ## Note: unionSpatialPolygons returns SP elements in alphabetical
    ## order by their value in IDs
    SP <- unionSpatialPolygons(SPDF, IDs)
    df <- data.frame(SPDF)[!duplicated(IDs), ]
    ## Next line allows SPDF() below to match up row.names(df) to SP
    ## names
    row.names(df) <- unique(IDs)
    SpatialPolygonsDataFrame(SP, df)
}


##' Rasterize \code{Spatial*} objects using gdal_rasterize.
##'
##' For a 1000-by-1000 raster, this function \code{gRasterize} is more
##' than 6 times faster than \code{raster::rasterize}. For a
##' 2000-by-2000 raster, it is almost 12 times faster (6 seconds
##' vs. 70 seconds on my Windows laptop). I'd be interested to know if
##' there's a really good reason that the \pkg{raster} package does
##' \emph{not} use this much faster code to perform rasterization.
##'
##' I've modeled \code{gRasterize} arguments and behavior on that of
##' \code{\link[raster]{rasterize}}. Like\code{rasterize},it takes a
##' \code{filename=} argument which defaults to \code{""} in which
##' case (unless it's determined internally that
##' \code{!canProcessInMemory(rstr, 3)}) the returned raster is
##' \code{'inMemory'}. Otherwise, if the raster is too large or if a
##' filename is supplied, it's returned \code{fromDisk}.
##'
##' Internally, \code{\link[gdalUtils]{gdal_rasterize}} by default
##' writes to a file, and only optionally returns an R \code{Raster}
##' object (when its \code{output_Raster = TRUE}); to get the raster
##' \code{'inMemory'}, I use \code{\link[raster]{readAll}} (after a
##' check that it's really OK, memory-wise to do so.)
##' @title Fast rasterize for Spatial objects
##' @param SPDF A \code{Spatial*} object to be rasterized.
##' @param r A \code{Raster*} object to be used as the rasterization
##'     template.
##' @param field Character. The name of the numeric column in
##'     \code{data.frame()} that will be written to the output Raster*
##'     object.
##' @param filename Character. Output filename (optional). If none is
##'     supplied, the resulting raster will be stored \code{inMemory}
##'     (unless it is too large, as determined by a call to
##'     \code{canProcessInMemory(y, 3)}
##' @return A \code{RasterLayer} object containing a rasterized
##'     version of \code{SPDF}.
##' @importFrom gdalUtilities gdal_rasterize
##' @export
##' @author Joshua O'Brien
##' @examples
##' SPDF <- shapefile(system.file("external/lux.shp", package="raster"))
##' ## rr <- raster(extent(SPDF), ncol=100, nrow=100, crs=proj4string(SPDF))
##' llratio <- 1/cos(pi*mean(coordinates(SPDF)[,2])/180)
##' rr <- raster(extent(SPDF),
##'              resolution=c(llratio*0.01, 0.01),
##'              crs=proj4string(SPDF))
##'
##' ## An example using an integer-valued field
##' rInt <- gRasterize(SPDF, rr, field = "ID_2")
##' plot(rInt, col=RColorBrewer::brewer.pal(name = "Paired", 12))
##' plot(SPDF, lwd=3, border="grey30", add=TRUE)
##'
##' ## An example using a character-valued field
##' rFac <- gRasterize(SPDF, rr, field = "NAME_2")
##' rasterVis::levelplot(rFac)
gRasterize <- function (SPDF, r, field, filename = "") {

    INMEM <- canProcessInMemory(r, 3) && filename == ""
    ## character/factor field preparations
    ofield <- SPDF[[field]]
    FACTOR_FIELD <- inherits(ofield, c("character", "factor"))
    if(FACTOR_FIELD) {
        SPDF[[field]] <- as.integer(factor(ofield, levels = unique(ofield)))
    }
    ## Write both layers to files ("*.shp" & "*.tif" respectively)
    tmpDir <- dirname(rasterTmpFile())
    shpDir <- file.path(tmpDir, "shapes")
    shpFile <- file.path(shpDir,  "SPDF.shp")
    if(!dir.exists(shpDir)) {
        on.exit(unlink(shpDir, recursive=TRUE), add=TRUE)
        dir.create(shpDir)
    }
    if (filename == "") {
        rasFile <- file.path(tmpDir, "r.tif")
    } else {
        rasFile <- filename
    }
    shapefile(SPDF, shpFile, overwrite = TRUE)
    ## We want to burn into a raster with background of NAs
    ## r[] <- NA
    ## suppressWarnings(writeRaster(r, filename = rasFile,
    ##                              format="GTiff", datatype='FLT4S',
    ##                              overwrite = TRUE))
    init(r, fun = function(x) NA, filename = rasFile, format = "GTiff",
         datatype = "FLT4S", overwrite = TRUE)
    ## Rasterize polygons, burning into the raster values from selected field
    ## b <- gdal_rasterize(shpFile, rasFile, a = field, output_Raster = TRUE)
    b <- gdal_rasterize(shpFile, rasFile, a = field)
    ## r <- raster(b, layer=1)
    r <- raster(rasFile)
    ## Further  processing for character or factor fields from SPDF
    if(FACTOR_FIELD) {
        r <- ratify(r)
        RAT <- levels(r)[[1]]
        RAT[field] <- unique(ofield)[RAT[[1]]]
        levels(r) <- RAT
    }
    ## Clean up intermediate files:
    unlink(dirname(shpFile), recursive = TRUE)
    if(INMEM) {
        r <- readAll(r)
        unlink(rasFile)
    }
    r
}
