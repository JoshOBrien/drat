##' Makes a list of five different kinds of Spatial objects.
##'
##' @title A function to quickly create example Spatial*DataFrame
##'     objects
##' @return A list containing \code{Spatial*DataFrame}, where \code{*}
##'     is one of \code{Points}, \code{Lines}, \code{Polygons},
##'     \code{Grid}, or \code{Pixels}.
##' @export
##' @importFrom rgeos readWKT
##' @importFrom stats rnorm
##' @author Joshua O'Brien
##' @examples
##' ll <- SPobjects()
##' with(ll, {
##' spplot(SP, col.regions = "wheat4", auto.key = FALSE,
##'     sp.layout = list(list("sp.lines", SL, col="orangered4", lwd=8),
##'                      list("sp.polygons", SPL, lwd=3, fill="gold")))
##' })
SPobjects <- function() {
## (1) Make Spatial**DataFrame objects.

## SpatialPointsDataFrame
SP <- SpatialPoints(matrix(rnorm(10000), ncol = 2))
SP <- SpatialPointsDataFrame(SP, data.frame(id = seq_along(SP)))

## SpatialLinesDataFrame
SL <- readWKT("LINESTRING(-3 -3,0 3,3 -3)")
SL <- SpatialLinesDataFrame(SL, data.frame(id = seq_along(SL)))

## SpatialPolygonsDataFrame
SPL <-  readWKT("POLYGON((-1.5 -1.5,1.5 -1.5,1.5 1.5,-1.5 1.5,-1.5 -1.5))")
SPL <- SpatialPolygonsDataFrame(SPL, data.frame(id = seq_along(SPL)))

## SpatialGridDataFrame
r <- deratify(rasterize(SPL, raster(extent(SPL))))
r[] <- 1:ncell(r)
SG <- as(shift(r, dx = 1, dy = 1), "SpatialGridDataFrame")

## SpatialPixelsDataFrame
SPIX <- as(SG, "SpatialPixelsDataFrame")

## Return them all in a single list
list(SP=SP, SL=SL, SPL=SPL, SG=SG, SPIX=SPIX)
}

