##' Color Palette for Foray Preference Rasters
##'
##' This vector of RGB colors gives the palette used for displaying
##' foray preference rasters in ArcGIS versions of the RoCT.
##'
##' @docType data
##' @format A character vector giving the rgb codes of 20 colors.
##' @examples
##' \dontrun{
##' plot(raster(matrix(1:20, nrow = 1)),
##'      col = Yellow_to_Green_to_Dark_Blue)
##' }
"Yellow_to_Green_to_Dark_Blue"
