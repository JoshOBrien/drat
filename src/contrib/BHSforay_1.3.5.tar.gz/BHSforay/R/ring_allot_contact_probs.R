ring_allot_contact_probs <- function(ALLOTS, RINGS, HAB, HabPrefTable,
                                     FD_ram, FD_ewe)  {
    ## (1) Union of RINGS and ALLOTMENTS (incl. rasterized version)
    FRAGS <- my_union(X = RINGS, Y = ALLOTS,
                      fx = "Ring", fy = "Allotment")
    st_geometry(FRAGS) <- st_cast(st_geometry(FRAGS), "MULTIPOLYGON")
    FRAGS_RASTER <- fasterizeDT(FRAGS, HAB, field = "ID", background = NA)

    ## (2) Extract sum of values in each fragment of union
    if(is.factor(HAB)) {
        xtab <- crosstabDT(FRAGS_RASTER, HAB)
        col_IDs <- as.integer(colnames(xtab))
        HabPrefVec <- HabPrefTable[J(col_IDs), VAL]

        frag_sums <- data.frame(ID = as.integer(row.names(xtab)),
                                val = xtab %*% HabPrefVec)
    } else {
        DT <- zonalDT(HAB, FRAGS_RASTER, sum)
        colnames(DT) <- c("ZONE", "VAL")
        frag_sums <- data.frame(DT[!is.na(ZONE), .(ID=ZONE, val=VAL)])
    }
    ## Collect results in a data.table
    res <- merge(st_drop_geometry(FRAGS), frag_sums, by = "ID")
    DT <- data.table(res, key = "Ring")
    DT[, ID := NULL]

    ## (3) Compute conditional prob of allotment contact in each ring
    RR <- DT[!is.na(Ring), list(total = sum(val)), by = "Ring"]
    CC <- DT[complete.cases(DT),]
    PROBS <- RR[CC, .(Ring, Allotment, prob = val/total)]
    PROBS
}
