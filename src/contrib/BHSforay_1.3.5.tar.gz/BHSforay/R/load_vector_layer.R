load_vector_layer <- function(obj) {
    if (is.character(obj) & length(obj) %in% 1:2) {
        obj <-
            if (length(obj) == 1) {
                st_read(obj)
            } else {
                read_GDB(obj[1], obj[2])
            }
    }
    if (inherits(obj, "sf")) {
        return(st_make_valid(obj))
    }
    stop("obj must be either an object of class 'sf' or a character vector",
         "giving the path to a shapefile or gdb directory and layer")
}
