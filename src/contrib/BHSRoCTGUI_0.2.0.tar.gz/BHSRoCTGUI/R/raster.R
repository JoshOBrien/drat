## Helper functions for map whose code I sent to Kezia, 2019-06-26:
## c:/Josh/Projects/BHS/USU-19/Code/leaflet-RoC-mapper.R


## Helper function that computes the factor by which a raster should
## be aggregated to stay below (well below) 4 Mb limit that is
## addRasterImage()'s default. The two scaling factors appearing in
## the function's computation of `nBytes`result from the following:
##
## - gdalwarp() to "EPSG:3857" ("Web Mercator") projection with no
##   change of resolution increases the number of cells 2.13-fold.
##
## - We get approximately 9.19 raster cells per byte in the pngData
##   object tested by addRasterImage()'s 4Mb `maxBytes=` default
##   limit.
##
##' @export
compute_agg_factor <- function(r, maxBytes = 8e5) {
    ff <- c(1,2,5,10,20,50) ## Candidate aggregation factors
    nBytes <- ncell(r) * (2.13/9.19)
    ff[match(TRUE, (nBytes/(ff)^2) < maxBytes)]
}

##' @export
raster_warp <- function(file, agg_factor) {
    ## Aggregate and project to a Web Mercator projection
    r <- raster(file)
    if (missing(agg_factor)) {
        agg_factor <- compute_agg_factor(r)
    }
    out_res <- res(r) * agg_factor
    out_tif <- tempfile(fileext = ".tif")
    ## `tap=TRUE` ("target aligned pixels") forces pixel edges to be
    ## at multiples of `tr`
    gdalwarp(file, out_tif, tap = TRUE,
             r = "mode",
             t_srs = "EPSG:3857",
             multi = TRUE, tr = out_res)
    ## The gdalwarp() call above produces a raster whose CRS contains
    ## `ellps WGS 84` and `datum WGS_1984` components that now get
    ## dropped with warnings by raster() call
    suppressWarnings(raster(out_tif))
}


##------------------------------------------------------------------------------
## Usage:
##------------------------------------------------------------------------------
## Data preparation
##
## hab <- system.file("data/rasters/Payette-habitat.tif",
##                    package = "BHSdataPNF")
## agg_factor <- compute_agg_factor(raster(hab))
## hab_raster <- raster_warp(hab, agg_factor = agg_factor)
##
##
## Overlay on leaflet map:
##
## addRasterImage(hab_raster, opacity = 0.5,
##                project = FALSE,
##                colors = grey(c(0.0, .7, .9)),
##                group = "Habitat") %>%
