
## Write inputs, parameters, and runscript to Archive directory
##' @export
archive_inputs_CHHR <- function(archiveDir, params) {
    ## Copy of parameter list, to be modified to point at archived
    ## copies of data
    pp <- params

    ## Save PTS layer to geopackage
    PTS_gpkg <- paste(gsub(".", "_", pp$dsn[2], fixed = TRUE),
                      collapse = "-")
    PTS_gpkg <- paste0(PTS_gpkg, ".gpkg")
    ogr2ogr(pp$dsn[1],
            file.path(archiveDir, PTS_gpkg),
            layer = pp$dsn[2],
            f = "GPKG",
            overwrite = TRUE)
    pp$dsn[1] <- PTS_gpkg

    ## Write out YAML file that can be used to reproduce the analysis
    write_parameters_txt_CHHR(params = pp, outputDir = archiveDir)
    write_runscript_CHHR(params = pp, outputDir = archiveDir)

    ## Add README.txt, describing the directory's contents
    README <- system.file(package = "BHSRoCTGUI",
                          "inst/shiny-app/extras/README-CHHR.txt")
    file.copy(README, file.path(archiveDir, "README.txt"))
}
