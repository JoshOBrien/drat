
##' @export
spatialLayerSummary <-
    function(RV,
             layerType = c("CHHR", "ALLOTS", "Habitat"),
             fileType = c("SHP", "GDB", "TIF"))
{
    template <-
        paste("%s layer summary:\n\n",
              "  - File type:  %s\n",
              "  - File path:  %s\n",
              "  - Layer:      %s\n")
    layerTypes <- c(PTS = "Animal locations",
                    CHHR = "CHHR",
                    ALLOTS = "Allotments",
                    Habitat = "Habitat")
    fileTypes <- c(SHP = "Shapefile",
                   GDB = "File geodatabase",
                   TIF = "GeoTiff")
    ## Extract info about currently-loaded layer from RV object
    filePath <- RV[[paste(layerType, fileType, "path", sep="_")]]
    ## Only GDB have explicitly supplied layer name. For shapefiles,
    ## just use the name of the shapefile as the layer name.
    layer <- if (fileType == "GDB") {
                 RV[[paste(layerType, fileType, "layer", sep="_")]]
             } else {
                 tools::file_path_sans_ext(basename(filePath))
             }
    ## Plug info into template and print it out
    summary <- sprintf(template,
                layerTypes[layerType],
                fileTypes[fileType],
                dQuote(filePath),
                layer)
    ## Allotments layer can get an additional line, for ID column...
    if (layerType == "PTS" & nchar(RV$PTS_ID_column)) {
        summary <-
            paste(summary, sprintf("  - ID column:  %s\n",
                                   dQuote(RV$PTS_ID_column)))
    }
    ## Allotments layer can get an additional line, for ID column...
    if (layerType == "ALLOTS" & nchar(RV$ALLOTS_ID_column)) {
        summary <-
            paste(summary, sprintf("  - ID column:  %s\n",
                                   dQuote(RV$ALLOTS_ID_column)))
    }
    cat(summary)
}

## ## Example usage
##
## RV <- list(CHHR_is = "SHP",
##            CHHR_SHP_path = "C:\\Users\\Josh\\Desktop\\GUI-Foray-Contact\\sampleData\\shapefiles\\Lostine.shp",
##            CHHR_GDB_path = "C:\\Users\\Josh\\Desktop\\GUI-Foray-Contact\\sampleData\\file-geodatabase\\Payette.gdb",
##            CHHR_GDB_layer = "Payette_Sheep_Allotments")
##
## spatialLayerSummary(RV, "CHHR", "GDB")
## spatialLayerSummary(RV, "CHHR", fileType = RV$CHHR_is)



