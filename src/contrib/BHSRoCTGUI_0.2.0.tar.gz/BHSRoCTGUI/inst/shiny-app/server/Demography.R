##--------------------------##
##  DEMOGRAPHY TAB: SERVER  ##
##--------------------------##

## One, and only one, of Input$Number or Input$Ratio checkboxes can be TRUE
observe(updateCheckboxInput(session, "Number", value = !input$Ratio))
observe(updateCheckboxInput(session, "Ratio", value = !input$Number))

## Depending which checkbox is selected, disable appropriate inputs.
observe({toggleState(id = "HerdSize", condition = input$Ratio)})
observe({toggleState(id = "ramPerc", condition = input$Ratio)})
observe({toggleState(id = "ewePerc", condition = input$Ratio)})
observe({toggleState(id = "ramNum", condition = input$Number)})
observe({toggleState(id = "eweNum", condition = input$Number)})

## Force ram and ewe percentages to add to 100
values <- reactiveValues(EWEPCT = numeric(0))
observe(if(input$Ratio) values$EWEPCT <- input$ewePerc)
observe(if(input$Ratio) values$EWEPCT <- 100 - input$ramPerc)
observe(if(input$Ratio) updateNumericInput(session, "ewePerc", value = values$EWEPCT))
observe(if(input$Ratio) updateNumericInput(session, "ramPerc", value = 100 - values$EWEPCT))


## Force ram and ewe numbers to match percentages and HerdSize
observe(
  if (input$Ratio) {
    if (!is.na(input$HerdSize)) {
      updateNumericInput(session, "eweNum",
                         value = round(input$HerdSize*input$ewePerc/100, 1))
      updateNumericInput(session, "ramNum",
                         value = round(input$HerdSize*input$ramPerc/100, 1))
    }
  })

## Force total pop to match ram + ewe
observe(
  if (input$Number) {
    ## Whenever animal-number entry is activated, round to integers
    updateNumericInput(session, "eweNum", value = round(input$eweNum))
    updateNumericInput(session, "ramNum", value = round(input$ramNum))
    ## OTHER
    updateNumericInput(session, "HerdSize",
                       value = pmax(input$eweNum, 0, na.rm = TRUE) +
                         pmax(input$ramNum, 0, na.rm = TRUE))
    if (isTRUE(input$HerdSize > 0)) {
      updateNumericInput(session, "ewePerc",
                         value = round(100*input$eweNum/input$HerdSize, 1))
      updateNumericInput(session, "ramPerc",
                         value = round(100*input$ramNum/input$HerdSize, 1))
    }
  })

##------------------------------------------------------------------------------
## Conditionally hide/show check mark
##------------------------------------------------------------------------------

observeEvent({input$HerdSize}, {
  toggle("dash_HerdSize", condition = {!(input$HerdSize > 0)})
  toggle("check_HerdSize", condition = {input$HerdSize > 0})
  OK$Demography <- isTRUE(input$HerdSize > 0)
})



## // Local Variables:
## // ess-indent-offset: 2
## // End:
