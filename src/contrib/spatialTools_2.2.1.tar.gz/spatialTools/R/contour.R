
## If this package didn't Depend on sf, we might also need to import
## rbind.sf (which is unexported):
## https://stackoverflow.com/q/59647444/980833

##' Compute contour enclosing smallest possible area containing
##' specified proportion of mass in a PDF raster.
##'
##' This function is the one called \code{R2C_stars_PDF()} in my
##' CHHR-estimation project.
##' @title Compute Contour from a PDF Raster
##' @param R A \code{RasterLayer} object representing a density
##'     surface.
##' @param contour A number between \code{0} and \code{1}. The
##'     function will draw a contour around the smallest possible area
##'     containing the proportion of the total density mass of
##'     \code{R} specified by \code{contour}.
##' @return An sf object of type \code{MULTIPOLYGON}.
##' @importFrom stars st_as_stars st_contour
##' @importFrom sf st_geometry
##' @export
##' @author Joshua O'Brien
##' @examples
##' RR <- raster(system.file("external/test.grd", package="raster"))
##' CC <- raster_to_contour(RR, contour = c(0.95, 0.50))
##' plot(CC, col = c("yellow", "red"))
raster_to_contour <- function (R, contour = 0.95) {
    ## For some reason (possibly because it was written with
    ## elevations in mind?) this function fails unless we scale up the
    ## raster values. Rescaling max cell value to between 1000 and
    ## 10000 seems to work just fine.
    log10_ceiling <- function(x) {
        10^(ceiling(log10(x)))
    }
    XX <- 10000/log10_ceiling(maxValue(R))
    R <- R * XX
    ## Carry on...
    PMF <- getValues(R)
    PMF <- sort(PMF, decreasing = TRUE)
    CDF <- cumsum(PMF)
    ii <- sapply(contour,
                 function(cc) match(TRUE, CDF > cc * max(CDF)))
    cont_break <- PMF[ii]
    X <- lapply(cont_break, function(cc) {
        ## b/c we're dealing with a PDF we want the 2nd MULTIPOLYGON,
        ## the one containing densities from cont_break to Inf.
        st_geometry(st_contour(st_as_stars(R), breaks = cc)[2,])
    })
    X <- do.call(c, X)
    st_sf(contour = contour, geom = X)
}
