

##' Find UTM zone of longitude or of a vector or raster object's
##' centroid
##'
##' @title Find UTM Zone of a Longitude or a Spatial Object
##' @param X Either a single number (representing a longitude) or any
##'     vector (sp or sf) or raster object from which
##'     \code{sf::st_bbox()} can extract a bounding box.
##' @param type A character string, \code{"proj4string"} (for a
##'     PROJ4-style character string), \code{"numeric"} (for a number
##'     between 1 and 60), or \code{"epsg"} (for a number between
##'     32601 and 32660). Default value is \code{proj4string}.
##' @return Depending on \code{type}, a number or character string
##'     representing the UTM zone containing the centroid of the
##'     object \code{X}.
##' @export
##' @author Joshua O'Brien
##' @examples
##' ## Find UTM of SLC
##' get_UTM(-111.891, type = "numeric")
##'
##' ## Find suitable UTM for Luxembourg, and
##' LUX <- getSpatialData("lux")
##' UTM_LUX <- get_UTM(LUX)
##' plot(st_geometry(st_transform(LUX, UTM_LUX)))
get_UTM <- function(X, type = c("epsg", "numeric", "proj4string")) {
    type <- match.arg(type)
    if (is.numeric(X)) {
        long <- X
    } else {
        XY <-
            st_envelope(X) %>%
            st_centroid %>%
            st_transform(4326) %>%
            st_coordinates
        long <- XY[,"X"]
    }
    zone <- (floor((long + 180)/6) %% 60) + 1
    STR <- "+proj=utm +zone=%d +datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"
    switch(type,
           epsg = return(32600 + zone),
           numeric = return(zone),
           proj4string = return(sprintf(STR, zone))
           )
}
