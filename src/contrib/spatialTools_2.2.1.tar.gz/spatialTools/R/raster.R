
##' Inspired by code at \url{https://gis.stackexchange.com/a/252893/5720}
##'
##' @title Find the extent of a list of rasters
##' @param rasters A list of rasters
##' @return An Extent object
##' @export
##' @author Joshua O'Brien
extent_all_rasters <- function(rasters){
    Reduce(union, sapply(rasters, raster::extent))
}


##' Inspired by code at \url{https://gis.stackexchange.com/a/252893/5720}
##'
##' @title Sum together well-registered rasters with possibly
##'     different extents
##' @param rasters A list of rasters
##' @param extent Optionally provide an extent over which the rasters
##'     will be summed
##' @return A raster that is the sum of all supplied rasters
##' @export
##' @author Joshua O'Brien
sum_all_rasters <- function(rasters, extent = extent_all_rasters(rasters)){
    re = lapply(rasters, function(r) {raster::extend(r, extent, value = 0)})
    Reduce("+", re)
}


##' An alternative to raster::reclassify()
##'
##' @title Reclassify a continuous raster by cutting at breaks
##' @param x A continuous (non-factor) raster
##' @param breaks An numeric vector of (ordered) breakpoints. It will
##'     often useful to set the first and last values be \code{-Inf}
##'     and \code{Inf}.
##' @param names A vector of names to be given to the categories
##'     defined by \code{breaks}. The vector should have one fewer
##'     element than \code{breaks}.
##' @param ... Additional arguments to be passed on to
##'     \code{raster::reclassify()}.
##' @return A categorical raster, whose RAT includes a column named
##'     \code{"value"} with the values passed in via the \code{names}
##'     argument.
##' @import raster
##' @export
##' @author Joshua O'Brien
##' @examples
##' r <- raster(system.file("external/test.grd", package="raster"))
##' rc <- classify_raster(r, breaks = c(-Inf, 450, 900, 1350, Inf),
##'                       names = c("low", "medium", "high", "highest"))
##' rasterVis::levelplot(rc)
##'
classify_raster <-
    function(x,
             breaks,
             names = LETTERS[seq_len(length(breaks) - 1)],
             ...)
{
    names <- factor(names, levels = names)
    DF <- data.frame(from = breaks[-length(breaks)],
                     to = breaks[-1],
                         names = as.numeric(names))
    X <- as.factor(reclassify(x, DF, ...))
    RAT <- levels(X)[[1]]
    RAT$value <- as.character(names)
    levels(X)[[1]] <- RAT
    X
}


##' Create a template stars raster all of whose vertices are at integer
##' multiples of `res`
##'
##' @title Create a Template stars Raster
##' @param X Raster or vector object for which \code{st_bbox} returns
##'     a bounding box that can be used to define the template
##'     raster's extent.
##' @param res Resolution of the to-be-outputted template raster.
##' @return A template raster all of whose vertices are at integer
##'     multiples of \code{res}.
##' @import stars
##' @export
##' @author Joshua O'Brien
##' @examples
##' r <- raster(system.file("external/test.grd", package="raster"))
##' tidy_template(r, 100)
tidy_template <- function(X, res) {
    round_any <- function(x, accuracy, f = round) {
        f(x/accuracy)*accuracy
    }
    BBOX <- st_bbox(X)
    BBOX <- round_any(BBOX + c(0, 0, res, res), res, floor)
    st_as_stars(BBOX, dx = res, dy = res)
}


##' Warp a RasterLayer to match a template raster or stars object.
##' This function uses \code{stars::st_warp()} & thus
##' \code{gdal_warp()}.
##'
##' @title Warp a RasterLayer to Match a Template
##' @param src A RasterLayer object to be warped
##' @param dest A template (RasterLayer or stars) to guide the warping
##' @param method See \code{stars::st_warp()}.
##' @param use_gdal See \code{stars::st_warp()}.
##' @param ... Additional arguments to \code{stars::st_warp()}.
##' @return A RasterLayer
##' @import stars
##' @export
##' @author Joshua O'Brien
##' @examples
##' r <- raster(system.file("external/test.grd", package="raster"))
##' warp_template <- tidy_template(r, 30)
##' plot(warp_raster(r, warp_template))
warp_raster <- function(src, dest, method = "near", use_gdal = TRUE, ...) {
    dest <- st_as_stars(dest)
    st_as_stars(src) %>%
    st_warp(dest, method = method, use_gdal = use_gdal, ...) %>%
    ## `use_gdal = TRUE` for `method=` other than 'near'
    as("Raster")
}
