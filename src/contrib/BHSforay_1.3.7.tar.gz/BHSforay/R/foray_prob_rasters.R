foray_prob_rasters <- function(RINGS, HAB, FD_ram, FD_ewe,
                               foray_prob_raster_dir,  ...) {
    outfile_ram <- file.path(foray_prob_raster_dir, "ForayPrefRam.tif")
    outfile_ewe <- file.path(foray_prob_raster_dir, "ForayPrefEwe.tif")
    ## Ensure that cells represent habitat prefs (not habitat types)
    if (is.factor(HAB)) {
        HAB <- cat_to_val(HAB)
    }
    ## Compute sums of habitat preference values w/in each ring
    RINGS <- fasterizeDT(RINGS, HAB)
    ring_vals <- zonalDT(HAB, RINGS)
    names(ring_vals) <- c("RING", "pref_total")
    ## In computing a foray probability raster, habitat preferences
    ## within each ring are: (1) normalized by *dividing* by the
    ## ring's total habitat preference; and (2) *multiplied* by the
    ## probabilty a foraying animal will reach the ring. `ram_fact`
    ## and `ewe_fact` combine these two ring-specific multiplicative
    ## factors into one, which is then used to multiply habitat
    ## preferences from HAB in the following code block.
    ring_vals[FD_ram, FP_ram := ForayProb]
    ring_vals[FD_ewe, FP_ewe := ForayProb]
    ring_vals[, ram_fact := (FP_ram / pref_total)]
    ring_vals[, ewe_fact := (FP_ewe / pref_total)]

    if (canProcessInMemory(RINGS, 4)) {
        DT <- data.table(RING = getValues(RINGS),
                         pref = getValues(HAB))
        DT[, ram_prob := ring_vals[DT, ram_fact] * pref]
        writeRaster(setValues(HAB, DT[["ram_prob"]]),
                    filename = outfile_ram, overwrite = TRUE)
        DT[, ewe_prob := ring_vals[DT, ewe_fact] * pref]
        writeRaster(setValues(HAB, DT[["ewe_prob"]]),
                    filename = outfile_ewe, overwrite = TRUE)
    } else {
        tmpfile_ram <- rasterTmpFile()
        tmpfile_ewe <- rasterTmpFile()
        out_ram <- writeStart(HAB, filename = tmpfile_ram,
                              overwrite = TRUE, ...)
        out_ewe <- writeStart(HAB, filename = tmpfile_ewe,
                              overwrite = TRUE, ...)
        tr <- blockSize(out_ram)
        for (i in seq_len(tr$n)) {
            DT <- data.table(RING = getValues(RINGS, row = tr$row[i],
                                              nrows = tr$nrows[i]),
                             pref = getValues(HAB, row = tr$row[i],
                                              nrows = tr$nrows[i]))
            DT[, ram_prob := ring_vals[DT, ram_fact] * pref]
            out_ram <- writeValues(out_ram, DT[["ram_prob"]], tr$row[i])
            DT[, ewe_prob := ring_vals[DT, ewe_fact] * pref]
            out_ewe <- writeValues(out_ewe, DT[["ewe_prob"]], tr$row[i])
        }
        out_ram <- writeStop(out_ram)
        out_ewe <- writeStop(out_ewe)
        writeRaster(out_ram, filename = outfile_ram, overwrite = TRUE)
        writeRaster(out_ewe, filename = outfile_ewe, overwrite = TRUE)
    }
}
