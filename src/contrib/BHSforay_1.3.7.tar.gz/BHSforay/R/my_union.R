
##' An \code{sf}-based version of
##' \code{\link[raster:union]{raster::union()}}.
##'
##' @title Return the Union of Two sf Polygon Layers
##' @param X an \code{\link[sf:sf]{sf::sf()}} object with a geometry
##'     column of \code{POLYGON} and/or \code{MULTIPOLYGON} objects.
##' @param Y an \code{\link[sf:sf]{sf::sf()}} object with a geometry
##'     column of \code{POLYGON} and/or \code{MULTIPOLYGON} objects.
##' @param fx Character string giving the column in \code{X} to be
##'     used as an id variable
##' @param fy Character string giving the column in \code{Y} to be
##'     used as an id variable
##' @return an \code{sf::sf()} object with a geometry column of
##'     \code{POLYGON} and/or \code{MULTIPOLYGON} objects, an ID
##'     column, and columns relating to \code{fx} and \code{fy}.
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
my_union <- function(X, Y, fx, fy) {
    ## Only carry through selected index field
    X <- X[fx]
    Y <- Y[fy]
    ## Ensure that both objects share same geometry column name
    X <- st_sf(st_drop_geometry(X), geometry = st_geometry(X))
    Y <- st_sf(st_drop_geometry(Y), geometry = st_geometry(Y))
    ## Set up template sf object (with desired ordering of fields)
    Z <- st_sf(x = character(0),
               y = character(0),
               geometry = st_sfc(),
               crs = st_crs(X))
    names(Z)[1:2] <- c(fx, fy)
    ## Extract three types of fragments
    A <- suppressWarnings(st_intersection(X, Y))
    B <- suppressWarnings(st_difference(X, st_union(Y)))
    B[[fy]] <- rep(NA, nrow(B))
    C <- suppressWarnings(st_difference(Y, st_union(X)))
    C[[fx]] <- rep(NA, nrow(C))
    ## Put all the pieces together
    x <- rbind(Z, A, B, C)
    ## Filter out LINESTRING, MULTILINESTRING objects, etc.
    x <- x[st_is(x, c("POLYGON", "MULTIPOLYGON")), ]
    x <- cbind(ID = seq_len(nrow(x)), x)
    rownames(x) <- NULL
    x
}
