load_raster_layer <- function(obj) {
    if (inherits(obj, "Raster")) {
        return(obj)
    }
    if (is.character(obj)) {
        return(raster(obj))
    }
}
