Yellow_to_Green_to_Dark_Blue <-
    c("#FFFF80", "#E3FC6F", "#C4F75E", "#A5F24E", "#87ED3E",
      "#66E82A", "#45E314", "#3BD929", "#3DCC42", "#3DBF5C",
      "#3BB373", "#33A687", "#279A9C", "#1B8CA8", "#2074A1",
      "#225D99", "#204A91", "#1D368A", "#162280", "#0D1178")


## jobTools::displayPalette(Yellow_to_Green_to_Dark_Blue,
##                          border = "transparent")
##
## scales::show_col(Yellow_to_Green_to_Dark_Blue)
