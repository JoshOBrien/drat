##-----------------------------##
##  ALLOTMENTS UPLOAD TAB: UI  ##
##-----------------------------##
tabPanel("Allotments",
  fluidPage(
    fluidRow(
      column(1),
        column(10, align = "center",
          ## Allotment file type selection (SHP or GDB)
          radioButtonBoxes(inputId = "ALLOTS_file_type", label = "",
                           choices = c("ALLOTS from shapefile" = "shp",
                                       "ALLOTS from GDB" = "gdb"),
                           selected = character(0))
          ),
      column(1),
      br(), br(), br()
    ),
    ## Allotments shapefile upload
    fluidRowWidgetCheck(
      hidden(actionButton("upload_ALLOTS_shp",
                          "Upload Allotments shapefile",
                          width = "100%")),
      span(greyDash("dash_ALLOTS_shp"),
           greenCheck("check_ALLOTS_shp"))
    ),

    hidden(div(id = "upload_ALLOTS_gdb",
      ## Allotments GDB directory selection
      fluidRowWidgetCheck(
        actionButton("select_ALLOTS_GDB_path",
                     "Select GDB containing Allotment layer",
                     width = "100%"),
        span(greyDash("dash_ALLOTS_GDB_path"),
             greenCheck("check_ALLOTS_GDB_path"))
      ),
      ## Allotments GDB layer selectors
      fluidRowWidgetCheck(
        selectizeInput("select_ALLOTS_GDB_layer", label = "",
                       choices = "", selected = "",
                       options = list(
                         placeholder = "Select allotment layer",
                         onInitialize=I('function() { this.setValue(""); }')),
                       width = "100%"),
        span(greyDash("dash_ALLOTS_GDB_layer", yShift = -12),
             greenCheck("check_ALLOTS_GDB_layer", yShift = -12))
      )
      )),

      ## Allotment ID column selector
      fluidRowWidgetCheck(
        selectizeInput("ALLOTS_ID_column", label = "",
                       choices = "", selected = "",
                       options = list(
                         placeholder = "Select allotment ID column",
                         onInitialize=I('function() { this.setValue(""); }')),
                       width = "100%"),
        span(greyDash("dash_ALLOTS_ID_column", yShift = -12),
             greenCheck("check_ALLOTS_ID_column", yShift = -12))
      ),

    fluidRow(
      br(),
      column(12, align = "center",
        ## Display info about loaded Allotments
        div(align = "left", verbatimTextOutput("ALLOTS_info"))
        )
    )
  ))


## // Local Variables:
## // ess-indent-offset: 2
## // End:
