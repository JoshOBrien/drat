
##' @export
write_parameters_txt <- function(params, outputDir) {
    ## Prepare message for start of file
    message <-
'## This file records the data files and parameters used in the
## Risk of Contact Analysis whose results are stored in this
## directory.
##
## To reproduce the analysis whose results are stored in this
## folder, run code like the following from an R session on the
## computer on which the analysis was first performed:
##
## library(BHSRoCTGUI)
## scenarioDir <- "/path/to/this/directory"
## ## For example
## ## scenarioDir <- "%s"
## setwd(scenarioDir)
## params <- read_yaml("parameters.txt")
## do.call(compute_ROCT, params)

'
    message <- sprintf(message, outputDir)
    ## Prepare the YAML section
    tmp <- tempfile()
    write_yaml(params, tmp)
    ## Write message then YAML to "parameters.txt"
    outFile <- file.path(outputDir, "parameters.txt")
    cat(message, file = outFile)
    cat(readLines(tmp), sep = "\n", file = outFile, append = TRUE)
}

## ## Usage:
## outputDir <- "C:/Users/Josh/Desktop"
## params <- list(a=1:10, b=month.name)
## write_parameters_txt(params, outputDir)
