
##' @export
forayDistanceFileSummary <-
    function(sex = c("Ram", "Ewe"), path)
{
    template <-
        paste("%s foray distance file summary:\n",
              "  - File path:  %s\n",
              "  - Rows (km):  %s\n")

    ## Extract info about foray distance file
    FD <- data.table::fread(path)
    rows <- nrow(FD)

    ## Plug info into template and print it out
    cat(sprintf(template,
                sex,
                dQuote(path),
                rows))
}

## ## Example usage
##
## RV <- list(RFD_path = "C:/Users/Josh/Desktop/GUI-Foray-Contact/sampleData/defaults/Ram_summer_foray_dist_35.csv",
##            EFD_path = "C:/Users/Josh/Desktop/GUI-Foray-Contact/sampleData/defaults/Ewe_summer_foray_dist_35.csv")##
## forayDistanceFileSummary(sex = "Ram", path = RV$RFD_path)
## forayDistanceFileSummary(sex = "Ewe", path = RV$EFD_path)



