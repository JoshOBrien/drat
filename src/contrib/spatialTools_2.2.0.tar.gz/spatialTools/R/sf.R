##' Get bounding box for a set of features
##'
##' @title Get bounding box for a set of features
##' @param ... sf features
##' @return An object of class \code{bbox}.
##' @export
##' @author Joshua O'Brien
##' @seealso \code{\link{st_envelope}}
##' @examples
##' if (require(sfheaders)) {
##' p1 <- sfheaders::sf_polygon(matrix(10*runif(6), nc = 2))
##' p2 <- sfheaders::sf_polygon(matrix(10*runif(6), nc = 2))
##' p3 <- sfheaders::sf_polygon(matrix(10*runif(6), nc = 2))
##' st_bbox_overall(p1, p2, p3)
##' ## Convert to sf POLYGON (or, better, use st_envelope())
##' st_sf(st_as_sfc(st_bbox_overall(p1, p2, p3)))
##' }
st_bbox_overall <- function(...) {
    bbox_as_sfc <- function(X) {
        st_as_sfc(st_bbox(X))
    }
    XX <- lapply(list(...), bbox_as_sfc)
    st_bbox(do.call(c, XX))
}


##' Create a spatial rectangle to clip region around sf object
##'
##' @title Create a spatial rectangle to clip region around sf object
##' @param ... sf features
##' @param buf Distance, in units of CRS, by which to buffer sf
##'     features' collective bounding box
##' @return An \pkg{sf} object with a \code{POLYGON} geometry
##'     delineating the buffered bounding box of the supplied \pkg{sf}
##'     objects.
##' @importFrom sf st_drop_geometry st_coordinates st_bbox
##' @importFrom sf st_as_sfc st_as_sf st_buffer
##' @export
##' @author Joshua O'Brien
##' @examples
##' if (require(sfheaders)) {
##' p1 <- sfheaders::sf_polygon(matrix(10*runif(6), nc = 2))
##' p2 <- sfheaders::sf_polygon(matrix(10*runif(6), nc = 2))
##' p3 <- sfheaders::sf_polygon(matrix(10*runif(6), nc = 2))
##' ee <- st_envelope(p1, p2, p3, buf = 0.1)
##' plot(ee)
##' plot(p1, col = adjustcolor("red", alpha = 0.5), add = TRUE)
##' plot(p2, col = adjustcolor("blue", alpha = 0.5), add=TRUE)
##' plot(p3, col = adjustcolor("yellow", alpha = 0.5), add=TRUE)
##' }
st_envelope <- function(..., buf = 0) {
    st_bbox_overall(...) %>%
        st_as_sfc() %>%
        st_buffer(buf) %>%
        st_bbox() %>%
        st_as_sfc() %>%
        st_as_sf()
}


## Distantly inspired by
## https://github.com/r-spatial/sf/issues/231#issuecomment-290817623
##
##' Convert sf object to a data.frame with each coordinate a column
##'
##' @title Convert sf object to a data.frame with each coordinate a
##'     column
##' @param x A simple features object
##' @return A \code{data.frame}
##' @export
##' @author Joshua O'Brien
##' @examples
##' nc <- st_read(system.file("shape/nc.shp", package = "sf"))
##' sf_to_df(st_centroid(nc[1:5,]))
sf_to_df <- function(x) {
    stopifnot(inherits(x, "sf") &&
              inherits(sf::st_geometry(x), "sfc_POINT"))
    cbind(st_drop_geometry(x), st_coordinates(x))
}


##' Utility function for converting any MULTISURFACE to MULTIPOLYGON
##'
##' For an example, see
##' \url{https://gis.stackexchange.com/a/389854/5720}.
##' @title Convert any MULTISURFACE to MULTIPOLYGON
##' @param X A simple features object consisting of MULTIPOLYGON
##'     and/or MULTISURFACE objects
##' @return A simple features object with only MULTIPOLYGON objects in
##'     its geometry column
##' @importFrom gdalUtilities ogr2ogr
##' @export
##' @author Joshua O'Brien
ensure_multipolygons <- function(X) {
    types <- st_geometry_type(X)
    if (!all(types %in% c("MULTIPOLYGON", "MULTISURFACE"))) {
        stop("All features must by of type 'MULTIPOLYGON' or 'MULTISURFACE'")
    }
    if (all(types == "MULTIPOLYGON")) {
        return(X)
    }
    tmp1 <- tempfile(fileext = ".gpkg")
    tmp2 <- tempfile(fileext = ".gpkg")
    st_write(X, tmp1)
    ogr2ogr(tmp1, tmp2, f = "GPKG", nlt = "MULTIPOLYGON")
    Y <- st_read(tmp2)
    st_sf(st_drop_geometry(X), geom = st_geometry(Y))
}


##' Construct segments from sf POINTS object
##'
##' @title Convert sf POINTS to LINESTRING of trajectory segments
##' @param PTS An \pkg{sf} \code{POINTS} object, with points from one
##'     animal arranged in order of increasing time.
##' @param seg_length Number of segments to include in each
##'     \code{LINESTRING}. Default is 1.
##' @return A \code{LINESTRING} object, with each segment a straight line
##'     between two consecutive telemetry relocations.
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
st_points_to_segments <- function(PTS, seg_length = 1) {
    ## Prepare list of index vectors
    nn <- seg_length
    ii <- seq_len(nrow(PTS))
    f <- function(ii, nn) {
        ngroup <- ceiling(length(ii)/nn)
        ff <- function(group) {
        ## seq(from = 1, to = min(group * nn, length(ii)))
            seq(from = max((group - 1)*nn + 1, 1),
                to   = min(group*nn + 1, length(ii)))
        }
        lapply(seq_len(ngroup), ff)
    }
    ii <- f(ii, nn)
    ii <- ii[sapply(ii, length) != 1]
    ## Construct geometry column containing line segments
    GEOM <- lapply(ii, function(i) {
        st_cast(st_combine(PTS[i,]), "LINESTRING")
    })
    GEOM <- do.call(c, GEOM)
    ## Extract attribute columns
    DF <- st_drop_geometry(PTS)[sapply(ii, tail, 1),]
    ## Recombine to form sf object
    st_sf(DF, geom = GEOM)
}
