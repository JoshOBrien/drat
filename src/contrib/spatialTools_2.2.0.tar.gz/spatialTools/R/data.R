
##' Utility function for quickly accessing spatial datasets shipped
##' with standard R spatial packages.
##'
##' \code{"lux"}, \code{"boston_tracts"}, \code{"NY8"}, and
##' \code{"nc"} are \code{SpatialPolygonsDataFrame}s, \code{"pointZ"}
##' is a \code{SpatialPointsDataFrame}. \code{"test_raster"} and
##' \code{"rlogo_brick"} are from the \pkg{raster} package.
##' @title Easy access to spatial data
##' @param layer Name of spatial dataset. One of \code{"lux"},
##'     \code{"boston_tracts"}, \code{"NY8"}, \code{"pointZ"},
##'     \code{"test_raster"}, or \code{"rlogo_brick"}.
##' @return An R spatial object.
##' @export
##' @author Joshua O'Brien
##' @examples
##' plot(getSpatialData("lux"))
getSpatialData <-
    function(layer = c("lux", "boston_tracts", "NY8", "nc", "pointZ",
                       "test_raster", "rlogo_brick"))
{
    layer <- match.arg(layer)
    switch(layer,
           lux = st_read(system.file("external/lux.shp",
                                     package = "raster")),
           boston_tracts = st_read(system.file("etc/shapes/boston_tracts.shp",
                                               package = "spdep")),
           NY8 = st_read(system.file("etc/shapes/NY8_utm18.shp",
                                     package = "spdep")),
           nc = st_read(system.file("shape/nc.shp",
                                    package = "sf")),
           pointZ = st_read(system.file("shapes/pointZ.shp",
                                        package = "maptools")),
           test_raster = raster(system.file("external/test.gri",
                                            package = "raster")),
           rlogo_brick = brick(system.file("external/rlogo.gri",
                                            package = "raster"))
           )
}
