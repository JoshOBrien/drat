
##' Calculate a herd-level bounding box and then use a kernel density
##' estimator (kde) to calculate each animal's utilization
##' distribution.
##'
##' MORE TO COME FOR DETAILS SECTION
##'
##' @title Calculate kernel density estimates for all animals in a
##'     herd.
##' @export
##' @seealso \code{\link{kdeOneAnimal}}
##' @param dsn Either a \code{SpatialPointsDataFrame} or a character
##'     string containing a path name or a length-two character
##'     vector.  If a \code{SpatialPointsDataFrame}, no
##'     \code{layerName} argument is needed. If a character string,
##'     for Esri shapefiles, the string identifies the directory
##'     containing the file. For Esri personal geodatabases, the path
##'     identifies the database itself (including the \code{".mdb"}
##'     extension). \code{"dsn"} stands for \dQuote{data source name},
##'     and is handed to an argument of the same name in the function
##'     \code{\link[rgdal:readOGR]{rgdal::readOGR()}}. Finally, if a
##'     length-two character vector, the vector is split in two, with
##'     the first element taken to be the \code{dsn} value (as above) and the
##'     second taken to be the value of \code{layerName} (described
##'     below).
##' @param layerName A character string naming the layer that contains
##'     the telemetry points for a herd. (\code{layerName} is passed
##'     on to the argument \code{layer} in
##'     \code{\link[rgdal:readOGR]{rgdal::readOGR()}})
##' @param animalIDcol A character string naming the attribute table
##'     column used to identify the animals in a herd.
##' @param buffer Numeric. Gives the width (in meters) of a buffer
##'     used to extend the region for which the kernel density raster
##'     will be calculated. If set to \code{0}, density will be
##'     calculated only for the minimal bounding box containing all of
##'     the telemetry points from animals in a herd.
##' @param cellsize A single number setting the dimensions (width and
##'     height in meters) of the raster cells used to map the
##'     utilization distributions.
##' @param whichAnimals An integer vector or a character vector. In
##'     either case, the vectors are used to index a list of the
##'     animals in a herd, identifying a subset for whom kernel
##'     density estimation should be performed. The default value,
##'     \code{"all"}, selects all animals in a herd for further
##'     processing.
##' @param aggregatePoints Should the points from individual animals
##'     all be pooled and analyzed together? Default value is
##'     \code{FALSE}, in which case a separate utilization density
##'     raster is calculated for each animal.
##' @param minObs An integer. Sets the minimum number of observations
##'     of an animal necessary for its inclusion in home range size
##'     calculations. Default value is \code{5}.
##' @param bwEstimator A character string. Names the bandwidth
##'     estimator used to determine the degree of smoothing applied by
##'     the kde() function. Must be either \code{"Hpi"} (the plug-in
##'     estimator of Sheather and Jones (1991)), or one of three
##'     flavors of \code{"Href"} (the \dQuote{reference} bandwidth
##'     estimator described in Fieberg (2007), and used in the
##'     analyses described in the Payette NF's 2010
##'     FSEIS). \code{"Href"}, \code{"Href_diag"}, and
##'     \code{"Href_full"} produce, respectively, a fully symmetric
##'     kernel, a kernel that is stretched along its N-S or E-W axis,
##'     and a kernel that may be stretched in any direction. The
##'     current default is \code{"Hpi"}.
##' @param bwMultiplier A single real number, used to multiply the
##'     bandwidth estimated by \code{Hpi()} or \code{Href()}. Values
##'     \code{> 1} produce more highly smoothed density maps; values
##'     \code{< 1} produce maps in which the density is more highly
##'     peaked around observed points. Default value is \code{1} (no
##'     broadening or narrowing of the bandwidth estimated by the
##'     algorithm specified in the \code{bwEstimator} argument).
##' @param cont A numeric vector (e.g. \code{c(0.5, 0.75, 0.95)}, or
##'     \code{0.90}).  Indicates the levels at which isopleth contours
##'     are to be calculated. The default value, \code{0.95} finds a
##'     contour that surrounds the smallest area containing
##'     \code{95\%} of the probability mass on the density map.
##' @param outputDir A character string giving the output directory
##'     for GeoTiff files (if \code{outputType="tiff"}) or polygon
##'     shapefiles (if \code{outputType="poly"}).
##' @param logFile A character string giving the location of the
##'     session-specific log-file. Defaults to \code{"BHSkde_log.txt"}
##'     in current directory.
##' @param outputType A character string determining the default
##'     output data type. Can be one of \code{"rawpoints"},
##'     \code{"plotdata"}, \code{"kde"}, \code{"sgdf"}, \code{"tiff"},
##'     \code{"raster"}, \code{"sldf"}, \code{"spdf"}, or
##'     \code{"poly"}.  \code{outputType}s \code{"tiff"} and
##'     \code{"raster"} write data to files: all others return
##'     \bold{R} list objects, each element of which corresponds to a
##'     single animal (if \code{aggregatePoints} is \code{FALSE}) or
##'     to the aggregated data (if \code{aggregatePoints} is
##'     \code{TRUE}).
##'
##'   Options that write data to files in the directory specified
##'   by \code{outputDir}:
##'   \describe{
##'     \item{\code{"tiff"}:}{Writes estimated utilization distributions
##'       to GeoTiff raster files.}
##'     \item{\code{"poly"}:}{Writes estimated CHHR boundaries to polygon
##'       shapefiles.}
##'   }
##'
##'   Options that create R list objects
##'   \describe{
##'     \item{\code{"rawpoints"}:}{Returns a list of SpatialPoints objects,
##'       each of which contains telemetry data from one animal.}
##'     \item{\code{"kde"}:}{Items are rasters of class \code{"kde"},
##'      representing utilization distributions (UDs) of individual animals}
##'     \item{\code{"raster"}:}{Items are rasters of class
##'       \code{"raster"}, representing estimated UDs of individual animals}
##'     \item{\code{"sgdf"}:}{Items are rasters of class
##'       \code{"SpatialGridDataFrame"}, representing estimated
##'       UDs of individual animals}
##'     \item{\code{"sldf"}:}{Items are contours of estimated CHHRs, of class
##'       \code{"SpatialLinesDataFrame"}.}
##'     \item{\code{"spdf"}:}{Items are contours of estimated CHHRs, of class
##'       \code{"SpatialPolygonsDataFrame"}.}
##'     \item{\code{"plotdata"}:}{Dummy dummy.}
##'   }
##' @return Depends on which outputType has been selected.
##' @seealso \code{\link[rgdal:readOGR]{rgdal::readOGR()}}
##' @examples
##' \dontrun{
##' ## Load data from a personal geodatabase
##' ## (Warning: requires R.version >= R-2.15.0 (i.e. R-devel)
##' SLDF <-
##' kdeAllAnimals(dsn = file.path(mdbDir, "R_Personal.mdb"),
##'              layerName = "testfull",
##'              animalIDcol = "Animal_ID",
##'              whichAnimals = 1:3,
##'              outputType = "sldf")
##'
##' # Load data from shapefiles using any version of R
##' SLDF <-
##' kdeAllAnimals(dsn=system.file("GISdata/shape-files", package="BHSkde"),
##'              layerName = "testfull",
##'              animalIDcol = "Animal_ID",
##'              whichAnimals = 1:3,
##'              outputType = "sldf")
##'
##' ## Write out polygon shapefiles containing the default 95th
##' ## isopleths for three animals in the Asotin herd.
##' ##
##' ## NOTE: Before running this, make sure to first create the
##' ## directory specified in the "outputFile" argument of the call
##' ## to kdeHerd().
##' kdeAllAnimals(dsn=system.file("GISdata/shape-files", package="BHSkde"),
##'               layerName = "testfull",
##'               animalIDcol = "Animal_ID",
##'               whichAnimals = 1:3,
##'               outputType = "poly",
##'               outputDir = "Asotin-polygons")
##'
##' }
##' @author Josh O'Brien
kdeAllAnimals <- function(dsn = system.file("GISdata/shape-files", package="BHSkde"),
                          layerName = "testfull",
                          animalIDcol = "Animal_ID2",
                          buffer = 5000, # buffer size in meters.
                          cellsize = 100,
                          whichAnimals = "all",
                          aggregatePoints = FALSE,
                          minObs = 5,
                          bwEstimator = "Hpi",
                          bwMultiplier = 1,
                          cont = 0.95,
                          outputType = "tiff",
                          outputDir = ".",
                          logFile = "dummy.log"){
    ## Check this first, before any other calculations!
    outTypes <- c("rawpoints", "plotdata", "kde", "sgdf", "tiff",
                  "raster", "sldf", "spdf", "poly")
    if(!tolower(outputType) %in% outTypes) {
        msg <- paste('outputType must be one of:\n       ',
                     paste(paste('"', outTypes, '"', sep=""), collapse=", "))
        stop(msg)
    }

    ## Read in the telemetry data, and return a list containing
    ## both a list of points (per animal), and the attributes
    ## of the grid over which we want to estimate the density surface.
    dat <- makePointsListAndGridArgs(dsn = dsn,
                                     layerName = layerName,
                                     animalIDcol = animalIDcol,
                                     whichAnimals = whichAnimals,
                                     aggregatePoints = aggregatePoints,
                                     minObs = minObs,
                                     cellsize = cellsize,
                                     buffer = buffer)
    BHSptsList <- dat$BHSptsList
    gridArgs <- dat$gridArgs

    nms <- names(BHSptsList)

    cat(paste("Calculating individual-level", outputType, "for", length(nms), "animals:"),
        file = logFile, sep = "\n", append = TRUE)
    resultsList <-
    sapply(nms, function(nm) {
        cat(paste("  Processing animal '", nm, "'   .....   ", sep = ""),
            file = logFile, append = TRUE)
        res <-
            kdeOneAnimal(BHSpts = BHSptsList[nm],
                         BHSname = nm,
                         outputType = outputType,
                         gridArgs = gridArgs,
                         bwEstimator = bwEstimator,
                         bwMultiplier = bwMultiplier,
                         cont = cont,
                         outputDir = outputDir)
        cat("Complete.\n", file = logFile, append = TRUE)
        res
    }, simplify = FALSE, USE.NAMES = TRUE)
    return(resultsList)
}

##' Read point data from Esri shapefile or personal geodatabase data
##' into an R SpatialPointsDataFrame.
##'
##' MORE LATER. In particular, it'll be worth noting that data in
##' personal geodatabases can only be read in by R-2.15.0 or later
##' (coming in April 2012).
##' @title Read Esri point data into a SpatialPointsDataFrame
##' @inheritParams kdeAllAnimals
##' @return A SpatialPointsDataFrame object containing telemetry
##'     location data for all animals in the selected herd.
##' @author Josh O'Brien
readGISdata <- function(dsn, layerName, animalIDcol) {
    BHSpts <- readOGR(dsn, layerName)
    return(BHSpts)
}

##' TITLE A helper function for kdeAllAnimals
##'
##' DESCRIPTION A helper function for kdeAllAnimals
##' @title A helper function for kdeAllAnimals
##' @param BHSpts A SpatialPointsDataFrame containing all telemetry
##'     points for a herd (read in by readGISdata()).
##' @inheritParams kdeAllAnimals
##' @return BHSptsList
##' @author Josh O'Brien
makePointsList <- function(BHSpts,
                           animalIDcol,
                           whichAnimals,
                           aggregatePoints,
                           minObs) {
    ## (2) Split telemetry points into a list of data.frames, each
    ##     one containing points from a single animal, after which
    ##     it is named.
    ##
    ## TODO: The following needs additional tests of integer and
    ## character vectors, to determine whether they can in fact
    ## index BHSptsList.

    IDcol_present <- animalIDcol %in% names(BHSpts)

    if(!IDcol_present & !aggregatePoints) {
        stop("Supplied animalIDcol does not match any fields in spatial data")
    }
    if(IDcol_present) {
        BHSptsList <- split(BHSpts, BHSpts[[animalIDcol]])
        names(BHSptsList) <-
            sapply(BHSptsList, function(X) {
                as.character(unique(slot(X, "data")[[animalIDcol]]))
            })
        ## Unless "all" animals selected, get subset of those listed
        ## in whichAnimals
        if(whichAnimals[1] != "all") {
            BHSptsList <- BHSptsList[whichAnimals]
        }
        ## Optionally lump all points from a herd, as was done in the
        ## Payette NF's DSEIS. MIGHT be useful for datasets with few
        ## points for each animal, or if metadata identifying
        ## individual animals are not available.
        if(aggregatePoints) {
            BHSptsList <- do.call(rbind, BHSptsList)
            BHSptsList <- list("all" = BHSptsList)
        }
    }
    if(!IDcol_present & aggregatePoints) {
        BHSptsList <- list("all" = BHSpts)
    }
    ## Only keep animals for whom more than minObs observations are available.
    nObs <- sapply(BHSptsList, function(X)  nrow(as.data.frame(X)))
    BHSptsList <- BHSptsList[nObs >= minObs]
    return(BHSptsList)
}

##' A helper function for kdeAllAnimals
##'
##' DESCRIPTION A helper function for kdeAllAnimals
##' @title A helper function for kdeAllAnimals
##' @inheritParams kdeAllAnimals
##' @return A list containing the BHSptsList and gridArgs used in all further calculations
##' @examples
##' \dontrun{
##' BHSpts <- BHSkde:::makePointsListAndGridArgs(
##'     dsn=system.file("GISdata/shape-files", package="BHSkde"),
##'     layerName = "testfull",
##'     animalIDcol = "Animal_ID",
##'     whichAnimals = "all",
##'     aggregatePoints = FALSE,
##'     minObs = 5,
##'     cellsize = 100,
##'     buffer = 5000)
##' }
##' @author Josh O'Brien
makePointsListAndGridArgs <-
    function(dsn,
             layerName,
             animalIDcol,
             whichAnimals,
             aggregatePoints,
             minObs,
             cellsize,
             buffer) {
        ## (1) Read in all telemetry points.
        if (is(dsn, "SpatialPointsDataFrame")) {
            BHSpts <- dsn
        } else {
            BHSpts <- readGISdata(dsn = dsn, layerName = layerName,
                                  animalIDcol = animalIDcol)
        }
        BHSptsList <- makePointsList(BHSpts = BHSpts,
                                     animalIDcol = animalIDcol,
                                     whichAnimals = whichAnimals,
                                     aggregatePoints = aggregatePoints,
                                     minObs = minObs)
        gridArgs <- getGridArgs(BHSpts = BHSpts,
                                cellsize = cellsize,
                                buffer = buffer)
        return(list(BHSptsList = BHSptsList, gridArgs = gridArgs))
    }

##' Utility function to determine the size & grain of the raster
##' calcuated by kde
##'
##' MORE LATER
##' @title Calculate the extent of the raster to be calculated by kde()
##' @inheritParams kdeAllAnimals
##' @return A list, containing info on the bounding box, projection,
##'   cellsize, and grid extent to be used by kde.
##' @author Josh O'Brien
getGridArgs <- function(BHSpts, cellsize, buffer) {
    ##==================================#
    ## Extract spatial metadata         #
    ## (projection, bounding box, etc.) #
    ##==================================#
    prj <- crs(BHSpts)   # CRS object
    BB  <- bbox(BHSpts)  # matrix of min and max coordinates
    ## Increase extent of bounding
    BB[, "min"] <- BB[, "min"] - buffer
    BB[, "max"] <- BB[, "max"] + buffer
    BB[, "min"] <- (floor(BB[,"min"]/cellsize) * cellsize)
    BB[, "max"] <- (ceiling(BB[,"max"]/cellsize) * cellsize)
    gridsize <- (diff(t(BB))/cellsize)
    ## Return a list containing useful metadata.
    list(BB=BB, prj=prj, gridsize=gridsize, cellsize=cellsize)
}


