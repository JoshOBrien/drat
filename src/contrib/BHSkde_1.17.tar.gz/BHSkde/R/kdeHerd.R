##' Combine kernel density estimates from animals in a herd to form a
##' common kde and estimated isopleths (including CHHR) for the herd
##' as a whole.
##'
##' MORE LATER
##' @title Kernel Density Estimates and CHHR for an entire herd.
##' @export
##' @inheritParams kdeAllAnimals
##' @param outputType A character vector determining the default
##'     output data type(s). Can include one or both of \code{"tiff"}
##'     and \code{"poly"} and/or one of \code{"plotdata"},
##'     \code{"raster"}, \code{"sgdf"}, \code{"sldf"}, or
##'     \code{"spdf"}.  (See Details for more information.)
##' @param outputFile A character string giving the root of the
##'     filename (i.e. without a file extension) to which an file
##'     results will be saved. It's suggested to set this to
##'     \code{"<herdname>Herd"}, where \code{"<herdname>"} is the name
##'     of the herd being analyzed.  Default value is \code{"CHHR"}.
##' @param BHSTool_logFile Should we create a logFile of the form and
##'     in the location expected by the \dQuote{Bighorn Sheep Risk of
##'     Contact Tool}? Default is \code{FALSE}. If \code{TRUE}, a
##'     logFile named \code{"BHSkde_<timestamp>.log"} is stored in the
##'     directory \file{../logs/}.
##' @return Depends on choice of \code{ouputType}
##'
##' @examples
##' \dontrun{
##'
##' ## Return a list of plottable data for the first three animals
##' ## in the Asotin herd.
##' d <- kdeHerd(dsn = system.file("GISdata/shape-files",
##'              package = "BHSkde"),
##'              layerName = "testfull",
##'              animalIDcol = "Animal_ID",
##'              whichAnimals = 1:3,
##'              outputType = "plotdata",
##'              outputDir = "Asotin-polygons",
##'              outputFile = "AsotinHerd")
##' library(BHSkdeVis)
##' plotAnimalHR(1, list(d))
##'
##' ## Calculate CHHR based on data from all animals in the Asotin
##' ## herd and save the output to an Esri polyogons shapefile.
##' ## The default bandwidth estimator ("Hpi") and default 95th
##' ## 95th isopleth are used in the CHHR calculations.
##' ##
##' ## NOTE: Before running this, make sure to first create the
##' ## directory specified in the "outputFile" argument of the call
##' ## to kdeHerd().
##' ##
##' kdeHerd(dsn = system.file("GISdata/shape-files",
##'              package = "BHSkde"),
##'              layerName = "testfull",
##'              animalIDcol = "Animal_ID",
##'              whichAnimals = "all",
##'              outputType = "poly",
##'              outputDir = "Asotin-polygons",
##'              outputFile = "AsotinHerd")
##' }
##' @author Josh O'Brien
kdeHerd <- function(dsn = system.file("GISdata/shape-files", package="BHSkde"),
                    layerName = "testfull",
                    animalIDcol = "Animal_ID2",
                    buffer = 5000,  # buffer size in meters
                    cellsize = 100,
                    whichAnimals = "all",
                    aggregatePoints = FALSE,
                    minObs = 5,
                    bwEstimator = "Hpi",
                    bwMultiplier = 1,
                    cont = 0.95,
                    outputType,
                    outputDir = ".",
                    outputFile = "CHHR",
                    logFile = "BHSkde.log",
                    BHSTool_logFile = FALSE)
{

    ## Create logfile, set up a connection to it, and ensure that
    ## connection will be closed even if R or call evaluation fails.
    if(BHSTool_logFile) {
        logFileTime <- paste("BHSkde_",
                             format(Sys.time(), "%Y-%m-%d_%H-%M-%S"),
                             ".log", sep="")
        logFile <- file.path(outputDir, "../logs", logFileTime)
        file.create(logFile)                ## Create file
        logFile <- file(logFile, open="a+") ## Create append/read-capable cnxn
    } else {
        logFile <- file() # Anonymous file, following sugg. in ?textConnection
    }
    on.exit(close(logFile))                 ## Ensure that connection closes

    ## A function to write Traceback information to logFile
    ## following a crash.
    ## (Is this triggered _before_ on.exit() closes the connection?)
    dumpTraceback <- function() {
        cat("---------------------------------------------------------",
            "---------------------------------------------------------",
            "## BHSkde failed with an error. The following 'traceback'",
            "## shows the sequence of calls that led to the last",
            "## uncaught error:",
            "---------------------------------------------------------",
            "---------------------------------------------------------\n",
            capture.output(traceback()),
            "\n---------------------------------------------------------",
            "---------------------------------------------------------",
            sep = "\n",
            file = logFile)
    }
    options(error = dumpTraceback)

    ## Startup message and timestamp
    pkgDesc <- packageDescription("BHSkde")
    cat("Calculations using:", "\n",
        "   R executable at ", R.home(), "\n",
        "   BHSkde package version ", pkgDesc[["Version"]],
        ", compiled on ", pkgDesc[["Date"]], "\n\n",
        file = logFile)
    cat(timestamp(prefix = "Start time:           ",
                  suffix = "\n\n", quiet = TRUE),
        file = logFile)

    ## Allow users to supply dsn and layerName as length-two vector to
    ## "dsn=" argument
    if(length(dsn) == 2 & missing(layerName)) {
        layerName <- dsn[[2]]
        dsn <- dsn[[1]]
    }

    ## Pass on all arguments to kdeAllAnimals(),
    ## which will output a list of raster files.
    d <- kdeAllAnimals(dsn = dsn,
                       layerName = layerName,
                       animalIDcol = animalIDcol,
                       buffer = buffer,
                       cellsize = cellsize,
                       whichAnimals = whichAnimals,
                       aggregatePoints = aggregatePoints,
                       minObs = minObs,
                       bwEstimator = bwEstimator,
                       bwMultiplier = bwMultiplier,
                       cont = cont,
                       outputType = "plotdata",
                       outputDir = outputDir,
                       logFile = logFile)

    ## Rearrange the returned data
    rast <- lapply(d, "[[", "rast")
    sldf <- lapply(d, "[[", "sldf")
    pts  <- lapply(d, "[[", "pts")

    ## Combine the kde's, and then operate on the combined kde.
    cat("\nCombining individual-level utilization distribution rasters ... ",
        file = logFile)
    rast <- Reduce("+", rast)
    cat("Complete\n", file = logFile)

    proj4string <- crs(rast)

    cat("\nCalculating herd-level isopleth(s) ... ", file = logFile)
    SLDF <- raster2SLDF(rast, cont = cont, proj4string=proj4string)
    cat("Complete\n", file = logFile)

    cat("\nConverting isopleth(s) to polygons ... ", file = logFile)
    SPDF <- SLDF2SPDF(SLDF, proj4string=proj4string)
    cat("Complete\n\n", file = logFile)

    ## Wrapup message and timestamp
    cat(timestamp(prefix = "Execution complete:   ",
                  suffix = "\n\n", quiet = TRUE),
        file = logFile)

    SGDF <- as(rast, "SpatialGridDataFrame")

    ## Write utilization distribution to a GeoTiff file
    if ("tiff" %in% outputType) {
        rast2GTiff(rast = rast,
                   ID = paste("Herd_", layerName, sep=""),
                   outputDir = outputDir)
    }
    ## Write polygons shapefiles to the specified directory
    if("poly" %in% outputType) {
        writeSPDF(SPDF,
                  animalID = outputFile,
                  outputDir = outputDir)
    }
    ## Return R objects of form specified by outputType
    if("raster"   %in% outputType) return(rast)
    if("sgdf"     %in% outputType) return(SGDF)
    if("sldf"     %in% outputType) return(SLDF)
    if("spdf"     %in% outputType) return(SPDF)
    if("plotdata" %in% outputType) {
        return(list(rast = rast,
                    sldf = SLDF,
                    pts  = do.call("rbind", pts)))
    }
}

