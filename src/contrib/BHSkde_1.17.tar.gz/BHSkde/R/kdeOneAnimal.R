
##' Calculate and/or write out density surface and/or isopleth
##' for a single bighorn sheep.
##'
##' MORE DETAILS LATER
##' @title Compute utilization distribution and isopleth for a single
##'     animal.
##' @export
##' @inheritParams kdeAllAnimals
##' @return Depends on the value of \code{"outputType"}.
##' @author Josh O'Brien
kdeOneAnimal <- function(BHSpts,
                         BHSname,
                         outputType,
                         gridArgs,
                         bwEstimator,
                         bwMultiplier,
                         cont,
                         outputDir) {
    ## Calculate density surfaces (kde objects) for each animal
    KDE <-
    telem2kde(BHSpts = BHSpts,
              BB = gridArgs$BB,
              gridsize = gridArgs$gridsize,
              cellsize = gridArgs$cellsize,
              bwEstimator = bwEstimator,
              bwMultiplier = bwMultiplier)

    ## Convert kde objects to SpatialGridDataFrames
    SGDF <-
    kde2SGDF(KDE = KDE,
             BB = gridArgs$BB,
             gridsize = gridArgs$gridsize,
             cellsize = gridArgs$cellsize,
             proj4string = gridArgs$prj)

    ## Convert SGDFs to rasters
    rast <-  SGDF2raster(SGDF, proj4string = gridArgs[["prj"]])

    ## Calculate SLDF contours/isopleths from rasters
    SLDF <- raster2SLDF(rast, cont = cont,
                        proj4string = gridArgs[["prj"]])

    ## Convert SLDF contours to SPDF contours
    if(outputType %in% c("spdf", "poly")) {
        SPDF   <- SLDF2SPDF(SLDF,
                            proj4string = gridArgs[["prj"]])
    }

    if(outputType == "plotdata") {
        return(list(rast = rast,
                    sldf = SLDF,
                    pts = BHSpts[[1]]))
    }
    if(outputType == "rawpoints") return(BHSpts)
    if(outputType == "kde") return(KDE)
    if(outputType == "sgdf") return(SGDF)
    if(outputType == "raster") return(rast)
    if(outputType == "sldf") return(SLDF)
    if(outputType == "spdf") return(SPDF)
    ## Write out utilization distribution to a GeoTiff file
    if(outputType =="tiff") {
        rast2GTiff(rast = rast,
                   ID = paste("Animal_", BHSname, sep=""),
                   outputDir = outputDir)
        return()
    }
    ## Write out polygons shapefiles to the specified directory
    if(outputType == "poly") {
        writeSPDF(SPDF,
                  animalID = BHSname,
                  outputDir = outputDir)
        return()
    }
}



##' Helper functions used by kdeOneAnimal and kdeHerd.
##'
##' The best explanation of these functions is in Figure in my pdf
##' document.
##' @title Helper functions for \code{kdeOneAnimal} and
##'     \code{kdeHerd}, all in one place.
##' @name helperFunctions
##' @aliases telem2kde kde2SGDF SGDF2raster raster2SLDF LL2PL
##'     SLDF2SPDF writeSPDF rast2GTiff
telem2kde <- function(BHSpts, BB, gridsize, cellsize,
                      bwMultiplier = 1,
                      bwEstimator = c("Href", "Href_diag", "Href_full", "Hpi")) {
## Utility function taking a SpatialPointsDataFrame and returning
## a kernel density estimate.
##
## @title Calculate kernel density estimate from a SpatialPointsDataFrame.
## @param BHSpts A SpatialPointsDataFrame
## @param BB A Spatial bounding box encoding the extent of the grid
## over which a kernel density estimate is to be calculated.
## @param gridsize A length-two vector c(nx, ny) specifying the
##   dimension of the grid to be output. "nx" is the number of columns
##   of cells in the x-dimension, and "ny" is the number of rows in the
##   y-dimension.
## @inheritParams kdeAllAnimals
## @return An object of class "kde"
## @author Josh O'Brien
    ## Extract coordinates of the telemetry points
    pts <- coordinates(BHSpts[[1]])
    ## Estimate bandwidth
    bwEstimator <- match.arg(bwEstimator)
    bw <- switch(bwEstimator,
                 Href      = Href(pts),
                 Href_diag = Href(pts, type = "diagonal"),
                 Href_full = Href(pts, type = "full"),
                 Hpi       = Hpi(pts, binned=TRUE))

    ## Calculate kernel density estimate
    KDE <- kde(x = pts,
               H = bw * bwMultiplier,
               gridsize = gridsize,
               xmin = BB[,1] + cellsize/2,
               xmax = BB[,2] - cellsize/2,
               supp = 8)  ## Up from default value of 3.7
    return(KDE)
}


##' @rdname helperFunctions
kde2SGDF <- function(KDE, BB, gridsize, cellsize, proj4string) {
## Utility function for converting kde-class objects to SGDFs
##
## More here later, for "Details" section.
## @title convert kde grids to SGDF grids
## @param KDE An object of class "kde", returned by "kde()"
## @param BB A Spatial bounding box encoding the extent of the grid
## @param gridsize See kdeAllAnimals (**Doc Cleanup**)
## @param cellsize See kdeAllAnimals (**Doc Cleanup**)
## @return An object of class SpatialGridDataFrame
## @author Josh O'Brien
    cc <- BB[,1] + cellsize/2
    cs <- c(cellsize, cellsize)
    cd <- gridsize
    grd <- GridTopology(cellcentre.offset = cc,
                        cellsize = cs,
                        cells.dim = cd)
    ## The following line of code was added because kde() outputs
    ## points from lower left to right, then up a line, while
    ## SpatialGridDataFrame(), when just passed a grd, takes points
    ## in from top left (just look at head(coordinates(y)),
    ## tail(coordinates(y))
    X <- KDE$estimate[, rev(seq.int(ncol(KDE$estimate)))]
    SGDF <- SpatialGridDataFrame(grid = grd,
                                 data = data.frame(d = as.vector(1e9 * X)),
                                 proj4string = proj4string)
    return(SGDF)
}

##' @rdname helperFunctions
SGDF2raster <- function(SGDF, proj4string) {
## Convert a list of SpatialGridDataFrame object to a list of
## objects of class "raster", optionally combining them into a single raster
##
## The raster package has superior facilities for handling and
## summarizing spatial raster data. Mostly in order to combine
## superposed raster layers, we convert the raster data storedin
## lists of  SpatialGridDataFrames into a list of "raster" objects.
##
## @title Convert SPGDF to raster objects
## @param SGDF
## @param combine Logical. Should the list of animal-level raster objects
## stored in SGDF be combined to produce a herd-level density map?
## @return Either a list of animal-level density maps, each one of
##   class raster, or a single raster object representing the combined
##   herd-level density map.
## @author Josh O'Brien
    rs <- raster(SGDF)
    crs(rs) <- proj4string
    return(rs)
}

##' @rdname helperFunctions
raster2SLDF <- function(r, cont = 0.95, proj4string) {
## Calculate contours for raster layers, and output the resulting
## lines as SpatialLineDataFrame's
##
## Really, I want to output these as SpatialPolygonDataFrame's, to be
## exported to polygon shapefiles, but this is a start. **NOTE**
## Currently, a ssingle animal can produce contours that form several
## polygons. R has no problem with this, but the conversion to
## polygon shapefiles might take some careful attention to ID labels,
## etc. (especially if the function is applied to several animals and
## contour levels at a time.
## @title Calculate isopleths from raster density maps.
## @param r An object of class "RasterLayer"
## @param cont A numeric vector of the form c(0.5, 0.75, 0.95), or
## 0.90.  Indicates the levels at which isopleth contours are to be
## calculated. A value of 0.95 (the default) will find a contour that
## surrounds the smallest area containing 95% of the probability mass
## on the density map.
## @return An object of class "SpatialLinesDataFrame"
## @author Josh O'Brien
    X <- sort(getValues(r, format = "matrix"))
    Y <- cumsum(X)
    Y <- Y/max(Y)
    ## Here's the key bit, which finds the densities of X
    ## at which exactly "cont" proportion of the probability
    ## mass is found in cells with a higher density
    D <- sapply(cont, function(CONT) X[min(which(Y > (1 - CONT)))])

    ## The following, which calculates the locations of the contour
    ## lines, was lifted nearly verbatim from the raster package's
    ## S4 method for applying contour() to "RasterLayer"s
    x <- sampleRegular(r, size = 1e+07, asRaster = TRUE, useGDAL=TRUE)
    CL <- contourLines(x = xFromCol(x, 1:ncol(x)),
                       y = yFromRow(x, nrow(x):1),
                       z = t((getValues(x, format = "matrix"))[nrow(x):1, ]),
                       levels=D)
    SLDF <- ContourLines2SLDF(CL)
    ## Name the lines objects with the appropriate levels of cont
    ## (ContourLines2SLDF() appears to sort resulting lines into
    ## decreasing order, so I need to reflect that in the names
    ## I attach to them.)
    nms <- paste("C_", sort(cont, decreasing=TRUE), sep="")
    SLDF <- spChFIDs(SLDF, nms)
    proj4string(SLDF) <- proj4string
    return(SLDF)
}



##' @rdname helperFunctions
LL2PL <- function(LL) {
## Converts a list of Lines to a list of Polygons. To undergo the
## conversion, each of the Lines must form a full cycle, with its
## final point being identical to its first point.
##
## A helper function for SLDF2SPDF. "LL2PL" is short for "Lines"-list
## to "Polygons"-list. A simple sanity check is performed, testing
## whether each of the Lines objects forms a full cycle.
## @title For a single animal, convert the list of Lines representing
##   the contours of a single isopleth to a list of Polygons.
## @param LL A list of Lines objects
## @return A list of Polygons objects
## @author Josh O'Brien
    sapply(LL, function(X) {
        crds <- coordinates(X)
        ## First, test that this line forms a closed loop, and can thus
        ## be converted to a polygon.
        if(!identical(crds[1, ], crds[nrow(crds), ])) {
            warning("Problem in LL2PL. At least one line object does not\n
                  form a closed loop; likely a machine precision issue.")
            crds[nrow(crds),] <- crds[1,]
        }
        # And if it
        Polygon(crds)
    })
}



##' @rdname helperFunctions
SLDF2SPDF <- function(SLDF, proj4string) {
## Convert the contour(s) calculated for a single animal from an
## object of class SpatialLinesDataFrame to a
## SpatialPolygonsDataFrame
##
## A single SpatialLinesDataFrame represents the contour(s)
## calculated for a single animal. If more than one contour was
## requested (say cont=c(0.95, 0.9)), the "lines" slot will contain a
## list of several "Lines" objects, each containing the one or more
## "Line" objects associated with each of the contours.
## @title Convert a SpatialLinesDataFrame to a SpatialPolygonsDataFrame
## @param SLDF A SpatialLinesDataFrame object.
## @param proj4string An object of class "CRS", consisting of a
## string describing the projection of the data in CRS style.
## @return A SpatialPolygonsDataFrame object.
## @author Josh O'Brien
    LinesList <- slot(SLDF, "lines")
    listOfPolygons <-
        lapply(LinesList,
               function(X) {
                   LineList <- slot(X, "Lines")
                   PolygonList <- LL2PL(LineList)
                   Polygons(PolygonList, ID=slot(X, "ID"))
               })
    SPs <- SpatialPolygons(listOfPolygons)
    IDs <- sapply(slot(SPs, "polygons"), slot, "ID")
    dat <- data.frame(cont=IDs, row.names=IDs)
    SPDF <- SpatialPolygonsDataFrame(SPs, data=dat)
    proj4string(SPDF) <- proj4string
    return(SPDF)
}



##' @rdname helperFunctions
writeSPDF <- function(SPDF, animalID, outputDir) {
## A wrapper for writeOGR, used to output Esri shapefiles
## containing the estimated isopleth(s) for a single animal.
##
## Possibly more details later. In particular, discuss why: (a) we
## can't write directly to personal geodatabases; (b) the possibility
## of better distinguishing the polygons associated with different
## isopleths. Is issue (b) solvable using the data.frame part of the
## SpatialPolygonsDataFrame?
##
## Note: writeSPDF will not overwrite existing shapefiles. TODO: I
## will need to add code that handles that possibility, either
## warning the user, or first removing the existing files. If we
## would like it to do that, the code will need to check for already
## existing files and remove them if they have the same name as the
## file-to-be-written. That code will also have to gracefully handle
## the additional possibility that those files are locked (because
## they are currently open in an ArcView session), and return a
## helpful message to the user.
## @title Output an Esri shapefile containing the estimated isopleths
## for a single animal.
## @param SPDF A SpatialPolygonsDataFrame, containing Polygons
## objects representing the contours/isopleths from a single animal.
## @param animalID something
## @param outputDir A full or relative path specifying the directory
## into which the shapefiles should be written.
## @return No return value. Called for its side effect of writing
## Esri polygon shapefiles to the resultsDir
##
## @author Josh O'Brien
    drv <- "ESRI Shapefile"
    writeOGR(SPDF, dsn = outputDir, layer = animalID, driver = drv,
             overwrite_layer = TRUE)
}


##' @rdname helperFunctions
rast2GTiff <- function(rast, ID, outputDir) {
## Write a kernel density estimate (stored in a raster) to a GeoTiff
## file.
##
## MORE EVENTUALLY
## @title Write kde of utilization distribution to GeoTiff file.
## @param rast A raster object.
## @param ID A character string identifying the raster.
## @param outputDir Directory into which the GeoTiff file should be written.
## @return Called for its side effect
## @author Josh O'Brien
    fName <- paste(ID, ".tif", sep="")
    writeRaster(x = rast,
                filename = file.path(outputDir, fName),
                format = "GTiff")
}

