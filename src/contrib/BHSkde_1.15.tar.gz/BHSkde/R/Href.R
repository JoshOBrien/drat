##' Function to calculate ``Href'', the ``reference'' bandwidth estimator
##' of Worton (1995) and others.
##'
##' This is my implementation of the reference bandwidth
##' estimator. Its default behavior (with ``\code{diag=TRUE}'') is based on the
##' descriptions of Href in Worton (1995) and Fieberg (2007). From
##' both of those, it appears that only the x and y variances are
##' calculated, and the covariance is not considered at all.
##'
##' Href returns a 2-by-2 variance-covariance matrix, whose diagonal
##' contains the variance of the kernel in the x- and
##' y-directions. The off-diagonal elements contain the x-y
##' covariance. For more details, see the vignette that accompanies
##' the \pkg{ks} package (viewed by typing \code{vignette("kde",
##' package = "ks")}).
##'
##' The \code{type} argument is used to choose among three variations
##' on the ``Href'' estimator of Worton (1995):
##' \describe{
##' \item{\code{"radial"}}{Produces a radially symmetrical kernel,
##' like that described by Worton (1995). It is what was used by the
##' Payette NF in the analyses described in its 2010 FSEIS.}
##' \item{\code{"diagonal"}}{Produces an `elliptic'
##' kernel which may be `stretched' (relative to a circle) in a N--S or
##' E--W direction, as described by Fieberg (2007). It may not, though,
##' have a diagonal orientation.}
##' \item{\code{"full"}}{Produces a full covariance matrix, encoding a
##' kernel that can be `stretched' \emph{and} `rotated' so that its
##' major axis can point in some direction other than N--S or E--W. This
##' is similar to the plug-in bandwidth estimator, but so far, I've
##' found no reference to it in the published literature.}
##' }
##' @title Calculate Href
##' @export
##' @param x A two column matrix containing the x- and y- coordinates
##' of the telemetry observations. (Same as for \code{ks::Hpi()},
##' which is more general, with methods for points in 1- to
##' 6-dimensional spaces.
##' @param type A character string determining the type of bandwidth
##' matrix returned by the function. Options are \code{"radial"} (the
##' default, corresponding to the estimator used in the Payette NF
##' analyses), \code{"diagonal"}, and \code{"full"}. See Details
##' section for more
##' \ldots details.
##' @return A 2x2 matrix
##' @references {
##' Fieberg, J. (2007). Kernel density estimators of home range:
##' Smoothing and the autocorrelation red herring.
##' \emph{Ecology} \bold{88}(4): 1059-1066.
##'
##' Worton, B. J. (1995). Using Monte-Carlo simulation to evaluate
##' kernel-based home-range estimators.
##' \emph{Journal of Wildlife Management} \bold{59}(4): 794-800.
##' }
##' @author Josh O'Brien
Href <- function(x, type = c("radial", "diagonal", "full")) {
    type <- match.arg(type)
    n <- nrow(x)
    M <- cov(x) * n^(-1/3)
    switch(type,
           radial   = diag(mean(diag(M)), 2),
           diagonal = diag(diag(M)),
           full     = M)
}
