##' Get bounding box for a set of features
##'
##' @title Get bounding box for a set of features
##' @param ... sf features
##' @return An object of class \code{bbox}.
##' @export
##' @author Joshua O'Brien
##' @examples
##' if (require(sfheaders)) {
##' p1 <- sfheaders::sf_polygon(matrix(10*runif(6), nc=2))
##' p2 <- sfheaders::sf_polygon(matrix(10*runif(6), nc=2))
##' p3 <- sfheaders::sf_polygon(matrix(10*runif(6), nc=2))
##' st_bbox_overall(p1, p2, p3)
##' }
st_bbox_overall <- function(...) {
    bbox_as_sfc <- function(X) {
        st_as_sfc(st_bbox(X))
    }
    XX <- lapply(list(...), bbox_as_sfc)
    st_bbox(do.call(c, XX))
}


##' Create a spatial rectangle to clip region around sf object
##'
##' @title Create a spatial rectangle to clip region around sf object
##' @param ... sf features
##' @param buf Distance, in units of CRS, by which to buffer sf
##'     features' collective bounding box
##' @return An \pkg{sf} object with a \code{POLYGON} geometry
##'     delineating the buffered bounding box of the supplied \pkg{sf}
##'     objects.
##' @importFrom sf st_drop_geometry st_coordinates st_bbox
##' @importFrom sf st_as_sfc st_as_sf st_buffer
##' @export
##' @author Joshua O'Brien
##' @examples
##' if (require(sfheaders)) {
##' p1 <- sfheaders::sf_polygon(matrix(10*runif(6), nc=2))
##' p2 <- sfheaders::sf_polygon(matrix(10*runif(6), nc=2))
##' p3 <- sfheaders::sf_polygon(matrix(10*runif(6), nc=2))
##' ee <- st_envelope(p1, p2, p3, buf = 2)
##' plot(ee)
##' plot(p1, col = adjustcolor("red", alpha = 0.5), add = TRUE)
##' plot(p2, col = adjustcolor("blue", alpha = 0.5), add=TRUE)
##' plot(p3, col = adjustcolor("yellow", alpha = 0.5), add=TRUE)
##' }
st_envelope <- function(..., buf = 0) {
    st_bbox_overall(...) %>%
        st_as_sfc() %>%
        st_buffer(buf) %>%
        st_bbox() %>%
        st_as_sfc() %>%
        st_as_sf()
}


## Distantly inspired by
## https://github.com/r-spatial/sf/issues/231#issuecomment-290817623
##
##' Convert sf object to a data.frame with each coordinate a column
##'
##' @title Convert sf object to a data.frame with each coordinate a
##'     column
##' @param x A simple features object
##' @return A \code{data.frame}
##' @export
##' @author Joshua O'Brien
##' @examples
##' nc <- st_read(system.file("shape/nc.shp", package = "sf"))
##' sf_to_df(st_centroid(nc[1:5,]))
sf_to_df <- function(x) {
    stopifnot(inherits(x, "sf") &&
              inherits(sf::st_geometry(x), "sfc_POINT"))
    cbind(st_drop_geometry(x), st_coordinates(x))
}

