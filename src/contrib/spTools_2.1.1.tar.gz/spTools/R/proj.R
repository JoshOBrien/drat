
##' Generic long/lat convenience projection
##'
##' The following PROJ.4 string is used: \code{+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0}
##' @export
##' @author Joshua O'Brien
##' @examples
##' us <- usa_48() # it's the default
##' us <- sp::spTransform(us, sp::CRS(proj_longlat))
proj_longlat <- "+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"


##' Albers equal-area conic convenience projection
##'
##' The following PROJ.4 string is used: \code{+proj=laea +lat_0=45 +lon_0=-100 +x_0=0 +y_0=0 +a=6370997 +b=6370997 +units=m +no_defs}
##' @family convenience projections
##' @export
##' @author Joshua O'Brien
##' @examples
##' us <- usa_48()
##' us <- sp::spTransform(us, sp::CRS(proj_laea))
proj_laea <- "+proj=laea +lat_0=45 +lon_0=-100 +x_0=0 +y_0=0 +a=6370997 +b=6370997 +units=m +no_defs"


##' Lambert conformal conic convenience projection
##'
##' The following PROJ.4 string is used: \code{+proj=lcc +lat_1=27.11637320883929 +lat_2=53.050729042644335 +lon_0=-95.44921875}
##' @family convenience projections
##' @export
##' @author Joshua O'Brien
##' @examples
##' us <- usa_48()
##' us <- sp::spTransform(us, sp::CRS(proj_lcc))
proj_lcc <- "+proj=lcc +lat_1=27.11637320883929 +lat_2=53.050729042644335 +lon_0=-95.44921875"


##' Equidistant conic convenience projection
##'
##' Distance correct along meridians
##'
##' The following PROJ.4 string is used: \code{+proj=eqdc +lat_1=27.11637320883929 +lat_2=53.050729042644335 +lon_0=-95.44921875}
##' @family convenience projections
##' @export
##' @author Joshua O'Brien
##' @examples
##' us <- usa_48()
##' us <- sp::spTransform(us, sp::CRS(proj_eqdc))
proj_eqdc <- "+proj=eqdc +lat_1=27.11637320883929 +lat_2=53.050729042644335 +lon_0=-95.44921875"


##' Oblique azimuthal equidistant convenience projection
##'
##' Distance correct along any line passing through the center of the
##' map (i.e., great circle)
##'
##' The following PROJ.4 string is used: \code{+proj=aeqd
##' +lat_0=40.08355112574181 +lon_0=-95.44921875}
##' @family convenience projections
##' @export
##' @author Joshua O'Brien
##' @examples
##' us <- usa_48()
##' us <- sp::spTransform(us, sp::CRS(proj_aeqd))
proj_aeqd <- "+proj=aeqd +lat_0=40.08355112574181 +lon_0=-95.44921875"

