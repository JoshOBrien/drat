
##' This code is presented in the introduction to the colorspace
##' package vignette, gotten by typing \code{vignette("hcl-colors")}.
##' @title Display a vector of colors.
##' @param col Vector of colors.
##' @param border A color to be used on the display's borders.
##' @param ... Other arguments to base R's plot function.
##' @return None. (Called for its side effect, a plot of colored rectangles.)
##' @importFrom graphics rect
##' @export
##' @author Joshua O'Brien
##' @examples
##' displayPalette(rainbow(100), border=NA)
displayPalette <- function(col, border = "light gray", ...) {
    n <- length(col)
    plot(0, 0, type="n", xlim = c(0, 1), ylim = c(0, 1),
         axes = FALSE, xlab = "", ylab = "", ...)
    rect(0:(n-1)/n, 0, 1:n/n, 1, col = col, border = border)
}


## https://stackoverflow.com/a/10417676/980833
##
##' A better colorRamp(), returning colors as sRGB strings.
##'
##' @title A better colorRamp(), returning colors as sRGB strings.
##' @param colors Same as for \code{\link[grDevices:colorRamp]{colorRamp()}}
##' @param ... Additional arguments to be passed on to
##' \code{\link[grDevices:colorRamp]{colorRamp()}}.
##' @param fit Boolean. Should the return function normalize values
##' passed to it, sot that they range between 0 and 1? \code{FALSE}
##' (the default) corresponds to the behavior of
##' \code{\link[grDevices:colorRamp]{colorRamp()}}.
##' @return A vector sRGB color strings.
##' @importFrom grDevices colorRamp rgb
##' @export
##' @author Joshua O'Brien
##' @examples
##' cr <- colorRampRGB(c("black", "red", "yellow"), fit = TRUE)
##' plot(rnorm(99), pch = 16, cex = 2, col = cr(1:99))
colorRampRGB <- function(colors, ..., fit=FALSE) {
    function(x) {
        if(fit) x <- (x - min(x))/(diff(range(x)))
        rgb(colorRamp(colors, ...)(x), maxColorValue = 255)
    }}


##' Color palettes from Gretchen Peterson's "GIS Cartography"
##'
##' These are palettes presented in Gretchen Peterson's "GIS
##' Cartography: A Guide to Effective Map Design"
##' @title Palettes for GIS cartography.
##' @param pal.name Character string naming desired palette. One of
##' "Currents", "Elevation", "Geology", "Hillshade",
##' "LandUseAndCover", "Parcels", "RiversAndStreams", "Roads",
##' "Soils", or "Temperature".
##' @return Vector of 8 colors, specified using \code{"#******"} format.
##' @export
##' @author Joshua O'Brien
##' @examples
##' displayPalette(GIScolors("Geology"))
GIScolors <- function(pal.name = "Soils") {
    ## Produced by doing the following
    ## GIScolors <- read.csv("GIScolors.csv", as.is=TRUE)
    ## dput(rgb(GIScolors[c("r", "g", "b")], max=255))
    tmp <- structure(list(
        Currents = c("#000000", "#FFFFFF", "#E6EFFF", "#FFFDF7", "#237ACC",
        "#F03000", "#D81818", "#A80000"),
        Elevation = c("#FFFFFF", "#B2B2B2", "#6E532D", "#998957", "#FCBA03",
        "#267300", "#FFFFBE", "#BEE8FF"),
        Geology = c("#DAE678", "#BEA775", "#BF5E34", "#93BFA6", "#EB7500",
        "#E089C3", "#FDE14F", "#CC1FFF"),
        Hillshade = c("#FFFFFF", "#DCDCDC", "#C8C8C8", "#B4B4B4", "#9D9D9D",
        "#828282", "#646464", "#000000"),
        LandUseAndCover = c("#EB6D69", "#CEA68A", "#FFE0AE", "#A6D59E",
        "#75B5DC", "#BCDBE8", "#C8C8C8", "#BDDDD1"),
        Parcels = c("#FFFFFF", "#000000", "#D3FFBE", "#FFFFBE", "#C500FF",
        "#F5A27A", "#FFD37F", "#D79E9E"),
        RiversAndStreams = c("#9D9FA6", "#439AB8", "#006F9E", "#003445",
        "#050982", "#BEFFE8", "#63DEB7", "#A9B1C2"),
        Roads = c("#FFFFFF", "#E1E1E1", "#FF0000", "#FFAA00", "#FFFF00",
        "#734C00", "#4E4E4E", "#000000"),
        Soils = c("#59482D", "#755D27", "#917D2F", "#BA8330", "#CF9F59",
        "#F5FF7A", "#F08966", "#F0E6C6"),
        Temperature = c("#B40000", "#E43B24", "#C97C00", "#E94C13", "#F4FD08",
        "#E6EFFF", "#C6C3D7", "#267BAC")),
        .Names = c("Currents", "Elevation", "Geology", "Hillshade",
        "LandUseAndCover", "Parcels", "RiversAndStreams", "Roads", "Soils",
        "Temperature"))
    tmp[[match(tolower(pal.name), tolower(names(tmp)))]]
}


##' This function is currently not at all robust. It will fail whenver
##' the supplied value of \code{shade} takes the value of even one
##' color in \code{col} outside of the range [0,1].
##'
##' Darken colors by decreasing their HSV value. (See
##' \url{https://stackoverflow.com/a/26322593/980833} for a similar
##' function that desaturates a vector of colors.)
##' @title Darken colors
##' @param col A vector of colors in any of the three kinds of R
##' color specifications accepted by \code{col2rgb()}.
##' @param shade A number less than 1 indicating the amount by which
##' the colors' value (the 'V' in 'HSV') should by decreased.
##' @return A vector of colors
##' @importFrom grDevices col2rgb hsv rgb2hsv
##' @export
##' @author Joshua O'Brien
##' @examples
##' cols <- RColorBrewer::brewer.pal(9, 'Set1')
##' cols_dk <- makeDarker(cols)
##' plot(1:9, rep(1, 9), pch = 19, cex = 2, col = cols)
##' points(1:9, rep(1.2, 9), pch = 19, cex = 2, col = cols_dk)
makeDarker <- function(col, shade = 0.2) {
    x = rgb2hsv(col2rgb(col)) - c(0, 0, shade)
    hsv(x[1,], x[2,], x[3,])
}




##' Reads vector of colors from binary Adobe Color Table (act)
##' and Global Color Table (gct) files.
##'
##' Adobe Color Tables use a binary format in which each of 256 RGB
##' color values is given by three consecutive bytes. Global Color
##' Tables, optionally placed near the start of GIF files, use the
##' same format. NASA's Panoply Data Viewer for NetCDF and other
##' gridded data ships with a number of color tables, many of them
##' encoded as ACT or GCT files. All of those color tables are
##' downloadable from
##' \url{https://www.giss.nasa.gov/tools/panoply/colorbars/}.
##' @title Read Adobe (or Global) Color Tables
##' @param file Path to an Adobe/Global Color Table file.
##' @return A vector of 256 color specifications, encoded as sRGB
##' character strings.
##' @export
##' @author Joshua O'Brien
##' @references For descriptions of the Global Color Table format, see
##' Matthew Flickinger's detailed writeup of
##' \href{https://www.matthewflickinger.com/lab/whatsinagif/bits_and_bytes.asp}{\dQuote{What's
##' in a GIF --- Bit by Byte}} and/or
##' \href{https://www.w3.org/Graphics/GIF/spec-gif89a.txt}{the official
##' GIF89a file format specification}.
##' @examples
##' SMpal <-
##' readACT(system.file(package="spTools", "extdata/SVS_soilmoisture.act"))
##' image(matrix(1:256, ncol=1), col=SMpal)
readACT <- function(file) {
    f <- file(file, "rb")
    on.exit(close(f))
    bb <- readBin(f, what="integer", size=1, n=3*256, signed=FALSE)
    mm <- matrix(bb, ncol=3, byrow=TRUE)
    rgb(mm, maxColorValue = 256)
}
