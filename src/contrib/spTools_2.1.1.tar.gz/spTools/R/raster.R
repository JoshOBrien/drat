
##' Inspired by code at \url{https://gis.stackexchange.com/a/252893/5720}
##'
##' @title Find the extent of a list of rasters
##' @param rasters A list of rasters
##' @return An Extent object
##' @export
##' @author Joshua O'Brien
extent_all_rasters <- function(rasters){
    Reduce(union, sapply(rasters, raster::extent))
}


##' Inspired by code at \url{https://gis.stackexchange.com/a/252893/5720}
##'
##' @title Sum together well-registered rasters with possibly
##'     different extents
##' @param rasters A list of rasters
##' @param extent Optionally provide an extent over which the rasters
##'     will be summed
##' @return A raster that is the sum of all supplied rasters
##' @export
##' @author Joshua O'Brien
sum_all_rasters <- function(rasters, extent = extent_all_rasters(rasters)){
    re = lapply(rasters, function(r) {extend(r, extent, value = 0)})
    Reduce("+", re)
}
