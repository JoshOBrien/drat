##' Calculate the location of a destination point reached by traveling
##' along a straight line in the projected coordinate system, given a
##' starting point, direction, and distance.
##'
##' Currently (2014-10-21), this has only been tested in a UTM
##' coordinate system. Function and argument names follow that of
##' geosphere::destPoint(), which (since it implements spherical
##' trigonometry) also includes 'r' with a default value of 6378137
##' meters to the center of the earth.
##' @title Destination given bearing (direction) and distance in a
##' projected coordinate system.
##' @param p \code{SpatialPoints} object representing the initial point.
##' @param b Bearing in degrees.
##' @param d Distance in meters.
##' @return \code{SpatialPoints} object representing the destination
##' point.
##' @export
##' @author Joshua O'Brien
##' @examples
##' a <- SpatialPoints(matrix(c(0,30), ncol=2), CRS("+proj=merc"))
##' b <- destPointPRJ(a, 30, 3)
##' plot(rbind(a,b))
##' gDistance(a, b)
destPointPRJ <- function(p, b, d) {
    rad <- b*pi/180
    crs <- crs(p)
    xy <- coordinates(p)
    dxy <-  d*(cbind(cos(rad), sin(rad)))
    SpatialPoints(xy + dxy, proj4string = crs)
}


##' Calculate the line between an initial point and a destination
##' reached by traveling a given distance at a fixed bearing in a
##' projected coordinate system.
##'
##' Currently (2014-10-21), this has only been tested in a UTM
##' coordinate system. See Details at \code{\link{destPointPRJ}} for
##' more.
##' @title Line from initial point to destination, given bearing
##' (direction) and distance in a projected coordinate system.
##' @param p \code{SpatialPoints} object representing the initial point.
##' @param b Bearing in degrees.
##' @param d Distance in meters.
##' @return \code{SpatialLines} object representing the destination point.
##' @export
##' @author Joshua O'Brien
##' @examples
##' ## Load an example polygon and convert it to UTM coordinates
##' CHHR <- shapefile(system.file("external/lux.shp", package="raster"))[1,]
##' zone <- long2UTM(coordinates(gCentroid(CHHR))[1])
##' crs <- CRS(sprintf("+proj=utm +zone=%s ellps=WGS84", zone))
##' CHHR <- spTransform(CHHR, crs)
##' hub <- gCentroid(CHHR)
##' ## Now use destLinePRJ to find intersection of line with CHHR
##' ll <- destLinePRJ(p=hub, b=30, d=2e4)
##' plot(CHHR)
##' plot(gIntersection(ll, CHHR), col="blue", lwd=2, add=TRUE)
##' gLength(gIntersection(ll, CHHR))
destLinePRJ <- function(p, b, d) {
    dest <- destPointPRJ(p,b,d)
    as(bind(p, dest), "SpatialLines")
}
