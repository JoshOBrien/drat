

##' A utility function, supplying a straightforward way to say ``I'd
##' like a matrix filled with values \code{v}, with row names \code{r}
##' and column names \code{c}."
##'
##' The vector of values, \code{v} should have a number of values
##' that cleanly divides \code{length(n)*length(c)}, but it does not
##' currently enforce that requirement.
##' @title Construct a matrix from row and column names
##' @param r A vector used to name rows.
##' @param c A vector used to name columns.
##' @param val A numeric vector (often of length 1) supplying the
##' values used to fill the matrix.
##' @return A matrix with \code{length(r)} rows and \code{length(c)}
##' columns, with row and column names given by \code{r} and \code{c}.
##' @export
##' @author Joshua O'Brien
##' @examples
##' filledMatrix(letters[1:3], LETTERS[24:26], val=3:1)
filledMatrix <- function(r,c,val=0L) {
    matrix(val, nrow=length(r), ncol=length(c), dimnames=list(r,c))
}

##' A utility function, supplying a straightforward way to say ``I'd
##' like a matrix of zeros, with row names \code{r} and column names
##' \code{c}."
##'
##' This is simply a utility function, wrapping the more general
##' \code{\link{filledMatrix}}.
##' @title Construct a matrix of zeros from row and column names.
##' @inheritParams filledMatrix
##' @return A matrix of zeros with \code{length(r)} rows and
##' \code{length(c)} columns, with row and column names given by
##' \code{r} and \code{c}.
##' @export
##' @author Joshua O'Brien
##' @examples
##' zeroMatrix(letters[1:3], LETTERS[24:26])
zeroMatrix <- function(r,c) {
    filledMatrix(r,c,val=0L)
}

##' Uses the nifty matrix-based indexing/replacement functionality
##' available since R version (??) to replace values given a
##' two-column matrix of their row and column indices.
##'
##' There is no requirement that all (or even any) of \code{b}'s row
##' and colum names be found in \code{a}. I haven't yet checked for
##' what happens in the case that \code{b} and/or \code{a} have
##' repeated row or column names.
##' @title Subassign one matrix into another, based on their dimnames.
##' @param a The (typically larger) matrix into which assignment is to
##' take place.
##' @param b The matrix whose elements will be inserted into \code{a}.
##' @return A matrix of the same dimensions as \code{a}, with elements
##' whose row and column names are also found in \code{b} having been
##' replaced by the corresponding element of \code{b}
##' @export
##' @author Joshua O'Brien
##' @examples
##' a <- zeroMatrix(letters[1:3], LETTERS[24:26])
##' b <- zeroMatrix(c("a", "c"), c("Y", "Z"))
##' b[] <- 1:4
##' insertMatrix(a,b)
insertMatrix <- function(a,b) {
    ij <- cbind(match(rownames(b)[row(b)], rownames(a)),
                match(colnames(b)[col(b)], colnames(a)))
    a[ij] <- b
    a
}
