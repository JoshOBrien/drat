
##' Like \code{\link[base:load]{load}}, except: (1) reloads data saved
##' by \code{saveRDS}; and (2) uses the file's name, without
##' extension, as the name assigned to the loaded object
##'
##' @title Reload data from an ``RDS'' file, assigning it to an object
##' named using the file's name.
##' @param file Path giving the RDS file to be loaded.
##' @return Like \code{\link[base:load]{load}}, a character string
##' with the name of the object created, invisibly.
##' @author Joshua O'Brien
##' @export
##' @examples
##' \dontrun{
##' X <- 1:4
##' saveRDS(X, file = "varXX.rds")
##' rm(X)
##' loadRDS(file = "varXX.rds")
##' varXX
##' }
loadRDS <- function(file) {
    objname <- tools::file_path_sans_ext(basename(file))
    assign(x = objname, value = readRDS(path),
           envir = parent.frame())
    invisible(objname)
}


##' More later.
##'
##' At present, this function only does something useful in the R Gui.
##' In (my) Emacs, the value of the pager option, used by default by
##' file.show(), is set to "console". Previously, to force printing to
##' a new window, I explicitly set pager="emacsclientw.exe" in
##' file.show(), but if the R session was closed before the subsidiary
##' window, emacs was entirely frozen. (In the R Gui, the value of
##' options("pager") is "internal", just what we want.)
##' @title Display object's printed value in a window.
##' @param obj Any R object.
##' @return Called for its side effect, a new pager window displaying
##' the printed representation of obj.
##' @importFrom utils capture.output
##' @export
##' @author Joshua O'Brien
printToWindow <- function(obj) {
    b <- tempfile()
    capture.output(obj, file=b)
    ## if("ESSR" %in% search()) {
    ##     file.show(b, pager="emacsclientw.exe")
    ## } else {
    	file.show(b)
    ## }
}


##' Retrieve and display an Rd file
##'
##' Details: perhaps more details later.
##' @title Retrieve the Rd file that produces a given help file.
##' @param topic Character string with name of help file produced by
##' the Rd file being sought.
##' @param view Logical. Should the Rd file be displayed (in Windows,
##' in a newly opened window)? Default is \code{TRUE}.
##' @param pkg Character string giving name of package from which the
##' help file is being sought. If left as \code{NULL} (it's default),
##' \code{getRd} will attempt to discover the package's identity on
##' its own.
##' @return Invisibly returns a list representing the parsed (?) Rd
##' code underlying the help file.
##' @importFrom tools Rd_db
##' @importFrom methods getPackageName
##' @importFrom utils find
##' @export
##' @author Joshua O'Brien
getRd <- function(topic, view=TRUE, pkg=NULL) {
    if(is.null(pkg)) pkg <- getPackageName(find(topic))
    db <- Rd_db(pkg)
    ## All help files for package functions
    unname(sapply(db, tools:::.Rd_get_metadata, "name"))
    ## Get the help file
    rd <- db[grep(paste0(topic, ".Rd"), names(db))]
    if(view) {printToWindow(rd)}
    invisible(rd)
}


##' Open a high-resolution png device, with dimensions given in inches
##'
##' Oscar Perpinan accomplishes something similar by first outputting
##' pdf files and then converting them to png files, using a call to
##' ImageMagick's \code{mogrify}.
##' @title Open a high-resolution png device
##' @param filename Name of file to which device output will be
##'     written.
##' @param width Device width in inches. (Default 7).
##' @param height Device height in inches. (Default 7).
##' @param res Nominal resolution in pixels per inch. Defaults to
##'     400. See \code{\link{png}} for details.
##' @return Called for side effect (opening a high-resolution png
##'     device with dimensions that mimic those of a default pdf
##'     device).
##' @importFrom grDevices png
##' @export
##' @author Joshua O'Brien
hiresPNG <- function(filename = "Rplot%03d.png",
                     width = 7, height = 7, res = 400) {
    png(filename, width = width, height = height,
        units = "in", type = "cairo", res = res)
}

##' Use pdftk to remove first page from a pdf
##'
##' @title Remove first page from a pdf
##' @param f Name of file from which first page is to be removed
##' @return Called for side effect.
##' @export
##' @author Joshua O'Brien
pdftkSnip <- function(f) {
    tmp <- paste0("TMP", f)
    system2(command = "pdftk",
            args = c(paste0("A=",shQuote(f)),
                     "cat A2-end output", shQuote(tmp)))
    file.rename(tmp, f)
}

