##' More later!
##'
##' Check \code{vignette("combine_maptools")} for the example from
##' which this function was derived.
##' @title Check for and sanitize holes in a SpatialPolygons* object.
##' @param SP A \code{SpatialPolygons} or
##' \code{SpatialPolygonsDataFrame} object.
##' @importFrom maptools checkPolygonsHoles
##' @export
##' @return A SpatialPolygons* object of the same class as that input
##' to \code{SP}. It should differ from \code{SP} only in that it's guaranteed to have had its Polygons all checked for holes.
##' @author Joshua O'Brien
checkSPHoles <- function(SP) {
    X <- lapply(SP@polygons, checkPolygonsHoles)
    X <- SpatialPolygons(X, proj4string = crs(SP))
    if(inherits(SP, "SpatialPolygonsDataFrame")) {
        X <- SpatialPolygonsDataFrame(X, data = data.frame(SP))
    }
    X
}
