## ----setup, echo=FALSE, results="hide"----------------------------------------
source("setup.R")
set.seed(123)

## ----makeDarker-plot, fig.height=1.6------------------------------------------
par(mar=c(0,0,0,0))
cols <- RColorBrewer::brewer.pal(9, 'Set1')
cols_dk <- makeDarker(cols)
plot(rep(1:9, 2), rep(2:1, each=9), ylim=c(0,3), axes=FALSE, ann=FALSE,
     pch = 19, cex = 3, col = c(cols, cols_dk))

## ----GIScolors-plot, fig.height=1.6-------------------------------------------
par(mar=c(0,0,0,0))
displayPalette(GIScolors("Geology"), border=NA)

## -----------------------------------------------------------------------------
(a <- zeroMatrix(letters[1:3], LETTERS[24:26]))
(b <- filledMatrix(r = c("a", "c"), c = c("Y", "Z"), val=5:8))
insertMatrix(a, b)

## ----gRasterize-plot, fig.height=4, fig.width=5.5-----------------------------
SPDF <- shapefile(system.file("external/lux.shp", package="raster"))
rr <- raster(extent(SPDF), ncol=100, nrow=100, crs=proj4string(SPDF))

## An example using a character-valued field
rFac <- gRasterize(SPDF, rr, field = "NAME_2")
rasterVis::levelplot(rFac)

## ----eval=FALSE---------------------------------------------------------------
#  method ? spplot(obj="Extent")

## ----makeScalebar-plot, fig.height=4, fig.width=4-----------------------------
library(lattice) # required for trellis.par.set():
trellis.par.set(sp.theme()) # sets color ramp to bpy.colors()
data(meuse)
coordinates(meuse)=~x+y
scalebar <- makeScalebar(bbox(meuse))
scalebar <- makeScalebar(bbox(meuse), pos = c(0.7,0.03),
                         conversionFactor = 1/1000, outUnit = "km")

spplot(meuse, "zinc", do.log=T,
       key.space=list(x=0.1,y=0.93,corner=c(0,1), cex=0.7),
       sp.layout = scalebar,
       main = "Zinc (top soil)")

## ----echo=FALSE, results="asis"-----------------------------------------------
writeIndex(cols = 5)

