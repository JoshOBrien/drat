
suppressPackageStartupMessages(library(spTools))


## Write this once at the start of the document.
##
## .nostripes gets triggered like this, as in writeIndex() defined below
##   cat('\n<div class="nostripes">\n')
##   print(knitr::kable(matrix(entries, ncol=cols), format="pandoc"))
##   cat("</div>\n")
##
cat('<style>
.nostripes tr.even {background-color: white;}
table {border-style: none;}
table th {border-style: none;}
table td {border-style: none;}
a[href^=".."] {text-decoration: underline;}
</style>
')


## Functions for setting up links and an index.
## Use like:
## `r indexfns("displayPalette")`
## `r indexfns("GIScolors")`
##
##
## ```{r echo=FALSE, results="asis"}
## writeIndex(cols = 4)
## ```

documentedfns <- c()
indexfns <- function(fns, text = paste0("`", fns, "`"), show = TRUE) {
  documentedfns <<- c(documentedfns, fns)
  anchors <- paste0('<a name="', fns, '">',
                    if (show) linkfn(fns, text, pkg = "spTools"),
                    '</a>')
  paste(anchors, collapse=if (show) ", " else "")
}

linkfn <- function(fn, text = paste0("`", fn, "`"), pkg = NA) {
  if (is.na(pkg))
    paste0('<a href="#', fn, '">', text, '</a>')
  else
    paste0('<a href="../../', pkg, '/help/', fn, '">', text,
           '</a>')
}

writeIndex <- function(cols = 4) {
  documentedfns <- sort(documentedfns)
  entries <- paste0('<a href="#', documentedfns, '">', documentedfns, '</a>&nbsp;&nbsp;')
  len <- length(entries)
  padding <- ((len + cols - 1) %/% cols) * cols - len
  if (padding)
    entries <- c(entries, rep("", length.out=padding))
  cat('\n<div class="nostripes">\n')
  print(knitr::kable(matrix(entries, ncol=cols), format="pandoc"))
  cat("</div>\n")
}
