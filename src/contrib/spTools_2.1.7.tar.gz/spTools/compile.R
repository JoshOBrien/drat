library(devtools)
setwd("..")
document("spTools")
install("spTools", build_vignette=TRUE)

static_help <- function(pkg, links = tools::findHTMLlinks()) {
  owd <- setwd(system.file('help', package = pkg))
  on.exit(setwd(owd))
  pkgRdDB = tools:::fetchRdDB(file.path(find.package(pkg), 'help', pkg))
  force(links); topics = names(pkgRdDB)
  for (p in topics) {
    tools::Rd2HTML(pkgRdDB[[p]], paste(p, 'html', sep = '.'),
                   package = pkg, Links = links, no_links = is.null(links))
  }
}
static_help("spTools")
