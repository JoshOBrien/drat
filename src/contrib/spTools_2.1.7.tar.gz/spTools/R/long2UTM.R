
##' Get a longitude's UTM zone.
##'
##' This code comes from my answer to this SO question
##'  (\url{https://stackoverflow.com/a/9188972/980833}). See the
##'  comments below the answer for a few caveats.
##' @title Get UTM zone that contains a longitude.
##' @param long A numeric longitude.
##' @param type A character string, one of \code{"numeric"} (for a
##'     number between 1 and 60), \code{"proj4string"} (for a
##'     PROJ4-style character string), or \code{"epsg"} (for a number between 32601 and 32660).
##' @return A number representing the UTM zone containing the
##'     longitude \code{long}
##' @export
##' @author Joshua O'Brien
long2UTM <- function(long,
                     type = c("numeric", "proj4string", "epsg")) {
    type <- match.arg(type)
    zone <- (floor((long + 180)/6) %% 60) + 1
    STR <- "+proj=utm +zone=%d +datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"
    switch(type,
           numeric = return(zone),
           proj4string = return(sprintf(STR, zone)),
           epsg = return(32600 + zone))
}


##' Reproject spatial data into the UTM coordinate system.
##'
##' To learn which UTM zone is most appropriate for a given dataset,
##' look at the map on
##' \href{https://en.wikipedia.org/wiki/Universal_Transverse_Mercator_coordinate_system}{Wikipedia's
##' UTM page} or use this package's \code{\link{long2UTM}} function.
##' @title Project spatial data into UTM coordinates.
##' @param obj A \code{Spatial*} object for which
##'     \code{\link[sp]{spTransform}} provides a method.
##' @param zone An integer between \code{1} and \code{60}, giving the
##'     UTM zone into which projection should take place.
##' @return A \code{Spatial*} object containing the data in \code{obj}
##'     reprojected into the projected planar UTM coordinate system.
##' @export
##' @author Joshua O'Brien
##' @examples
##' ## Following example here https://stackoverflow.com/a/26308889/980833
##' p <- shapefile(system.file("external/lux.shp", package="raster"))
##' zone <- round(mean(long2UTM(coordinates(p))))
##' pUTM <- project2UTM(obj=p, zone=zone)
project2UTM <- function(obj, zone) {
    STR <- "+proj=utm +zone=%d +datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"
    crs <- CRS(sprintf(STR, zone))
    spTransform(obj, crs)
}
