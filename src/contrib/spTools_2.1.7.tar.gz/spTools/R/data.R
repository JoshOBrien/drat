##' The data are a subset of the state-level GADM data (USA_adm1),
##' with Alaska and Hawaii removed.
##'
##' The data were originally retrieved from a database using
##' \code{raster::getData()}. For other similar data, check my
##' \file{/R/SpatialData/} directory
##' @title Retrieve a map of the lower 48 states
##' @return A \code{SpatialPolygonsDataFrame} delineating the 48
##'     continental states.
##' @export
##' @author Joshua O'Brien
##' @examples
##' us48 <- usa_48()
##' plot(us48)
usa_48 <- function () {
     readRDS(system.file("extdata/US48.rds", package = "spTools"))
}


##' Utility function for quickly accessing spatial datasets shipped
##' with standard R spatial packages.
##'
##' \code{"lux"}, \code{"boston_tracts"}, \code{"NY8"}, and
##' \code{"nc"} are \code{SpatialPolygonsDataFrame}s, \code{"pointZ"}
##' is a \code{SpatialPointsDataFrame}. \code{"test_raster"} and
##' \code{"rlogo_brick"} are from the \pkg{raster} package.
##' @title Easy access to spatial data
##' @param layer Name of spatial dataset. One of \code{"lux"},
##'     \code{"boston_tracts"}, \code{"NY8"}, \code{"pointZ"},
##'     \code{"test_raster"}, or \code{"rlogo_brick"}.
##' @return An R spatial object.
##' @export
##' @author Joshua O'Brien
##' @examples
##' plot(getSpatialData("lux"))
getSpatialData <- function(layer="lux") {
    switch(layer,
           lux = shapefile(system.file("external/lux.shp", package="raster")),
           boston_tracts = shapefile(system.file("etc/shapes/boston_tracts.shp",
                                                 package="spdep")),
           NY8 = shapefile(system.file("etc/shapes/NY8_utm18.shp",
                                       package="spdep")),
           nc = shapefile(system.file("shape/nc.shp", package="sf")),
           pointZ = shapefile(system.file("shapes/pointZ.shp",
                                          package="maptools")),
           test_raster = raster(system.file("external/test.gri",
                                            package="raster")),
           rlogo_brick = brick(system.file("external/rlogo.gri",
                                            package="raster"))
           ## NOTE: columbus is terrible as it's in arbitrary coordinates
           ## columbus=readOGR(dsn = system.file("etc/shapes",package="spdep"),
           ##                  layer = "columbus"))
           )
}
