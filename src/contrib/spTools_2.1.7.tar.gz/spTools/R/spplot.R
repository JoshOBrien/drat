#' @export
setMethod('spplot', signature(obj='Extent'),
          function(obj, ...) {
              obj <- as(obj, "SpatialPoints")
              spplot(obj, col.regions="transparent", auto.key=FALSE, ...)
          }
          )

#' @export
setMethod('spplot', signature(obj='SpatialPolygons'),
          function (obj, ..., col=1, col.regions="transparent") {
              nms <- sapply(obj@polygons, function(x) x@ID)
              CR <- as.numeric(factor(col.regions,
                                      levels = unique(col.regions)))
              vals <- rep(CR, length.out = length(obj))
              df <- data.frame(val = vals, row.names = nms)
              spdf <- SpatialPolygonsDataFrame(obj, data = df)
              spplot(spdf, col = col, colorkey = FALSE,
                     col.regions = col.regions,
                     cuts = length(unique(vals))-1,
                     ...)
          }
          )

#' @export
setMethod('spplot', signature(obj='SpatialLines'),
          function (obj, ..., col = 1) {
              nms <- sapply(obj@lines, function(x) x@ID)
              CR <- as.numeric(factor(col,
                                      levels = unique(col)))
              vals <- rep(CR, length.out=length(obj))
              DATA <- data.frame(val = vals, row.names = nms)
              SLDF <- SpatialLinesDataFrame(obj, data = DATA)
              spplot(SLDF, ..., col.regions = col, colorkey = FALSE,
                     cuts = length(unique(vals)) -1,
                     ...)
          }
          )


#' @export
setMethod('spplot', signature(obj='SpatialPoints'),
          function (obj, ...,
                    col.regions = "grey30", pch = 16,
                    auto.key = FALSE) {
              obj <- SpatialPointsDataFrame(obj, data.frame(ID = 1:length(obj)))
              spplot(obj, ..., col.regions = col.regions, pch = pch,
                     auto.key = auto.key)
          }
          )
## library(sp)
## data(meuse)
## coordinates(meuse) <- ~x+y
## proj4string(meuse) <- CRS("+init=epsg:28992")
## spPts <- as(meuse, "SpatialPoints")
## spplot(spPts)

