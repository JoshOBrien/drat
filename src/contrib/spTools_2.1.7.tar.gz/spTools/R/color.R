
##' Color palettes from Gretchen Peterson's "GIS Cartography"
##'
##' These are palettes presented in Gretchen Peterson's
##' "GIS Cartography: A Guide to Effective Map Design"
##' @title Palettes for GIS cartography.
##' @param pal.name Character string naming desired palette. One of
##'     "Currents", "Elevation", "Geology", "Hillshade",
##'     "LandUseAndCover", "Parcels", "RiversAndStreams", "Roads",
##'     "Soils", "Temperature", "BLM", or "USFS".
##' @return Vector of 8 colors, specified using \code{"#******"}
##'     format.
##' @export
##' @author Joshua O'Brien
##' @examples
##' if (require(jobTools)) {
##'     displayPalette(GIScolors("Geology"))
##'     par(mfcol = c(5, 1), mar = c(0, 0, 0, 0))
##'     ff <- function(x) {
##'         displayPalette(GIScolors(x))
##'         mtext(x, line = -2)
##'     }
##'     lapply(c("Currents", "Elevation", "Geology",
##'              "Hillshade", "LandUseAndCover"), ff)
##'     lapply(c("Parcels", "RiversAndStreams", "Roads",
##'              "Soils", "Temperature"), ff)
##' }
GIScolors <- function(pal.name = "Soils") {
    ## Produced by doing the following
    ## GIScolors <- read.csv("GIScolors.csv", as.is=TRUE)
    ## dput(rgb(GIScolors[c("r", "g", "b")], max=255))
    tmp <- list(
        Currents = c("#000000", "#FFFFFF", "#E6EFFF", "#FFFDF7", "#237ACC",
        "#F03000", "#D81818", "#A80000"),
        Elevation = c("#FFFFFF", "#B2B2B2", "#6E532D", "#998957", "#FCBA03",
        "#267300", "#FFFFBE", "#BEE8FF"),
        Geology = c("#DAE678", "#BEA775", "#BF5E34", "#93BFA6", "#EB7500",
        "#E089C3", "#FDE14F", "#CC1FFF"),
        Hillshade = c("#FFFFFF", "#DCDCDC", "#C8C8C8", "#B4B4B4", "#9D9D9D",
        "#828282", "#646464", "#000000"),
        LandUseAndCover = c("#EB6D69", "#CEA68A", "#FFE0AE", "#A6D59E",
        "#75B5DC", "#BCDBE8", "#C8C8C8", "#BDDDD1"),
        Parcels = c("#FFFFFF", "#000000", "#D3FFBE", "#FFFFBE", "#C500FF",
        "#F5A27A", "#FFD37F", "#D79E9E"),
        RiversAndStreams = c("#9D9FA6", "#439AB8", "#006F9E", "#003445",
        "#050982", "#BEFFE8", "#63DEB7", "#A9B1C2"),
        Roads = c("#FFFFFF", "#E1E1E1", "#FF0000", "#FFAA00", "#FFFF00",
        "#734C00", "#4E4E4E", "#000000"),
        Soils = c("#59482D", "#755D27", "#917D2F", "#BA8330", "#CF9F59",
        "#F5FF7A", "#F08966", "#F0E6C6"),
        Temperature = c("#B40000", "#E43B24", "#C97C00", "#E94C13", "#F4FD08",
        "#E6EFFF", "#C6C3D7", "#267BAC"),
        BLM = "#C36D54",
        USFS = "#6D9356")
    tmp[[match(tolower(pal.name), tolower(names(tmp)))]]
}



##' Reads vector of colors from binary Adobe Color Table (act)
##' and Global Color Table (gct) files.
##'
##' Adobe Color Tables use a binary format in which each of 256 RGB
##' color values is given by three consecutive bytes. Global Color
##' Tables, optionally placed near the start of GIF files, use the
##' same format. NASA's Panoply Data Viewer for NetCDF and other
##' gridded data ships with a number of color tables, many of them
##' encoded as ACT or GCT files. All of those color tables are
##' downloadable from
##' \url{https://www.giss.nasa.gov/tools/panoply/colorbars/}.
##' @title Read Adobe (or Global) Color Tables
##' @param file Path to an Adobe/Global Color Table file.
##' @return A vector of 256 color specifications, encoded as sRGB
##'     character strings.
##' @export
##' @author Joshua O'Brien
##' @references For descriptions of the Global Color Table format, see
##'     Matthew Flickinger's detailed writeup of
##'     \href{https://www.matthewflickinger.com/lab/whatsinagif/bits_and_bytes.asp}{\dQuote{What's
##'     in a GIF --- Bit by Byte}} and/or
##'     \href{https://www.w3.org/Graphics/GIF/spec-gif89a.txt}{the
##'     official GIF89a file format specification}.
##' @examples
##' SMpal <-
##' readACT(system.file(package = "spTools", "extdata/SVS_soilmoisture.act"))
##' image(matrix(1:256, ncol = 1), col = SMpal)
readACT <- function(file) {
    f <- file(file, "rb")
    on.exit(close(f))
    bb <- readBin(f, what="integer", size=1, n=3*256, signed=FALSE)
    mm <- matrix(bb, ncol=3, byrow=TRUE)
    rgb(mm, maxColorValue = 256)
}
