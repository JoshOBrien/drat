
##' @export
write_runscript_CHHR <- function(params, outputDir) {
    ## Prepare message for start of file
    HEADER <-
'## To reproduce the archived CHHR estimate, execute this script in an R
## session whose working directory is set to the directory containing
## this file:

library(BHSkde)

## Set path to results directory, creating it if it does not exist
results_dir <- "results"
dir.create(results_dir)

## Compute CHHR, saving it to a polygon shapefile in results_dir
'

    ## A trick to get an unquoted `results_dir` into call object
    params$outputDir <- as.symbol("results_dir")
    ## Construct call object and prepare it for printing
    CALL <- as.call(c(as.symbol("kdeHerd"), params))
    CALL <- deparse(CALL, width.cutoff = 20,
                 control = c("keepNA", "niceNames", "showAttributes"))
    CALL <- paste(c(CALL, "\n"), collapse="\n")

    ## Write out header and deparsed call to "runscript.R"
    outFile <- file.path(outputDir, "runscript.R")
    cat(HEADER, file = outFile)
    cat(CALL, file = outFile, append = TRUE)
}


