
## Exclude any GDB point or line layers from pull-down offering
##' @export
poly_layer_names <- function(gdb) {
    layers <- st_layers(gdb)
    is_poly <- sapply(layers[["geomtype"]],
                      function(x) {
                          grepl("Polygon", x, ignore.case = TRUE)
                      })
    layers[["name"]][is_poly]
}


## Given path to a geodatabase, find names of points layer
##' @export
point_layer_names <- function(gdb) {
    layers <- st_layers(gdb)
    is_point <- sapply(layers[["geomtype"]],
                       function(x) {
                           grepl("Point", x, ignore.case = TRUE)
                       })
    layers[["name"]][is_point]
}
