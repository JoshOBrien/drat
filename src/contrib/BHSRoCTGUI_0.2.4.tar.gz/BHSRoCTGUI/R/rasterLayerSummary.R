
##' @export
rasterLayerSummary <- function(RV)
{
    template <-
        paste("Habitat layer summary:\n\n",
              "  - File type:  GeoTiff\n",
              "  - File path:  %s\n")
    ## Extract info about currently-loaded layer from RV object
    filePath <- RV$HAB_file_path
    ## Plug info into template and print it out
    summary <- sprintf(template,
                dQuote(filePath))
    cat(summary)
}

## ## Example usage
##
## RV <- list(HAB_file_path = "C:/Users/User/Desktop/miniPayette.tif")
##
## rasterLayerSummary(RV)




