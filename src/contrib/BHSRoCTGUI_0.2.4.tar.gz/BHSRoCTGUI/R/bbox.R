##' @export
st_bbox_overall <- function(...) {
    ## Filter arguments, excluding character elements corresponding to
    ## as yet unpopulated elements of `RV` object
    dots <- list(...)
    dots <- dots[sapply(dots, function(X) !is.character(X))]
    ## Find then combine bounding boxes of one or more sf and
    ## RasterLayer objects
    bbox_as_sfc <- function(X) {
        st_as_sfc(st_bbox(X))
    }
    XX <- lapply(dots, bbox_as_sfc)
    st_bbox(do.call(c, XX))
}


##' @export
fitBounds_bbox <- function(map, bbox, options = list()) {
    fitBounds(map,
              lng1 = bbox[[1]], lat1 = bbox[[2]],
              lng2 = bbox[[3]], lat2 = bbox[[4]],
              options = options)
}


## When passed a bbox object, do the equivalent of:
##
## flyToBounds(map, lng1 = -120, lat1 = 45, lng2 = -115, lat2 = 47, options)
##
##' @export
flyToBounds_bbox  <- function(map, bbox, options = list()) {
    flyToBounds(map,
                lng1 = bbox[[1]], lat1 = bbox[[2]],
                lng2 = bbox[[3]], lat2 = bbox[[4]],
                options = options)
}



## ## (1) Minimal code to create leaflet map from a GDB
## library(sf)
## library(leaflet)
## gdb <- "sampleData/file-geodatabase/Payette.gdb"
##
## layers <- st_layers(gdb)[["name"]]
## CHHR <- st_read(gdb, layers[2]) %>% st_transform("+proj=longlat +datum=WGS84")
## CHHR1 <- st_read(gdb, layers[1]) %>%
##     st_transform("+proj=longlat +datum=WGS84")
## CHHR2 <- st_read(gdb, layers[2]) %>%
##     st_transform("+proj=longlat +datum=WGS84")
##
## st_bbox(CHHR1)
## st_bbox(CHHR2)
## st_bbox_overall(CHHR1, CHHR2)
