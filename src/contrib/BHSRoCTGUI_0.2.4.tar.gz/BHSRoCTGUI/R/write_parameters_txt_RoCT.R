
##' @export
write_parameters_txt_RoCT <- function(params, outputDir) {
    ## Prepare message for start of file
    message <-
'## The files in this directory contain all of the data and parameters
## used in the Risk of Contact Analysis whose results are stored in its
## parent directory. This file records all of the parameters needed to
## construct a command-line call that will reproduce that analysis.
##
## To reproduce the analysis, run the following from an R session whose
## working directory is set to the directory containing this file:
##
## library(BHSforay)
## library(yaml)
## params <- read_yaml("parameters.txt")
## do.call(compute_ROCT, params)

'
    ## Prepare the YAML section
    tmp <- tempfile()
    write_yaml(params, tmp)
    ## Write message then YAML to "parameters.txt"
    outFile <- file.path(outputDir, "parameters.txt")
    cat(message, file = outFile)
    cat(readLines(tmp), sep = "\n", file = outFile, append = TRUE)
}

## ## Usage:
## outputDir <- "C:/Users/User/Desktop"
## params <- list(a=1:10, b=month.name)
## write_parameters_txt_RoCT(params, outputDir)
