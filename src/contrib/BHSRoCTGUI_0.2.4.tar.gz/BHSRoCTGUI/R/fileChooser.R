
##' @export
fileChooser <- function(startDir = "", filter = "shp") {
    if (.Platform$OS.type == "windows") {
        ff <-
            switch(filter,
                   shp = matrix(c("Shapefiles (*.shp)", "*.shp"),
                                ncol = 2, dimnames = list("shapefiles")),
                   csv = matrix(c("CSV files (*.csv)", "*.csv"),
                                ncol = 2, dimnames = list("csv_files")),
                   tif = matrix(c("All Files (*.*)",
                                  "GeoTiff (*.tif,*.tiff)",
                                  "*.*", "*.tif;*.tiff"), ncol = 2,
                                dimnames = list(c("GeoTiff", "All Files"))),
                   NULL
                   )
        if (nzchar(startDir)) {
            startDir <- file.path(startDir, ".")
        }
        path <- choose.files(startDir, multi = FALSE, filters = ff)
        path <- normalizePath(path, winslash = "/")
        return(path)
    } else {
        ## Returns character(0) if cancelled without selection, to
        ## match behavior of the Windows-branch above.
        tryCatch(file.choose(), error = function(e) {character(0)})
    }
}

## Abandoned, 2020-03-05, in favor of the simpler approach above,
## which only fails to launch file explorer in front of browser ONCE,
## at start of session.
##
## Possible filter values are:
##     filter = "CSV files (*.csv)|*.csv"
##     filter = "shapefiles (*.shp)|*.shp"
##
## fileChooser <- function(startDir = "", filter = "shapefiles (*.shp)|*.shp") {
##   if (.Platform$OS.type == "windows") {
##       ## Handle case where directory at user-supplied path doesn't exist
##       startDir <- if(dir.exists(startDir)) {
##                       ## PowerShell expects paths w/backslash
##                       ## separators but NOT a backslash at end
##                       gsub("\\\\$", "", normalizePath(startDir))
##                   } else {
##                       ""
##                   }
##       ## TODO: Once packaged, use system.file() to find full path to *.ps1
##       powershell <-
##           "powershell -NoProfile -ExecutionPolicy Bypass -NoLogo -File"
##       script <-
##           system.file("utils", "fileChooser.ps1", package="BHSRoCTGUI")
##       ## script <- "helpers\\fileChooser\\fileChooser.ps1"
##       ## script <- "fileChooser.ps1"
##       cmd <- paste(powershell, dQuote(normalizePath(script), q='"'))
##       ## Prep two arguments to PowerShell script
##       startDir <- dQuote(startDir, q = '"')
##       filter <- dQuote(filter, q = '"')
##       system(paste(cmd, startDir, filter), intern = TRUE)
##   } else {
##       ## Returns character(0) if cancelled without selection, to
##       ## match behavior of the Windows-branch above.
##       tryCatch(file.choose(), error = function(e) {character(0)})
##   }
## }


## Usage:
##
## fileChooser("C:/Program Files/")
## fileChooser("~/Desktop", "All Files (*.*)|*.*")



##------------------------------------------------------------------------------
## ORIGINAL CODE (INCLUDING BAT/POWERSHELL HYBRID OPTION)
##------------------------------------------------------------------------------

## startDir <- "C:/Program Files/"
##
## ## Handle case in which directory at user-supplied path doesn't exist
## startDir <-
##     if (dir.exists(startDir)) {
##         startDir
##     } else {
##         ""
##     }
##
## ## Option 1: Use bat/Powershell hybrid
## args <- dQuote(normalizePath(startDir), q = '"')
## system(paste("fileChooser.bat", args), intern = TRUE)
##
## ## Option 2: User Powershell script
## cmd <- "powershell -NoProfile -ExecutionPolicy Bypass -NoLogo -File fileChooser.ps1"
## args <- dQuote(normalizePath(startDir), q = '"')
## system(paste(cmd, args), intern = TRUE)
