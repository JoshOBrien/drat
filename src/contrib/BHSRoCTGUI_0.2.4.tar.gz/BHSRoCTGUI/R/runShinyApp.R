## Based on example in https://deanattali.com/2015/04/21/r-package-shiny-app/
##' @importFrom shiny runApp
##' @export
runShinyApp <- function() {
    appDir <- system.file("shiny-app", package = "BHSRoCTGUI")
    if(appDir == "") {
        stop("Could not find shiny-app directory. ",
             "Try re-installing BHSRoCTGUI.",
             call. = FALSE)
    }
    runApp(appDir, display.mode = "normal", launch.browser = TRUE)
}
