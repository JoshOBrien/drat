
##' @export
st_read_WGS84 <- function(dsn, layer, ...) {
    if (is_GDB(dsn)) {
        x <- read_GDB(dsn, layer, ...)
    } else {
        x <- st_read(dsn, layer, ...)
    }
    if (!all(st_is_valid(x))) {
        x <- st_make_valid(x)
    }
    st_transform(x, "+proj=longlat +datum=WGS84")
}
