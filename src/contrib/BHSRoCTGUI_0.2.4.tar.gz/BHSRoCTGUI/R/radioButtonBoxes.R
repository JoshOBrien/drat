## This copied from ../demos/radioButtonBoxes/radioButtonBoxes.R. For
## a usage example, see ../demos/radioButtonBoxes/app.R

## Follows the general pattern used by shiny::radioButton():
##
## - `shiny:::normalizeChoicesArgs()` processes arguments `choices`,
##   `choiceNames`, and `choiceValues` to produce a list with the
##   latter two of those.
##
## - For more details, see demos/radioButtonBoxes/Notes.org
##

##' @export
radioButtonBoxes <- function(inputId, label, choices = NULL,
                        selected = NULL, choiceNames = NULL,
                        choiceValues = NULL) {
    ## Argument preparation modeled on shiny::radioButtons
    args <- shiny:::normalizeChoicesArgs(choices, choiceNames, choiceValues)
    selected <- restoreInput(id = inputId, default = selected)
    selected <- if (is.null(selected)) {
                    args$choiceValues[[1]]
                } else {
                    as.character(selected)
                }
    if (length(selected) > 1)
        stop("The 'selected' argument must be of length 1")
    ## parallels call to shiny:::generateOptions() in shiny::radioButtons()
    ids <- paste0(inputId, "_box_", seq_along(args$choiceValues))
    genOpts <- function(choice, value, id, selected) {
        inputTag <- tags$input(type="radio", `id`=id,
                               `name`=inputId, `value`=value)
        if (value %in% selected)
            inputTag$attribs$checked <- NA
        labelTag <- tags$label(choice, `for`=id)
        tagList(inputTag, labelTag)
    }
    options <- mapply(genOpts, choice = args$choiceNames,
                      value = args$choiceValues,
                      id = ids,
                      MoreArgs = list(selected = selected),
                      SIMPLIFY = FALSE, USE.NAMES = FALSE)
    divClass <- "radio-toolbar shiny-input-radiogroup shiny-input-container shiny-input-container-inline"
    tags$div(id = inputId, class = divClass, options)
}

## Usage:
##
## radioButtonBoxes(inputId = "radios", label = "",
##                  choiceNames = c("All", "Open", "Archived"),
##                  choiceValues = c("all", "false", "true"),
##                  selected = "false")
##
## radioButtonBoxes(inputId = "radios", label = "",
##                  choices = c("All"="all", "Open"="false", "Archived"="true"))
##
## radioButtonBoxes(inputId = "radios", label = "",
##                  choices = c("All", "Open"))
##
##
## <div id="radios" class="radio-toolbar shiny-input-radiogroup shiny-input-container shiny-input-container-inline">
##   <input type="radio" id="box_1" name="radios" value="All" checked/>
##   <label for="box_1">All</label>
##   <input type="radio" id="box_2" name="radios" value="Open"/>
##   <label for="box_2">Open</label>
## </div>

