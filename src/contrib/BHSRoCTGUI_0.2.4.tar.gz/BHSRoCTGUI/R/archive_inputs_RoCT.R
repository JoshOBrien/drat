
## Write inputs, parameters, and runscript to Archive directory
##' @export
archive_inputs_RoCT <- function(archiveDir, params) {
    ## Copy of parameter list, to be modified to point at archived
    ## copies of data
    pp <- params

    ## Save HABITAT layer to geotiff
    file.copy(pp$HAB, archiveDir)
    pp$HAB <- basename(pp$HAB)

    ## Save habitat preferences (if habitat raster is categorical)
    if (pp$is_categorical_habitat) {
        file.copy(pp$HabPrefTable, to = archiveDir)
    }
    pp$HabPrefTable <- basename(pp$HabPrefTable)

    ## Save CHHR layer to geopackage
    CHHR_gpkg <- paste(gsub(".", "_", basename(pp$CHHR), fixed = TRUE),
                       collapse = "-")
    CHHR_gpkg <- paste0(CHHR_gpkg, ".gpkg")
    ogr2ogr(pp$CHHR[1],
            file.path(archiveDir, CHHR_gpkg),
            layer = pp$CHHR[2],
            f = "GPKG",
            overwrite = TRUE,
            nlt = "MULTIPOLYGON")
    pp$CHHR <- CHHR_gpkg

    ## Save CHHR layer to geopackage
    ALLOTS_gpkg <- paste(gsub(".", "_", basename(pp$ALLOTS), fixed = TRUE),
                         collapse = "-")
    ALLOTS_gpkg <- paste0(ALLOTS_gpkg, ".gpkg")
    ogr2ogr(pp$ALLOTS[1],
            file.path(archiveDir, ALLOTS_gpkg),
            layer = pp$ALLOTS[2],
            f = "GPKG",
            overwrite = TRUE,
            nlt = "MULTIPOLYGON")
    pp$ALLOTS <- ALLOTS_gpkg

    ## Archive foray distance distribution files
    file.copy(pp$FD_ram, to = archiveDir)
    file.copy(pp$FD_ewe, to = archiveDir)
    pp$FD_ram <- basename(pp$FD_ram)
    pp$FD_ewe <- basename(pp$FD_ewe)

    ## Write out YAML file that can be used to reproduce the analysis
    pp$foray_prob_raster_dir <- "."
    write_parameters_txt_RoCT(params = pp, outputDir = archiveDir)
    write_runscript_RoCT(params = pp, outputDir = archiveDir)

    ## Add README.txt, describing the directory's contents
    README <- system.file(package = "BHSRoCTGUI",
                          "inst/shiny-app/extras/README-RoCT.txt")
    file.copy(README, file.path(archiveDir, "README.txt"))
}
