##' @export
is_GDB <- function(path) {
    tryCatch(
    {
        st_layers(path)[["driver"]] == "OpenFileGDB"
    },
    error = function(e) {
        ## message("Handling error: ", conditionMessage(e))
        return(FALSE)
    })
}

##' @export
is_GDB_with_points <- function(path) {
    tryCatch(
    {
        XX <- st_layers(path)
        if (!any(grepl("point", unlist(XX$geomtype), ignore.case=TRUE))) {
            msg <- "This GDB contains no POINTS or MULTIPOINTS features"
            shinyalert(title = "Invalid spatial input",
                       text = msg,
                       type = "error")
            return(FALSE)
        }
        XX[["driver"]] == "OpenFileGDB"
    },
    error = function(e) {
        ## message("Handling error: ", conditionMessage(e))
        return(FALSE)
    })
}

##' @export
is_GDB_with_polygons <- function(path) {
    tryCatch(
    {
        XX <- st_layers(path)
        if (!any(grepl("polygon", unlist(XX$geomtype), ignore.case=TRUE))) {
            msg <- "This GDB contains no POLYGONS or MULTIPOLYGONS features"
            shinyalert(title = "Invalid spatial input",
                       text = msg,
                       type = "error")
            return(FALSE)
        }
        XX[["driver"]] == "OpenFileGDB"
    },
    error = function(e) {
        ## message("Handling error: ", conditionMessage(e))
        return(FALSE)
    })
}


##' @export
is_valid_GDB_layer <- function(gdb, layerName) {
    tryCatch(
    {
        capture.output({
            ## Is this a readable GDB layer?
            shp <- read_GDB(gdb, layerName)
            ## Can it be projected into UTM coordinates?
            zone <- find_UTM_zone(shp)
            shp <- project2UTM(shp, zone)

        },
            tempfile())
        return(TRUE)
    },
    error = function(e) {
        ## message("Handling error: ", conditionMessage(e))
        return(FALSE)
    })
}


##' @export
is_valid_SHP <- function(path) {
    tryCatch(
    {
        capture.output({
            ## Is this a readable shapefile?
            shp <- st_read(path, drivers = "ESRI Shapefile")
            ## Can it be projected into UTM coordinates?
            zone <- find_UTM_zone(shp)
            shp <- project2UTM(shp, zone)
        },
        tempfile())
        return(TRUE)
    },
    error = function(e) {
        ## Silently handle non-choice (character(0)); otherwise, warn.
        if (length(path)) {
            msg<-paste("The selected file does not appear to be a valid shapefile:\n",
                       path)
            shinyalert(title = "Problem reading shapefile",
                       text = msg,
                       type = "error")
        }
         return(FALSE)
    })
}


##' @export
is_sf <- function(obj) {
    inherits(obj, "sf")
}


## Tests, among other things, for a `character(0)` returned when user
## backs out of `fileChooser()` without selecting a file.
##' @export
is_valid_csv <- function(path) {
    tryCatch(
    {
        data.table::fread(path)
        return(TRUE)
    },
    error = function(e) {
        return(FALSE)
    })
}


## is_raster_file()
##
## A nice approach to reading in part of a raster at
## https://stackoverflow.com/a/50839673/980833
##
## GDALinfo() might also be a nice way to test for
##
## gdalDrivers() for the full set of raster-readable formats
##
## Might want to do tryCatch, returning FALSE if not a good file, and
## assigning the value to RV$HAB, so we just read the raster in once

##' @export
is_raster_file <- function(filePath) {
    tryCatch(class(suppressWarnings(GDALinfo(filePath)))=="GDALobj",
             error = function(e) {FALSE})
}

##' @export
is_raster <- function(obj) {
    inherits(obj, "RasterLayer")
}


## Test whether an sf object's projection expresses coordinates in
## units of meters by checking that the projection: (a) is not
## longlat; and (b) comes with no multiplier factor for converting
## units to meters.
##' @export
is_proj_in_meters <- function(obj) {
    !is.na(st_crs(obj)) &
        !st_is_longlat(obj) &
         is.null(st_crs(obj)$to_meter)
}
##
## ## Example polygon in Trinidad and Tobago, from Spacedman, here
## ## https://github.com/r-spatial/sf/issues/1170#issuecomment-539208984
## g <- st_as_sfc("POLYGON ((-61.66957 10.69214, -61.565 10.75728, -61.37453 10.77654, -61.40721 10.60681, -61.66957 10.69214))")
## ## (1) No CRS supplied
## a <- st_as_sf(data.frame(id = 1, geometry = g))
## st_crs(a)$to_meter ## NA
## st_is_longlat(a)   ## NA
## ## (2) WGS 84 projection
## b <- st_as_sf(data.frame(id = 1, geometry = g), crs = 4326)
## st_crs(b)$to_meter ## NULL
## st_is_longlat(b)   ## [1] TRUE
## ## (3) 1903 Trinidad grid, using Clarke's foot as unit of measure (prior
## ##     to 1959 standardization of Imperial foot)
## c <- st_transform(b, 2314)
## st_crs(c)$to_meter ## [1] 0.30479726540000002
## st_is_longlat(c)   ## [1] FALSE
## ## (4) One of two UTM zones applied to Trinidad and Tobago
## d <- st_transform(b, 32621)
## st_crs(d)$to_meter ## NULL
## st_is_longlat(d)   ## [1] FALSE
##
## ## Testing `is_proj_in_meters()`
## sapply(list(a,b,c,d), is_proj_in_meters)
## ## [1] FALSE FALSE FALSE  TRUE
