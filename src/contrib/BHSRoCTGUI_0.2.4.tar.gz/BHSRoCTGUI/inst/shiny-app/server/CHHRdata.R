##------------------------------------------##
##  CHHR ESTIMATOR DATA UPLOAD TAB: SERVER  ##
##------------------------------------------##

## Handle BHS locations file type selection
output$PTS_file_type_selected <- renderText(input$PTS_file_type)
observeEvent(input$PTS_file_type, {
  toggle(id = "upload_PTS_shp",
         condition = input$PTS_file_type == "shp")
  toggle(id = "upload_PTS_gdb",
         condition = input$PTS_file_type == "gdb")
})


##------------------------------------------------------------------------------
## Shapefile layer upload
##------------------------------------------------------------------------------

observeEvent(input$upload_PTS_shp, {
  filePath <- fileChooser(RV$POLY_search_dir)
  if (is_valid_SHP(filePath)) {
    XX <- st_read_WGS84(filePath)
    if (!all(st_geometry_type(XX) %in% c("POINT", "MULTIPOINT"))) {
      msg <- "CHHR estimation requires a POINTS feature class"
      shinyalert(title = "Invalid spatial input",
                 text = msg,
                 type = "error")
    } else {
      if (!is_proj_in_meters(st_read(filePath))) {
        msg <- "Location data must be in a coordinate reference system with units of meters"
        shinyalert(title = "Invalid spatial input",
                   text = msg,
                   type = "error")
      } else {
        RV$PTS_is <- "SHP"
        RV$PTS_SHP_path <- filePath
        RV$POLY_search_dir <- dirname(filePath)
        RV$PTS <- XX
        RV$PTS_ID_column <- ""
        ## Clear out GDB inputs
        RV$PTS_GDB_path <- "~"
        RV$PTS_GDB_layer <- ""
        RV$PTS_GDB_path_valid <- FALSE
        OKHR$Data <- FALSE
      }
    }
  }
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## GDB layer upload
##------------------------------------------------------------------------------

## GDB directory selection
observeEvent(input$select_PTS_GDB_path, {
  filePath <- choose.dir(default = RV$POLY_search_dir,
                         caption = "Choose a directory...")
  if (is_GDB_with_points(filePath)) {
    RV$PTS_GDB_path <- filePath
    RV$PTS_GDB_path_valid <- TRUE
    RV$POLY_search_dir <- dirname(filePath)
  } else {
  }
}, ignoreInit = TRUE)
## GDB layer selection (conditional drop-down selector)
observeEvent(RV$PTS_GDB_path, {
  toggle("select_PTS_GDB_layer", condition = is_GDB(RV$PTS_GDB_path))
  if (is_GDB(RV$PTS_GDB_path)) {
    updateSelectInput(session, "select_PTS_GDB_layer",
                      choices = point_layer_names(RV$PTS_GDB_path))
  }
}, ignoreInit = TRUE)
## GDB layer upload
observeEvent(input$select_PTS_GDB_layer, {
  gdb <- RV$PTS_GDB_path
  layerName <- input$select_PTS_GDB_layer
  if (is_valid_GDB_layer(gdb, layerName)) {
    if (!is_proj_in_meters(st_read(gdb, layerName))) {
      msg <- "Location data must be in a coordinate reference system with units of meters"
      shinyalert(title = "Invalid spatial input",
                 text = msg,
                 type = "error")
    } else {
      RV$PTS_is <- "GDB"
      RV$PTS_GDB_layer <- layerName
      RV$PTS <- st_read_WGS84(gdb, layerName)
      ## Clear out SHP input
      RV$PTS_SHP_path <- ""
      RV$PTS_ID_column <- ""
      OKHR$Data <- FALSE
    }
  }
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Animal ID-column selection (both Shapefile & GDB layers)
##------------------------------------------------------------------------------

## Display annimal ID-column selector when locations layer is loaded
observeEvent(RV$PTS, {
  toggle("PTS_ID_column", condition = is_sf(RV$PTS))
  if (is_sf(RV$PTS)) {
    updateSelectInput(session, "PTS_ID_column",
                      choices = names(RV$PTS))
  }
})
## Register choice of ID-column in RV
observeEvent(input$PTS_ID_column, {
  RV$PTS_ID_column <- input$PTS_ID_column
  OKHR$Data <- TRUE
}, ignoreInit = TRUE)
## Hide ID-column selector when you are not on appropriate shp/gdb tab
observeEvent({RV$PTS_is; input$PTS_file_type}, {
  toggle("PTS_ID_column", condition = {
    identical(RV$PTS_is, toupper(input$PTS_file_type))
  })
})


##------------------------------------------------------------------------------
## Report info on currently loaded layer (Shapefile or GDB)
##------------------------------------------------------------------------------

observeEvent(RV$PTS, {
  toggle("PTS_info", condition = RV$PTS_is %in% c("SHP", "GDB"))
  output$PTS_info <-
    renderPrint(spatialLayerSummary(RV, "PTS", RV$PTS_is))
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Conditionally hide/show check marks
##------------------------------------------------------------------------------

## Successfully selected a GDB
observeEvent({RV$PTS_GDB_path; input$PTS_file_type}, {
  toggle("dash_PTS_GDB_path",
         condition = {
           !RV$PTS_GDB_path_valid & (input$PTS_file_type == "gdb")
         })
  toggle("check_PTS_GDB_path",
         condition = {
           RV$PTS_GDB_path_valid & (input$PTS_file_type == "gdb")
         })
})

## Successfully uploaded a GDB or shapefile layer
observeEvent({RV$PTS_is; input$PTS_file_type; RV$PTS_GDB_path}, {
  toggle("dash_PTS_shp",
         condition = (RV$PTS_is != "SHP") & (input$PTS_file_type == "shp"))
  toggle("check_PTS_shp",
         condition = (RV$PTS_is == "SHP") & (input$PTS_file_type == "shp"))
  toggle("dash_PTS_GDB_layer",
         condition = (RV$PTS_is != "GDB") & (input$PTS_file_type == "gdb") &
           (RV$PTS_GDB_path != "~"))
  toggle("check_PTS_GDB_layer",
         condition = (RV$PTS_is == "GDB") & (input$PTS_file_type == "gdb"))
}, ignoreInit = TRUE)

## Successfully selected an Allotment ID column
observeEvent({RV$PTS_ID_column; RV$PTS_is; input$PTS_file_type}, {
  toggle("dash_PTS_ID_column",
         condition = {
           !nchar(RV$PTS_ID_column) &
             identical(RV$PTS_is, toupper(input$PTS_file_type))
         })
  toggle("check_PTS_ID_column",
         condition = {
           nchar(RV$PTS_ID_column) &
             identical(RV$PTS_is, toupper(input$PTS_file_type))
         })
})



## // Local Variables:
## // ess-indent-offset: 2
## // End:
