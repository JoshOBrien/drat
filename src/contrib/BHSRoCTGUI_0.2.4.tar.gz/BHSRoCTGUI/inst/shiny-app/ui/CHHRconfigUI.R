##---------------------------------##
##  CHHR ESTIMATOR CONFIG TAB: UI  ##
##---------------------------------##

tabPanel("2. Configure CHHR estimator",
  useShinyjs(),
  useShinyalert(),
  fluidPage(
    ## Set Minimum Points per Animal --> "minObs"
    fluidRow(
      column(3),
      column(4,
        numericInput("minObs",
                     "Minimum Points Per Animal",
                     value = 21, min = 1)
        ),
      column(1,
             span(greyDash("dash_MinPPA", yShift = -20),
                  greenCheck("check_MinPPA", yShift = -20))),
      column(4)
    ),

    ##  Select Bandwidth Estimator --> "bwEstimator"
    fluidRowWidgetCheck(
      selectInput("bwEstimator",
                  label = "Bandwidth Estimator",
                  choices = c("Reference" = "Href",
                              "Plug-in" = "Hpi"),
                  selected = "Reference"),
      span()
    ),

    ## Set Percent of h_ref  --> 100 * "bwMultiplier"
    fluidRow(
      column(3),
      column(4,
        numericInput("bwMultiplier_100",
                     "Percent of h_ref",
                     value = 100, min = 5, step = 5)
        ),
      column(5)
    ),

    ## Set Max Isopleth Quantile --> 100 * "cont"
    fluidRow(
      column(3),
      column(4,
        numericInput("cont_100",
                     "Max Isopleth Quantile",
                     value = 95, min = 1, max = 99)
        ),
      column(5)
    )


  ))


## // Local Variables:
## // ess-indent-offset: 2
## // End:
