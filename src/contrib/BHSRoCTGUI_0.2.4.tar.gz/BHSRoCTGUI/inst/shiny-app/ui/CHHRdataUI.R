##--------------------------------------##
##  CHHR ESTIMATOR DATA UPLOAD TAB: UI  ##
##--------------------------------------##

tabPanel("1. Load bighorn locations",
  fluidPage(
    fluidRow(
      column(1),
        column(10, align = "center",
          ## BHS locations file type selection (SHP or GDB)
          radioButtonBoxes(inputId = "PTS_file_type", label = "",
                           choices = c("Locations from shapefile" = "shp",
                                       "Locations from GDB" = "gdb"),
                           selected = character(0))
          ),
      column(1),
      br(), br(), br()
    ),
    ## BHS locations shapefile upload
    fluidRowWidgetCheck(
      hidden(actionButton("upload_PTS_shp",
                          "Upload BHS locations shapefile",
                          width = "100%")),
      span(greyDash("dash_PTS_shp"),
           greenCheck("check_PTS_shp"))
    ),

    hidden(div(id = "upload_PTS_gdb",
      ## BHS locations GDB directory selection
      fluidRowWidgetCheck(
        actionButton("select_PTS_GDB_path",
                     "Select GDB containing BHS locations feature class",
                     width = "100%"),
        span(greyDash("dash_PTS_GDB_path"),
             greenCheck("check_PTS_GDB_path"))
      ),
      ## BHS locations GDB layer selectors
      fluidRowWidgetCheck(
        selectizeInput("select_PTS_GDB_layer", label = "",
                       choices = "", selected = "",
                       options = list(
                         placeholder = "Select BHS locations feature class",
                         onInitialize=I('function() { this.setValue(""); }')),
                       width = "100%"),
        span(greyDash("dash_PTS_GDB_layer", yShift = -12),
             greenCheck("check_PTS_GDB_layer", yShift = -12))
      )
      )),

      ## Allotment ID column selector
      fluidRowWidgetCheck(
        selectizeInput("PTS_ID_column", label = "",
                       choices = "", selected = "",
                       options = list(
                         placeholder = "Select Animal ID column",
                         onInitialize=I('function() { this.setValue(""); }')),
                       width = "100%"),
        span(greyDash("dash_PTS_ID_column", yShift = -12),
             greenCheck("check_PTS_ID_column", yShift = -12))
      ),

    fluidRow(
      br(),
      column(12, align = "center",
        ## Display info about loaded BHS locations
        div(align = "left", verbatimTextOutput("PTS_info"))
        )
    )
  ))


## // Local Variables:
## // ess-indent-offset: 2
## // End:
