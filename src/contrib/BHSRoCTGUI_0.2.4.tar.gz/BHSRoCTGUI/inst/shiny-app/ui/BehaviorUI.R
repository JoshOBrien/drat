##--------------------##
##  BEHAVIOR TAB: UI  ##
##--------------------##

tabPanel("5. Input foray behavior",
  useShinyjs(),
  useShinyalert(),
  fluidPage(theme = "radioButtonBoxes.css",

    ##--------------------------------------------------------------------------
    ## Foray frequencies
    ##--------------------------------------------------------------------------
    fluidRow(
      column(3,
             br(), br(), br(),
             checkboxInput("useDefaultForayProbs",
                           label = "Use default foray frequencies",
                           value = FALSE)),
      column(6,
      numericInput("RamForayProb",
                   "Ram foray frequency",
                   NULL, min = 0, max = Inf, step = 0.001,
                   width = "100%"),
      br(),
      numericInput("EweForayProb",
                   "Ewe foray frequency",
                   NULL, min = 0, max = Inf, step = 0.001,
                   width = "100%")
      ),
      column(1,
             br(), br(), br(),
             span(greyDash("dash_ForayProbs", yShift = -6),
                  greenCheck("check_ForayProbs", yShift = -6))),
      column(2)),
    br(),
    hr(),
    ##--------------------------------------------------------------------------
    ## Ram foray distance file upload
    ##--------------------------------------------------------------------------

    ## Search for and upload RFD
    fluidRow(
      column(3,
             checkboxInput("useDefaultRFD",
                           label = "Use default ram distance distribution",
                           value = FALSE)),
      column(6,
             actionButton("upload_RFD_file",
                   "Upload Ram Foray Distance file", width = "100%")),
      column(1,
             span(greyDash("dash_RFD_file"),
                  greenCheck("check_RFD_file"))),
      column(2)),

    ## Display info about loaded CHHR
    fluidRow(
      br(),
      column(12, align = "center",
             div(align = "left", verbatimTextOutput("RFD_info"))),
      hr()
    ),

    ##--------------------------------------------------------------------------
    ## Ewe foray distance file upload
    ##--------------------------------------------------------------------------

    ## Search for and upload RFD
    fluidRow(
      column(3,
             checkboxInput("useDefaultEFD",
                           label = "Use default ewe distance distribution",
                           value = FALSE)),
      column(6,
             actionButton("upload_EFD_file",
                   "Upload Ewe Foray Distance file", width = "100%")),
      column(1,
             span(greyDash("dash_EFD_file"),
                  greenCheck("check_EFD_file"))),
      column(2)),

    ## Display info about loaded CHHR
    fluidRow(
      br(),
      column(12, align = "center",
             div(align = "left", verbatimTextOutput("EFD_info"))),
      hr()
    )


  ))



## // Local Variables:
## // ess-indent-offset: 2
## // End:
