##' Limit plot extent to spatial object's bounding box
##'
##' Strategy from
##' \url{https://github.com/paleolimbot/ggspatial/issues/67}
##' @title Limit plot extent to spatial object's bounding box
##' @param X Any spatial object for which a \code{sf::st_bbox()}
##'     method is defined.
##' @return An object like that returned by a call to
##'     \code{ggplot2::coord_sf()}, which will set the limits of the
##'     area to be plotted.
##' @importFrom sf st_bbox
##' @importFrom ggplot2 coord_sf
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' if (require(ggspatial)) {
##'     LUX <- st_read(system.file("external/lux.shp", package="raster"))
##'     Wiltz <- LUX %>% subset(NAME_2 == "Wiltz")
##'
##'     ggplot() +
##'         layer_spatial(LUX) +
##'         layer_spatial(Wiltz, fill = adjustcolor("red", alpha = 0.5)) +
##'         compute_coord_sf(Wiltz) +
##'         scale_x_continuous(expand = expansion(mult = 0.00)) +
##'         scale_y_continuous(expand = expansion(mult = 0.00))
##' }
##' }
compute_coord_sf <- function(X) {
    map.bounds <- st_bbox(X)
    coord_sf(xlim = c(map.bounds["xmin"], map.bounds["xmax"]),
             ylim = c(map.bounds["ymin"], map.bounds["ymax"]))
}
