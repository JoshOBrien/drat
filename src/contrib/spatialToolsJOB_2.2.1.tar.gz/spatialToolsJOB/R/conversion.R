

##' This function makes it easy for me to save in a format that can be
##' imported to the Avenza maps app or viewed with Google Earth.
##'
##' @title Write sf object to a KMZ file
##' @param SF A simple features object of class \code{sf}.
##' @param path The path to which which you'd like the KMZ file to be
##'     written.
##' @return Called for its side-effect, but does return the path to
##'     which the KMZ file was just written.
##' @importFrom zip zip
##' @importFrom fs file_temp dir_create dir_delete
##' @importFrom fs path path_dir path_file path_ext_set
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' nc <- st_read(system.file(package="sf", "gpkg", "nc.gpkg"))
##' nc2 <- spatialData::counties %>% subset(STATEFP == 37)
##' write_kmz(nc, "nc.kmz")
##' write_kmz(nc2, "nc2.kmz")
##' }
write_kmz <- function(SF, path) {
    dir_create(tmpdir <- file_temp())
    on.exit(dir_delete(tmpdir))
    path_kml <- path(tmpdir, path_ext_set(path_file(path), "kml"))
    dir_kmz <- path_dir(path)
    file_kmz <- path_ext_set(path_file(path), "kmz")
    st_write(SF, path_kml, append = FALSE)
    zip(path_kml, zipfile = file_kmz, root = dir_kmz,
        mode = "cherry-pick")
    invisible(path(dir_kmz, file_kmz))
}


##' This function makes it easy for me to save in the format needed by
##' the USFWS IPaC website.
##'
##' I used this when requesting lists of TES insect and plant species
##' in USFS and BLM admin units from
##' \url{https://ecos.fws.gov/ipac/location/index}.
##' @title Write sf object to zipped shapefile
##' @param SF A simple feature object of class \code{sf}.
##' @param path The path to which you'd like the zipped shapefile to
##'     be written
##' @return A zip file (with extension ".zip") containing a shapefile
##'     storing SF.
##' @importFrom fs path_wd
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' nc <- st_read(system.file(package="sf", "gpkg", "nc.gpkg"))
##' write_zipped_shp(nc, "nc.zip")
##' }
write_zipped_shp <- function (SF, path) {
    ## Need fully expanded path to write to directory other than
    ## "root".
    path_zip <- path_ext_set(path_wd(path), "zip")
    ## Write shapefile to temporary directory
    dir_create(tmpdir <- file_temp())
    on.exit(dir_delete(tmpdir))
    path_shp <- path(tmpdir, path_ext_set(path_file(path), "shp"))
    st_write(SF, path_shp, append = FALSE)
    ## Collect shapefile components in zipfile
    zip(zipfile = path_zip, files = dir(tmpdir), root = tmpdir,
        mode = "cherry-pick")
    invisible(path_zip)
}
