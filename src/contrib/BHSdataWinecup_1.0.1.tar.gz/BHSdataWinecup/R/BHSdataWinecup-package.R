##' Spatial data from Winecup analysis
##'
##' \tabular{ll}{
##' Package: \tab BHSdataWinecup\cr
##' Type: \tab Package\cr
##' Version: \tab 1.0\cr
##' Date: \tab 2021-04-10\cr
##' License: \tab GPL (>= 2)\cr
##' LazyLoad: \tab yes\cr
##' }
##'
##' Data used in BLM Winecup analysis
##'
##' @name BHSdataWinecup-package
##' @aliases BHSdataWinecup
##' @docType package
##' @title Spatial data from Winecup analysis.
##' @author Joshua O'Brien \email{joshmobrien@@gmail.com}
##' @keywords package
##' @import sf
NULL
