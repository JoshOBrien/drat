##' Bind together telemetry data from five Winecup analysis herds into
##' one POINTS object
##'
##' @title Combine Winecup analysis herds telemetry
##' @return
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' ALL <- combine_herds()
##' }
combine_herds <- function() {
    nms <- intersect(names(LH), names(SS))
    BL <- cbind(herd = "BL", BL[nms])
    EH <- cbind(herd = "EH", EH[nms])
    LH <- cbind(herd = "LH", LH[nms])
    SR <- cbind(herd = "SR", SR[nms])
    SS <- cbind(herd = "SS", SS[nms])
    ALL <- rbind(BL, EH, LH, SR, SS)
    ALL
}
