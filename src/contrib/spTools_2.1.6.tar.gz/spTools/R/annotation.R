
##' Automate scalebar construction.
##'
##' More to come...
##' @title More-automatic scalebar construction
##' @param bb A bbox object giving limits of the plotted data.
##' @param pos A length-two numeric vector giving x-y coordinates of
##'     the scalebar's lower-left corner. So, for lower-left (the
##'     default) set pos=c(0.05,0.05), and for lower-right, set
##'     pos=c(0.8,0.05).
##' @param conversionFactor Conversion factor between input and output
##'     units. So, for example, to print scalebar's length in km for
##'     data given in meters (e.g. a UTM projection) set
##'     conversionFactor=1/1000
##' @param outUnit String giving name of units printed on
##'     scalebar. Defaults to "m" for meters.
##' @param outUnitMult Factor by which to multiply length given in
##'     on-the-ground units (e.g. meters) to get it in terms of the
##'     units drawn on the scalebar. If units referenced by the
##'     scalebar are meters (from a UTM projection), but we want
##'     \code{outUnit="km"}, \code{outUnit} should be set to
##'     \code{0.001}.
##' @param cex A number giving the cex of the text used to annotate
##'     the scalebar.
##' @return A list of the form taken by spplot's sp.layout
##'     argument. The list consists of three elements, used to print
##'     the scalebar and its two textual annotations.
##' @export
##' @author Joshua O'Brien
##' @examples
##' library(lattice)
##' trellis.par.set(sp.theme()) # sets color ramp to bpy.colors()
##' data(meuse)
##' coordinates(meuse) = ~x+y
##' scalebar <- makeScalebar(bbox(meuse))
##' scalebar <- makeScalebar(bbox(meuse), pos = c(0.7,0.05),
##'                          conversionFactor = 1/1000, outUnit = "km")
##'
##' spplot(meuse, "zinc", do.log = TRUE,
##' 	   key.space = list(x = 0.1, y = 0.93, corner = c(0, 1)),
##' 	   sp.layout = scalebar,
##' 	   main = "Zinc (top soil)")
makeScalebar <- function(bb, pos = c(0.05,0.05),
                         conversionFactor = 1,
                         outUnit = "m", outUnitMult = 1,
                         cex = 1) {
    width <- conversionFactor*diff(bb[1,])
    lenOut <- diff(pretty(c(0, width)))[1]
    lenIn <- lenOut/conversionFactor
    ## x-left, x-right, y-bottom, y-top
    xl <- bb[1,1] + pos[1]*(diff(bb[1,]))
    xr <- xl + lenIn
    yb <- bb[2,1] + pos[2]*(diff(bb[2,]))
    yt <- yb + 0.04*diff(bb[2,])
    ## Construct sp.layout-ready list
    scale <- list("SpatialPolygonsRescale", layout.scale.bar(),
                  offset = c(xl, yb), scale = lenIn,
                  fill = c("transparent", "black"))
    text1 <- list("sp.text", c(xl, yt), "0", cex = cex)
    text2 <- list("sp.text", c(xr, yt),
                  paste(round(lenOut*outUnitMult, 2), outUnit),
                  cex = cex)
    list(scale=scale, text=text1, text2=text2)
}
