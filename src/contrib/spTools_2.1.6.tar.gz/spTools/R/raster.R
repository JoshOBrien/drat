
##' Inspired by code at \url{https://gis.stackexchange.com/a/252893/5720}
##'
##' @title Find the extent of a list of rasters
##' @param rasters A list of rasters
##' @return An Extent object
##' @export
##' @author Joshua O'Brien
extent_all_rasters <- function(rasters){
    Reduce(union, sapply(rasters, raster::extent))
}


##' Inspired by code at \url{https://gis.stackexchange.com/a/252893/5720}
##'
##' @title Sum together well-registered rasters with possibly
##'     different extents
##' @param rasters A list of rasters
##' @param extent Optionally provide an extent over which the rasters
##'     will be summed
##' @return A raster that is the sum of all supplied rasters
##' @export
##' @author Joshua O'Brien
sum_all_rasters <- function(rasters, extent = extent_all_rasters(rasters)){
    re = lapply(rasters, function(r) {raster::extend(r, extent, value = 0)})
    Reduce("+", re)
}



##' An alternative to raster::reclassify()
##'
##' @title Reclassify a continuous raster by cutting at breaks
##' @param x A continuous (non-factor) raster
##' @param breaks An numeric vector of (ordered) breakpoints. It will
##'     often useful to set the first and last values be \code{-Inf}
##'     and \code{Inf}.
##' @param names A vector of names to be given to the categories
##'     defined by \code{breaks}. The vector should have one fewer
##'     element than \code{breaks}.
##' @param ... Additional arguments to be passed on to
##'     \code{raster::reclassify()}.
##' @return A categorical raster, whose RAT includes a column named
##'     \code{"value"} with the values passed in via the \code{names}
##'     argument.
##' @export
##' @author Joshua O'Brien
##' @examples
##' r <- raster(system.file("external/test.grd", package="raster"))
##' rc <- classify_raster(r, breaks = c(-Inf, 450, 900, 1350, Inf),
##'                       names = c("low", "medium", "high", "highest"))
##' rasterVis::levelplot(rc)
##'
classify_raster <-
    function(x,
             breaks,
             names = LETTERS[seq_len(length(breaks) - 1)],
             ...)
{
    names <- factor(names, levels = names)
    DF <- data.frame(from = breaks[-length(breaks)],
                     to = breaks[-1],
                         names = as.numeric(names))
    X <- as.factor(reclassify(x, DF, ...))
    RAT <- levels(X)[[1]]
    RAT$value <- as.character(names)
    levels(X)[[1]] <- RAT
    X
}
