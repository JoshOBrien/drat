

##' Compute contour enclosing smallest possible area containing
##' specified proportion of mass in a PDF raster.
##'
##' This function is the one called \code{R2C_stars_PDF()} in my
##' CHHR-estimation project.
##' @title Compute Contour from a PDF Raster
##' @param R A \code{RasterLayer} object representing a density
##'     surface.
##' @param contour A number between \code{0} and \code{1}. The
##'     function will draw a contour around the smallest possible area
##'     containing the proportion of the total density mass of
##'     \code{R} specified by \code{contour}.
##' @return An sf object of type \code{MULTIPOLYGON}.
##' @importFrom stars st_as_stars st_contour
##' @importFrom sf st_geometry
##' @importFrom raster extent
##' @export
##' @author Joshua O'Brien
##' @examples
##' \dontrun{
##' }
raster_to_CHHR <- function (R, contour = 0.95) {
    stop("In place of chhrTools::raster_to_CHHR(), use spTools::raster_to_contour()")
}
