## Declare these symbols, used in calls to `[.data.table()` , to avoid
## `R CMD check` complaints
utils::globalVariables(c(".", "..i", "..j", "Freq", "ID"))
