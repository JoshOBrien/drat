## Code copied from (top of) file of the same name at:
## https://github.com/wleepang/shiny-directory-input

#' @name choose.dir
#'
#' @title Choose a Folder Interactively
#'
#' Display an OS-native folder selection dialog under Mac OS X, Linux GTK+ or
#' Windows.
#'
#' @param default which folder to show initially
#' @param caption the caption on the selection dialog
#' @param useNew boolean, selects the type of dialog shown in windows
#'
#' @details
#' Uses an Apple Script, Zenity or Windows Batch script to display an OS-native
#' folder selection dialog.
#'
#' For Apple Script, with \code{default = NA}, the initial folder selection
#' is determined by default behavior of the "choose folder" script. Otherwise,
#' paths are expanded with \code{\link{path.expand}}.
#'
#' For Linux, with \code{default = NA}, the initial folder selection is
#' determined by defaul behavior of the zenity script.
#'
#' The new windows batch script allows both initial folder and caption to be set.
#' In the old batch script for Windows the initial folder is always ignored.
#'
#' @return
#' A length one character vector, character NA if 'Cancel' was selected.
#'
#' @export
#'
choose.dir = function(default = NA, caption = NA, useNew=TRUE) {
  if (Sys.info()['sysname'] == 'Darwin') {
    return(choose.dir.darwin(default = default, caption = caption))
  } else if (Sys.info()['sysname'] == 'Linux') {
    return(choose.dir.linux(default = default, caption = caption))
  } else if (Sys.info()['sysname'] == 'Windows') {
    # Use batch script to circumvent issue w/ `choose.dir`/`tcltk::tk_choose.dir`
    # window popping out unnoticed in the back of the current window
    return(choose.dir.windows(default = default, caption = caption, useNew = useNew))
  }
  return(paste("Error: don't know how to show a folder dialog in", Sys.info()['sysname']) )
}

#' @name choose.dir.darwin
#'
#' @title The apple version of the choose folder
#'
#' @seealso \code{\link{choose.dir}}
#'
#' @return
#' A length one character vector, character NA if 'Cancel' was selected.
#'
choose.dir.darwin <- function(default = NA, caption = NA) {
  command = 'osascript'
  args = '-e "POSIX path of (choose folder{{prompt}}{{default}})"'

  if (!is.null(caption) && !is.na(caption) && nzchar(caption)) {
    prompt = sprintf(' with prompt \\"%s\\"', caption)
  } else {
    prompt = ''
  }
  args = sub('{{prompt}}', prompt, args, fixed = T)

  if (!is.null(default) && !is.na(default) && nzchar(default)) {
    default = sprintf(' default location \\"%s\\"', path.expand(default))
  } else {
    default = ''
  }
  args = sub('{{default}}', default, args, fixed = T)

  suppressWarnings({
    path = system2(command, args = args, stderr = TRUE)
  })
  if (!is.null(attr(path, 'status')) && attr(path, 'status')) {
    # user canceled
    path = NA
  } else {
    # cut any extra output lines, like "Class FIFinderSyncExtensionHost ..."
    path = tail(path, n=1)
  }

  return(path)
}


#' @name choose.dir.linux
#'
#' @title The linux version of the choose folder
#'
#' @seealso \code{\link{choose.dir}}
#'
#' @return
#' A length one character vector, character NA if 'Cancel' was selected.
#'
choose.dir.linux <- function(default = NA, caption = NA) {
  command = 'zenity'
  args = '--file-selection --directory'

  if (!is.null(default) && !is.na(default) && nzchar(default)) {
    args = paste(args, sprintf('--filename="%s"', default))
  }

  if (!is.null(caption) && !is.na(caption) && nzchar(caption)) {
    args = paste(args, sprintf('--title="%s"', caption))
  }

  suppressWarnings({
    path = system2(command, args = args, stderr = TRUE)
  })

  #Return NA if user hits cancel
  if (!is.null(attr(path, 'status')) && attr(path, 'status')) {
    # user canceled
    return(NA)
  }

  #Error: Gtk-Message: GtkDialog mapped without a transient parent
  if(length(path) > 1){
    path = path[(length(path))]
  }

  return(path)
}

#' @name choose.dir.windows
#'
#' @title The windows version of the choose folder
#'
#' @seealso \code{\link{choose.dir}}
#'
#' @return
#' A length one character vector, character NA if 'Cancel' was selected.
#'
choose.dir.windows <- function(default = NA, caption = NA, useNew = TRUE) {
  if(useNew){
    ## uses a powershell script rather than the bat version, gives a nicer interface
    ## and allows setting of the default directory and the caption
    whereisutils <- system.file("utils", 'newFolderDialog.ps1', package = "BHSRoCTGUI")
    command = 'powershell'
    args = paste('-NoProfile -ExecutionPolicy Bypass -File',
                 dQuote(normalizePath(whereisutils), q = '"'))
    if (!is.null(default) && !is.na(default) && nzchar(default)) {
      args = paste(args, sprintf('-default "%s"', normalizePath(default)))
    }

    if (!is.null(caption) && !is.na(caption) && nzchar(caption)) {
      args = paste(args, sprintf('-caption "%s"', caption))
    }

    path = system2(command, args = args, stdout = TRUE)
    suppressWarnings({

    })
  } else {
    whereisutils <- system.file("utils", 'choose_dir.bat', package = "BHSRoCTGUI")
    command = normalizePath(whereisutils)
    args = if (is.na(caption)) '' else sprintf('"%s"', caption)
    suppressWarnings({
      path = system2(command, args = args, stdout = TRUE)
    })
  }
  if (path == 'NONE') {
      path <- NA
  } else {
      path <- normalizePath(path, winslash = "/")
  }
  return(path)
}


## An alternative that uses the choose_dir.bat based on that in
## the shinyDirectoryInput package.
##
## It behaves slightly differently, in a session launched with
## Rscript, than does the function that uses my PowerShell script. In
## particular, it always initially launches the explorer behind the
## browser windw, without even adding an icon to the taskbar to
## indicate that it's there. After it's once brought to the front,
## though, it always launches in front, for the rest of the
## session. (It also: (1) presents a less pretty and consistent
## interface; (2) doesn't accept a default starting directory; and (3)
## does not display shortcuts.
choose.dir2 <- function(caption = NA) {
    whereisutils <- system.file("utils", 'choose_dir.bat', package="BHSRoCTGUI")
    command <- "cmd"
    args <- paste("/c", normalizePath(whereisutils))
    if (!is.null(caption) && !is.na(caption) && nzchar(caption)) {
      args = paste(args, caption)
    }
    suppressWarnings({
        path = system2(command, args = args, stdout = TRUE)
    })
    if (path == 'NONE') path = NA
    return(path)
}
