## Function designed to reduce the large amount of layout-related code
## necessitated by giving each widget/checkmark pair its own row.
##' @export
fluidRowWidgetCheck <- function(widget = div(), checkmark = div()) {
    fluidRow(column(3),
             column(6, widget),
             column(1, checkmark),
             column(2))
}



## Returns customized icon with supplied ID, used to mark successfully
## completed steps.
##' @export
greenCheck <- function(id = "", yShift = 6, xShift = -15) {
    style <- paste0("color: green;font-size:32px;position:relative;bottom:",
                    yShift, "px;left:", xShift, "px;")
    hidden(span(id = id, icon("check-circle"), style = style))
    ## style="color: green;font-size:32px;position:relative;bottom:6px;"
}


## Returns customized icon with supplied ID, used to mark required
## steps.
##' @export
greyDash <- function(id = "", yShift = 6, xShift = -15) {
    style <- paste0("color: #9aa0a6;font-size:32px;position:relative;bottom:",
                    yShift, "px;left:", xShift, "px;")
    hidden(span(id = id, icon("minus-circle"), style = style))
    ## style="color: #9aa0a6;font-size:32px;position:relative;bottom:6px;"
}



##' @export
tab_completion_report <- function(tab = "", complete = FALSE) {
  ## Returns customized icon with supplied ID, used to mark successfully
  ## completed steps.
  greenCheck <- function(id = "", yShift = 6, xShift = 0) {
    style <- paste0("color:green;font-size:20px;position:relative;bottom:",
                    yShift, "px;left:", xShift, "px;")
    span(id = id, icon("check-circle"), style = style)
  }
  redTimes <- function(id = "", yShift = 6, xShift = 0) {
    style <- paste0("color:red;font-size:20px;position:relative;bottom:",
                    yShift, "px;left:", xShift, "px;")
    span(id = id, icon("times-circle"), style = style)
  }
  fluidPage(
    fluidRow(
      column(2),
      column(1, if(complete) greenCheck() else redTimes()),
      column(8, sprintf("%s tab", tab)),
      column(1)
    )
  )
}

