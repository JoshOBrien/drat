
##' @export
write_parameters_txt_CHHR <- function(params, outputDir) {
    ## Prepare message for start of file
    message <-
'## This file records the full list of parameters used in computing
## one of the estimated CHHR layers stored in this directory\'s
## parent directory.
##
## To reproduce the analysis, run the following from an R session whose
## working directory is set to the directory containing this file:
##
## library(BHSkde)
## params <- read_yaml("parameters.txt")
## do.call(kdeHerd, params)

'
    ## Prepare the YAML section
    tmp <- tempfile()
    write_yaml(params, tmp)
    ## Write message then YAML to "parameters.txt"
    outFile <- file.path(outputDir, "parameters.txt")
    cat(message, file = outFile)
    cat(readLines(tmp), sep = "\n", file = outFile, append = TRUE)
}

## ## Usage:
## outputDir <- "C:/Users/Josh/Desktop"
## params <- list(a=1:10, b=month.name)
## write_parameters_txt_CHHR(params, outputDir)
