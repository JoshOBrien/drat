
## Used whenever adding a new layer to the leaflet map, this function
## "edits" the LayersControl by removing the old one and then
## immediately adding an updated one. It learns layers to include by
## taking a quick glance at RV to see which layers have so far been
## successfully uploaded.
##' @export
editLayersControl <- function(map, RV) {
  overlayGroups <- c("Animal locations",
                     "Habitat", "CHHR", "Allotments",
                     "Ram Foray", "Ewe Foray")
  loadedLayers <- c(is_sf(RV$PTS),
                    is_raster(RV$HAB_image),
                    is_sf(RV$CHHR),
                    is_sf(RV$ALLOTS),
                    is_raster(RV$ram_foray_pref_image),
                    is_raster(RV$ewe_foray_pref_image))
  overlayGroups <- overlayGroups[loadedLayers]
  removeLayersControl(map) %>%
  addLayersControl(
    baseGroups = c("OpenStreetMap", "OpenTopoMap"),
    overlayGroups = overlayGroups,
    options = layersControlOptions(collapsed = FALSE))
}


## I pulled this code out of the initial call to leaflet() in Map.R.
## When included there, it broke the solution I had implemented for
## getting the Map tab to render before a user's first visit. Now,
## this gets called whenever a user adds a CHHR, Allotments, or
## Habitat layer (though it's only executed the first time it's
## called.)
##' @export
##' @importFrom curl has_internet
addBasemapLayers <- function(map, RV) {
  if (!RV$MAP_tiles) {
    ## This function's code to only be executed first time it's called
    RV$MAP_tiles <- TRUE
    ## If internet is available, add background map tiles
    if (has_internet()) {
      ## For now, I only add OpenTopoMap, which reliably loads and
      ## goes to Zoom level 17, as documented here:
      ## http://leaflet-extras.github.io/leaflet-providers/preview/
      map <- addProviderTiles(map, providers$OpenTopoMap,
                              group = "OpenTopoMap",
                              options = providerTileOptions(zIndex=1))
      ## ## Unfortunately, Stamen.TonerLite loads or fails to unpredictably
      ## map <- addProviderTiles(map, providers$Stamen.TonerLite,
      ##                         group = "Minimal")
      map
    } else {
      map
    }
  } else {
    map
  }
}




## // Local Variables:
## // ess-indent-offset: 2
## // End:
