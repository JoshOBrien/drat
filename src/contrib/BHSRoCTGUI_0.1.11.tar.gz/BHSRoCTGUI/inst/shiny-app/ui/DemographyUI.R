##----------------------##
##  DEMOGRAPHY TAB: UI  ##
##----------------------##

tabPanel("4. Input herd demographics",
  fluidPage(
    fluidRow(
      column(3),
      column(4,
        numericInput("HerdSize", "Herd Size", 0, min = 0, max = 3000)
        ),
      column(1,
             span(greyDash("dash_HerdSize", yShift = -20),
                  greenCheck("check_HerdSize", yShift = -20))),
      column(4)
    ),
    br(),
    fluidRow(
      column(1, br(), checkboxInput("Ratio", "", TRUE)),
      column(4, numericInput("ramPerc", "Ram %", 35,
                             min = 0, max = 100, step = 0.1)),
      column(4, numericInput("ewePerc", "Ewe %", 65,
                             min = 0, max = 100, step = 0.1)),
      column(3)
    ),
    fluidRow(
      column(1, br(), checkboxInput("Number", "", FALSE)),
      column(4, numericInput("ramNum", "Ram #", 49,
                             min = 0, max = 1000)),
      column(4, numericInput("eweNum", "Ewe #", 91,
                             min = 0, max = 2000)),
      column(3)
    )
  ))


## // Local Variables:
## // ess-indent-offset: 2
## // End:
