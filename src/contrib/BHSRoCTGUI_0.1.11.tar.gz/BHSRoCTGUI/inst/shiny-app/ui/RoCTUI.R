##------------------------##
##  COMPUTE RoCT TAB: UI  ##
##------------------------##

tabPanel("6. Compute RoCT",
  ## Make "Missing inputs" modal wide enough to avoid text wrapping
  tags$head(tags$style(".modal-dialog{ width:350px}")),

  br(), br(), br(),

  fluidPage(theme = "radioButtonBoxes.css",

    ## Output directory selection
    fluidRowWidgetCheck(
      actionButton("select_outputDir",
                   "Select output directory", width = "100%"),
      greenCheck("check_outputDir")
    ),

    br(),

    ## Display notification of selected output directory
    fluidRow(
      column(3),
      column(8, align = "center",
        div(align = "left", verbatimTextOutput("outputDir_info"))
        ),
      column(1)
    ),


    ## "Compute RoCT" button, hidden until all required parameters
    ## have been supplied
    hidden(div(id = "display_compute_RoCT",
    hr(),
    br(),
    fluidRow(
      column(3),
      column(6,
        actionButton("compute_RoCT",
                     "Compute RoCT",
                     width = "100%")),
      column(2, checkboxInput("Archive", "Archive inputs", FALSE)),
      column(1)
    )
    )),

    ## RoCT table and title
    hidden(div(id = "display_RoCT",
    hr(),
    fluidRow(
      column(1),
      column(10,
        ## RoCT title
        tags$h3("Risk of Contact Table:"),
        br(),
        ## Render RoCT handsontable
        rHandsontableOutput("hot_RoCT")),
      column(1)
    )
    )),

    br(), br()

    )
  )


## // Local Variables:
## // ess-indent-offset: 2
## // End:
