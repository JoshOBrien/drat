##------------------------------------------##
##  CHHR ESTIMATOR COMPUTATION TAB: SERVER  ##
##------------------------------------------##

## Prompt user to select CHHR output directory
observeEvent(input$select_CHHR_outputDir, {
  dirPath <- choose.dir(default = "~",
                        caption = "Choose a directory...")
  if (!identical(dirPath, "")) {
    RV$CHHR_outputDir <- dirPath
  }
})

##------------------------------------------------------------------------------
## Display additional elements once output directory is selected
##------------------------------------------------------------------------------

## Update CHHR name
observeEvent(input$enter_CHHR_name, {
  RV$CHHR_outputName <- paste0(input$enter_CHHR_name, ".shp")
  })

## Show box containing CHHR's name
observeEvent(RV$CHHR_outputDir, {
  toggle("enter_CHHR_name", condition = nchar(RV$CHHR_outputDir) > 0)
}, ignoreInit = TRUE)

## Show message box displaying selected output directory
observeEvent({RV$CHHR_outputDir; RV$CHHR_outputName}, {
  toggle("CHHR_outputDir_info", condition = nchar(RV$CHHR_outputDir) > 0)
  output$CHHR_outputDir_info <-
    renderPrint(cat(sprintf("CHHR output directory: %s\nCHHR shapefile name:   %s",
                            RV$CHHR_outputDir, RV$CHHR_outputName)))
}, ignoreInit = TRUE)

## Show "Compute CHHR" button when output directory is selected.
## Hide it again when CHHR computations are complete.
observeEvent({RV$CHHR_outputDir; RV$res_CHHR}, {
  toggle(id = "display_compute_CHHR",
         condition = (nchar(RV$CHHR_outputDir) & !is_sf(RV$res_CHHR)))
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Handle "Compute CHHR" button click.
##------------------------------------------------------------------------------

observeEvent(input$compute_CHHR, {
  OKHR$All <- (OKHR$Data)
  ##----------------------------------------------------------------------------
  ## If any tab is incomplete, use modal to report every tabs' status
  ##----------------------------------------------------------------------------
  if (!OKHR$All) {
    showModal(modalDialog(
      div("Missing inputs",
          style="display:flex; justify-content:center; align-items:center; font-size:160%"),
      br(),
      div("Before estimating CHHR, complete all tabs:"),
      br(),
      tab_completion_report("Bighorn locations", OKHR$Data),
      size = "s"
    ))
  }
  ##----------------------------------------------------------------------------
  ## If all tabs are complete, launch CHHR computation
  ##----------------------------------------------------------------------------
  if (OKHR$All) {
  ## Preliminaries
  temp_dir <- RV$temp_dir
  outputDir <- RV$CHHR_outputDir

  ##----------------------------------------------------------------------------
  ## Prepare inputs to compute_ROCT()
  ##----------------------------------------------------------------------------

  ## compute_RoCT() accepts character vectors giving paths to spatial
  ## files
  PTS_PATH <-
    if (RV$PTS_is == "SHP") {
      c(dirname(RV$PTS_SHP_path),
        tools::file_path_sans_ext(basename(RV$PTS_SHP_path)))
    } else {
      c(RV$PTS_GDB_path, RV$PTS_GDB_layer)
    }

  ## Construct full list of arguments to compute_ROCT
  params <-
    list(dsn = PTS_PATH,
         animalIDcol = input$PTS_ID_column,
         aggregatePoints = FALSE,
         bwEstimator = input$bwEstimator,
         bwMultiplier = input$bwMultiplier_100/100,
         cont = input$cont_100/100,
         outputType = "poly",
         outputDir = RV$CHHR_outputDir,
         outputFile = tools::file_path_sans_ext(RV$CHHR_outputName))

  ## Record run parameters to tempfile
  write_yaml(params, file = file.path(temp_dir, "CHHR_parameters.txt"))


  ##----------------------------------------------------------------------------
  ## Call kdeHerd()
  ##----------------------------------------------------------------------------

  ## Begin expensive computations of core herd home range
  show_modal_spinner(text = "Computing estimated core herd home range")

  ## Compute CHHR
  do.call(kdeHerd, params)

  ## Add newly calculated CHHR to RoCT and Map tabs
  filePath <- file.path(RV$CHHR_outputDir, RV$CHHR_outputName)
  RV$CHHR_is <- "SHP"
  RV$CHHR_SHP_path <- filePath
  RV$POLY_search_dir <- dirname(filePath)
  RV$CHHR <- st_read_WGS84(filePath)
  ## Clear out GDB inputs
  RV$CHHR_GDB_path <- "~"
  RV$CHHR_GDB_layer <- ""
  RV$CHHR_GDB_path_valid <- FALSE
  OK$CHHR <- TRUE
  updateRadioButtons(session, "CHHR_file_type", selected="shp")


  ## ##----------------------------------------------------------------------------
  ## ## Save results to output directory
  ## ##----------------------------------------------------------------------------
  ##
  ## ff <- c("ForayPrefEwe.tif", "ForayPrefRam.tif", "RoC-results.csv")
  ## file.copy(from = file.path(temp_dir, ff),
  ##           to = outputDir, recursive = TRUE)
  ## file.remove(file.path(temp_dir, ff[1:2]))


##----------------------------------------------------------------------------
## Save selected input files to Archive directory
##----------------------------------------------------------------------------

  if (input$Archive_CHHR) {
    ## Create Archive directory
    archiveDir <- file.path(outputDir,
                            sprintf("Archive_CHHR--%s", params$outputFile))
    unlink(archiveDir, recursive = TRUE)
    dir.create(archiveDir)

    ## Save inputs, parameters, and runscript to Archive directory
    archive_inputs_CHHR(archiveDir = archiveDir, params = params)
  }

  ## End of expensive computations of foray probability rasters and
  ## risk of contact table.
  remove_modal_spinner()

  ## Notify user of success and remind them where results are stored
  msg <- 'CHHR shapefile has been saved to: "%s"'
  msg <- sprintf(msg, RV$CHHR_outputDir)
  shinyalert(title = "CHHR estimation complete",
             text = msg,
             type = "success")
  }
})




## // Local Variables:
## // ess-indent-offset: 2
## // End:
