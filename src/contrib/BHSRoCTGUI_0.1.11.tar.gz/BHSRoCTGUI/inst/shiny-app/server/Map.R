##-------------------##
##  MAP TAB: SERVER  ##
##-------------------##


##-----------##
##  Basemap  ##
##-----------##
map <- leaflet() %>%
  ## Initially display entire western US
  fitBounds(lng1 = -125, lng2 = -90, lat1 = 30, lat2 = 50) %>%
  {if (has_internet()) addTiles(.) else .}

output$myMap <- renderLeaflet({
  map
})
## NOTE: Both this and the quick initial tab switch (executed at the
## top of "ui.R") are needed to get the background basemap to
## immediately render.
outputOptions(output, "myMap",
              suspendWhenHidden = FALSE, priority = 10)

##--------------------------##
##   Add Animal locations   ##
##--------------------------##
observeEvent(RV$PTS, {
  PTS <- RV$PTS
  ## Prepare labels for possibly multi-polygon PTS layer
  ptsName <- if (RV$PTS_is == "GDB") {
                RV$PTS_GDB_layer
              } else {
                tools::file_path_sans_ext(basename(RV$PTS_SHP_path))
              }
  ptsNames <- rep(ptsName, nrow(PTS))
  lab_PTS <-
    lapply(ptsNames,
           function(X) htmltools::HTML(paste0("<em>", X, "</em>")))

  BBOX <- st_bbox_overall(RV$PTS)
  proxy <- leafletProxy("myMap")
  proxy %>% flyToBounds_bbox(BBOX)
  proxy %>%
    removeShape(layerId = paste0("PTS_", 1:1000000)) %>%
    addBasemapLayers(RV = RV) %>%
    addCircleMarkers(data = PTS,
                     label = lab_PTS,
                     layerId = paste0("PTS_", seq_len(nrow(PTS))),
                     group = "Animal locations",
                     radius = 3,
                     stroke = FALSE, color = "red",
                     fillOpacity = 0.5) %>%
    editLayersControl(RV = RV)
}, ignoreInit = TRUE, priority = 9)


##----------------##
##   Add CHHR     ##
##----------------##
observeEvent(RV$CHHR, {
  CHHR <- RV$CHHR
  ## Prepare labels for possibly multi-polygon CHHR layer
  chhrName <- if (RV$CHHR_is == "GDB") {
                RV$CHHR_GDB_layer
              } else {
                tools::file_path_sans_ext(basename(RV$CHHR_SHP_path))
              }
  chhrNames <- rep(chhrName, nrow(CHHR))
  lab_CHHR <-
    lapply(chhrNames,
           function(X) htmltools::HTML(paste0("<em>", X, "</em>")))

  BBOX <- st_bbox_overall(RV$CHHR, RV$ALLOTS)
  proxy <- leafletProxy("myMap")
  proxy %>% flyToBounds_bbox(BBOX)
  proxy %>%
    removeShape(layerId = paste0("CHHR_", 1:1000)) %>%
    addBasemapLayers(RV = RV) %>%
    addPolygons(data = st_geometry(CHHR),
                label = lab_CHHR,
                layerId = paste0("CHHR_", seq_len(nrow(CHHR))),
                group = "CHHR") %>%
    editLayersControl(RV = RV)
}, ignoreInit = TRUE, priority = 9)


##------------------##
##  Add Allotments  ##
##------------------##
observeEvent({RV$ALLOTS; RV$ALLOTS_ID_column}, {
  ALLOTS <- RV$ALLOTS

  ## Prepare labels for allotment polygons
  if (nchar(RV$ALLOTS_ID_column)) {
    allotNames <- ALLOTS[[RV$ALLOTS_ID_column]]
  } else {
    allotNames <- rep(RV$ALLOTS_GDB_layer, nrow(ALLOTS))
  }
  lab_ALLOTS <-
    lapply(allotNames,
           function(X) htmltools::HTML(paste0("<em>", X, "</em>")))

  BBOX <- st_bbox_overall(RV$CHHR, RV$ALLOTS)
  proxy <- leafletProxy("myMap")
  proxy %>% flyToBounds_bbox(BBOX)
  proxy %>%
    removeShape(layerId = paste0("ALLOTS_", 1:1000)) %>%
    addBasemapLayers(RV = RV) %>%
    addPolygons(data = st_geometry(ALLOTS),
                label = lab_ALLOTS,
                color = heat.colors(10)[5],
                layerId = paste0("ALLOTS_", seq_len(nrow(ALLOTS))),
                group = "Allotments") %>%
    editLayersControl(RV = RV)
}, ignoreInit = TRUE, priority = 9)


##------------------##
##   Add Habitat    ##
##------------------##
observeEvent(RV$HAB_image, {
  proxy <- leafletProxy("myMap")
  suppressWarnings(
    proxy %>%
    removeImage(layerId = "Habitat") %>%
    addBasemapLayers(RV = RV) %>%
    addRasterImage(RV$HAB_image, opacity = 0.5,
                   project = FALSE,
                   colors = grey(c(0.0, 0.7, 0.9)),
                   layerId = "Habitat",
                   group = "Habitat") %>%
    editLayersControl(RV = RV)
  )
  ## Spinner removed here was started in "Habitat.R", just before call
  ## to `raster_warp()`
  remove_modal_spinner()
}, ignoreInit = TRUE, priority = 9)


##--------------------------------------##
##   Add Ram Foray Preference raster    ##
##--------------------------------------##
observeEvent(RV$ram_foray_pref_image, {
  BBOX <- st_bbox_overall(RV$CHHR, RV$ALLOTS, RV$ram_foray_pref_image)
  proxy <- leafletProxy("myMap")
  proxy %>% flyToBounds_bbox(BBOX)
  suppressWarnings(
    proxy %>%
    removeImage(layerId = "Ram Foray") %>%
    addRasterImage(RV$ram_foray_pref_image, opacity = 0.75,
                   project = FALSE,
                   colors = BHSforay::Yellow_to_Green_to_Dark_Blue,
                   layerId = "Ram Foray",
                   group = "Ram Foray") %>%
    editLayersControl(RV = RV)
  )
}, ignoreInit = TRUE, priority = 9)


##--------------------------------------##
##   Add Ewe Foray Preference raster    ##
##--------------------------------------##
observeEvent(RV$ewe_foray_pref_image, {
  proxy <- leafletProxy("myMap")
  suppressWarnings(
    proxy %>%
    removeImage(layerId = "Ewe Foray") %>%
    addRasterImage(RV$ewe_foray_pref_image, opacity = 0.75,
                   project = FALSE,
                   colors = BHSforay::Yellow_to_Green_to_Dark_Blue,
                   layerId = "Ewe Foray",
                   group = "Ewe Foray") %>%
    hideGroup("Ewe Foray") %>%
    editLayersControl(RV = RV)
  )
}, ignoreInit = TRUE, priority = 9)



## // Local Variables:
## // ess-indent-offset: 2
## // End:
