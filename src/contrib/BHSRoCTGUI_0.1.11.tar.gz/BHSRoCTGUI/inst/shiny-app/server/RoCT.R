##----------------------------##
##  COMPUTE RoCT TAB: SERVER  ##
##----------------------------##

## Prompt user to select output directory
observeEvent(input$select_outputDir, {
  dirPath <- choose.dir(default = "~",
                        caption = "Choose a directory...")
  if (!identical(dirPath, "")) {
    RV$outputDir <- dirPath
  }
})

##------------------------------------------------------------------------------
## Display additional elements once output directory is selected
##------------------------------------------------------------------------------

## Show message box displaying selected output directory
observeEvent(RV$outputDir, {
  toggle("outputDir_info", condition = nchar(RV$outputDir) > 0)
  output$outputDir_info <-
    renderPrint(cat(sprintf("Output directory: %s", RV$outputDir)))
}, ignoreInit = TRUE)

## Show "Compute RoCT" button when output directory is selected.
## Hide it again when RoCT computations are complete.
observeEvent({RV$outputDir; RV$res_RoCT}, {
  toggle(id = "display_compute_RoCT",
         condition = (nchar(RV$outputDir) & !is.data.frame(RV$res_RoCT)))
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## When "Compute RoCT" button is pressed, test whether inputs complete
##------------------------------------------------------------------------------

observeEvent(input$compute_RoCT, {
  OK$All <-
    (OK$CHHR & OK$Allotments & OK$Habitat & OK$Demography & OK$Behavior)
  ## If any tab is incomplete, use modal to report every tabs' status
  if (!OK$All) {
    showModal(modalDialog(
      div("Missing inputs",
          style="display:flex; justify-content:center; align-items:center; font-size:160%"),
      br(),
      div("Before running RoCT analysis, complete all tabs:"),
      br(),
      tab_completion_report("CHHR", OK$CHHR),
      tab_completion_report("Allotments", OK$Allotments),
      tab_completion_report("Habitat", OK$Habitat),
      tab_completion_report("Demography", OK$Demography),
      tab_completion_report("Behavior", OK$Behavior),
      size = "s"
    ))
  }


})


##------------------------------------------------------------------------------
## Carry out RoCT analysis when "Compute RoCT" button is pressed
##------------------------------------------------------------------------------

observeEvent(OK$All, {
  if (OK$All) {
  ## Preliminaries
  temp_dir <- RV$temp_dir
  outputDir <- RV$outputDir
  return_all_allots <- TRUE

  ##----------------------------------------------------------------------------
  ## Prepare inputs to compute_ROCT()
  ##----------------------------------------------------------------------------

  ## Now is the time to save interactively-supplied habitat class
  ## preferences (if any) to a file
  if(input$HAB_raster_type == "class_interactive") {
    tmp <- file.path(temp_dir, "Hab-prefs.csv")
    RV$HAB_pref_file_path <- tmp
    write.csv(RV$DF, file = tmp, row.names = FALSE)
  }

  ## compute_RoCT() accepts character vectors giving paths to spatial
  ## files
  CHHR <-
    if (RV$CHHR_is == "SHP") {
      RV$CHHR_SHP_path
    } else {
      c(RV$CHHR_GDB_path, RV$CHHR_GDB_layer)
    }
  ALLOTS <-
    if (RV$ALLOTS_is == "SHP") {
      RV$ALLOTS_SHP_path
    } else {
      c(RV$ALLOTS_GDB_path, RV$ALLOTS_GDB_layer)
    }

  ## Construct full list of arguments to compute_ROCT
  params <-
    list(CHHR = CHHR,
         ALLOTS = ALLOTS,
         HAB = RV$HAB_file_path,
         nRing = nrow(read.csv(RV$RFD_path)),
         allot_id_col = RV$ALLOTS_ID_column,
         is_categorical_habitat = RV$HAB_is_categorical,
         HabPrefTable = RV$HAB_pref_file_path,
         FP_ram = input$RamForayProb,
         FP_ewe = input$EweForayProb,
         FD_ram = RV$RFD_path,
         FD_ewe = RV$EFD_path,
         HerdSize = input$HerdSize,
         RamProp = input$ramPerc,
         EweProp = input$ewePerc,
         return_all_allots = return_all_allots,
         foray_prob_raster_dir = temp_dir)

  ## Record run parameters to tempfile
  write_yaml(params, file = file.path(temp_dir, "parameters.txt"))


  ##----------------------------------------------------------------------------
  ## Call compute_RoCT()
  ##----------------------------------------------------------------------------

  ## Begin expensive computations of foray probability rasters and
  ## risk of contact table.
  show_modal_spinner(text = "Computing foray probability rasters and RoC table")
  RES <- do.call(compute_ROCT, params)
  cols <- colnames(RES)[3:7]
  RES[, (cols) := lapply(.SD, function(X) round(X, 7)),
      .SDcols = cols]
  RV$res_RoCT <- RES
  ## Save Risk of Contact Table to a file
  fwrite(RES, file.path(temp_dir, "RoC-results.csv"), scipen = 10)


  ##----------------------------------------------------------------------------
  ## Display results of compute_RoCT()
  ##----------------------------------------------------------------------------

  ## Prepare RoCT rhandsontable for GUI display
  observeEvent(RV$res_RoCT, {
    if (is.data.frame(RV$res_RoCT)) {
      ## Show title for handsontable
      toggle(id = "display_RoCT", condition = TRUE)
      ## Show handsontable
      output$hot_RoCT <- renderRHandsontable({
        DF <- RV$res_RoCT
        cols <- colnames(DF)[3:7]
        DF[, (cols):=lapply(.SD, function(X) sprintf("%.5f", X)), .SDcols=cols]
        DF[, (cols):=lapply(.SD, function(X) gsub("Inf", "", X)), .SDcols=cols]
        rhandsontable(DF, readOnly = TRUE, width = 1400) %>%
          hot_col(2, halign="htRight") %>%
          hot_col(3:7, halign="htCenter") %>%
          hot_cols(renderer = "
            function (instance, td, row, col, prop, value, cellProperties) {
              Handsontable.renderers.TextRenderer.apply(this, arguments);
              if(instance.getData()[row][1] == 'CHHR'){
                td.style.background = 'pink'
              }
            }")
      })
    }
  })

  ## Downsample foray preference rasters to the same resolution as the
  ## background habitat layer to keep them small enough for inclusion
  ## in the leaflet map
  agg_factor <- compute_agg_factor(raster(RV$HAB_file_path))
  RV$ram_foray_pref_image <-
    raster_warp(file.path(temp_dir, "ForayPrefRam.tif"), agg_factor)
  RV$ewe_foray_pref_image <-
    raster_warp(file.path(temp_dir, "ForayPrefEwe.tif"), agg_factor)


  ##----------------------------------------------------------------------------
  ## Save results to output directory
  ##----------------------------------------------------------------------------

  ff <- c("ForayPrefEwe.tif", "ForayPrefRam.tif", "RoC-results.csv")
  file.copy(from = file.path(temp_dir, ff),
            to = outputDir, recursive = TRUE)
  file.remove(file.path(temp_dir, ff[1:2]))


  ##----------------------------------------------------------------------------
  ## Save selected input files to Archive directory
  ##----------------------------------------------------------------------------

  if (input$Archive) {
    ## Create Archive directory
    archiveDir <- file.path(outputDir, "Archive_RoCT")
    unlink(archiveDir, recursive = TRUE)
    dir.create(archiveDir)

    ## Save inputs, parameters, and runscript to Archive directory
    archive_inputs_RoCT(archiveDir = archiveDir, params = params)
  }

  ## End of expensive computations of foray probability rasters and
  ## risk of contact table.
  remove_modal_spinner()

  ## Notify user of success and remind them where results are stored
  msg <- 'Results table and foray preference rasters have been saved to: "%s"'
  msg <- sprintf(msg, outputDir)
  shinyalert(title = "RoC analysis complete",
             text = msg,
             type = "success")
  }
})



## // Local Variables:
## // ess-indent-offset: 2
## // End:
