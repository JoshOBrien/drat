##------------------------##
##  BEHAVIOR TAB: SERVER  ##
##------------------------##


##------------------------------------------------------------------------------
## Ram & Ewe foray frequencies
##------------------------------------------------------------------------------

## ## Force numericInput() to respect its maximum value of 1. (Issue
## ## discussed here: https://github.com/rstudio/shiny/issues/927 .)
## observeEvent(input$RamForayProb, {
##   if (!is.na(input$RamForayProb) && input$RamForayProb > 1) {
##     updateNumericInput(session, "RamForayProb", value = 1)
##   }
## })
## observeEvent(input$EweForayProb, {
##   if (!is.na(input$EweForayProb) && input$EweForayProb > 1) {
##     updateNumericInput(session, "EweForayProb", value = 1)
##   }
## })

## Use default (Payette) foray probabilities
observeEvent(input$useDefaultForayProbs, {
  if (input$useDefaultForayProbs) {
    updateNumericInput(session, "RamForayProb", value = 0.141)
    updateNumericInput(session, "EweForayProb", value = 0.015)
  }
})


##------------------------------------------------------------------------------
## Ram foray distance file upload
##------------------------------------------------------------------------------

## Use default RFD file
observeEvent(input$useDefaultRFD, {
  if (input$useDefaultRFD) {
    RV$RFD_path <-
      system.file("data/Ram_summer_foray_dist_35.csv",
                  package = "BHSRoCTGUI")
  } else {
    RV$RFD_path <- ""
  }
})

## Upload RFD file
observeEvent(input$upload_RFD_file, {
  filePath <- fileChooser("~", filter = "csv")
  if (is_valid_csv(filePath)) {
    if (identical(names(fread(filePath)), c("Distance", "ForayProb"))) {
      updateCheckboxInput(session, "useDefaultRFD", value = FALSE)
      ## Add 10 ms. delay to ensure line above executes before this one
      shinyjs::delay(10, {
        RV$RFD_path <- filePath
      })
    }
  }
}, ignoreInit = TRUE)
## Report info on currently loaded RFD file
observeEvent(RV$RFD_path, {
  toggle("RFD_info", condition = nchar(RV$RFD_path))
  output$RFD_info <-
    if (nchar(RV$RFD_path)) {
      renderPrint(forayDistanceFileSummary("Ram", RV$RFD_path))
    } else {
      renderPrint("")
    }
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Ewe foray distance file upload
##------------------------------------------------------------------------------

## Use default EFD file
observeEvent(input$useDefaultEFD, {
  if (input$useDefaultEFD) {
    RV$EFD_path <-
      system.file("data/Ewe_summer_foray_dist_35.csv",
                  package = "BHSRoCTGUI")
  } else {
    RV$EFD_path <- ""
  }
})

## Upload EFD
observeEvent(input$upload_EFD_file, {
  filePath <- fileChooser("~", filter = "csv")
  if (is_valid_csv(filePath)) {
    if (identical(names(fread(filePath)), c("Distance", "ForayProb"))) {
      updateCheckboxInput(session, "useDefaultEFD", value = FALSE)
      ## Add 10 ms. delay to ensure line above executes before this one
      shinyjs::delay(10, {
        RV$EFD_path <- filePath
      })
    }
  }
}, ignoreInit = TRUE)
## Report info on currently loaded EFD file
observeEvent(RV$EFD_path, {
  toggle("EFD_info", condition = nchar(RV$EFD_path))
  output$EFD_info <-
    if (nchar(RV$EFD_path)) {
      renderPrint(forayDistanceFileSummary("Ewe", RV$EFD_path))
    } else {
      renderPrint("")
    }
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Conditionally hide/show check marks
##------------------------------------------------------------------------------

observeEvent({input$RamForayProb; input$EweForayProb}, {
  toggle("dash_ForayProbs",
         condition = {
           !isTRUE((input$RamForayProb + input$EweForayProb > 0))
           })
  toggle("check_ForayProbs",
         condition = {
           ## Neither input is NA and at least one is greater than 0
           isTRUE((input$RamForayProb + input$EweForayProb > 0))
         })
  })

observeEvent({RV$RFD_path},
             toggle("dash_RFD_file", condition = !nchar(RV$RFD_path)))
observeEvent({RV$RFD_path},
             toggle("check_RFD_file", condition = nchar(RV$RFD_path)))
observeEvent({RV$EFD_path},
             toggle("dash_EFD_file", condition = !nchar(RV$EFD_path)))
observeEvent({RV$EFD_path},
             toggle("check_EFD_file", condition = nchar(RV$EFD_path)))

observeEvent({input$RamForayProb; input$EweForayProb; RV$RFD_path; RV$EFD_path},
{
  OK$Behavior <-
    isTRUE((input$RamForayProb + input$EweForayProb > 0)) &&
    nchar(RV$RFD_path) &&
    nchar(RV$EFD_path)
})


## Eventually, we may want to add code testing the validity of
## supplied FD files, including a shinyalert like the following
##
## if (is_FD_file(filePath)) {
##   RV$RFD_path <- filePath
## } else {
##   if (length(filePath)) {
##     msg<-paste("This file does not appear to be a valid foray distance file:\n",
##                filePath)
##     shinyalert(title = "Problem reading Ram Foray Distance file",
##                text = msg,
##                type = "error")
##   }
## }



## // Local Variables:
## // ess-indent-offset: 2
## // End:
