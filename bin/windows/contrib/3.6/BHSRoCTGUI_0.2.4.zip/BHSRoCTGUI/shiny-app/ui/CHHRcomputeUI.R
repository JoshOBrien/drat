##--------------------------------------##
##  CHHR ESTIMATOR COMPUTATION TAB: UI  ##
##--------------------------------------##

tabPanel("3. Compute CHHR",
  ## Make "Missing inputs" modal wide enough to avoid text wrapping
  tags$head(tags$style(".modal-dialog{ width:350px}")),

  br(), br(), br(),

  fluidPage(theme = "radioButtonBoxes.css",

    ## Select output directory
    fluidRowWidgetCheck(
      actionButton("select_CHHR_outputDir",
                   "Select output directory", width = "100%"),
      greenCheck("check_CHHR_outputDir")
    ),
    br(),

    ## Select output file name
    fluidRowWidgetCheck(
      hidden(textInput("enter_CHHR_name",
                       "Enter name for computed CHHR:",
                       value = "CHHR", width = "100%")),
      greenCheck("check_enter_CHHR_name")
    ),
    br(),

    ## Display notification of selected output directory
    fluidRow(
      column(2),
      column(8, align = "center",
        div(align = "left", verbatimTextOutput("CHHR_outputDir_info"))
        ),
      column(2)
    ),


    ## "Compute RoCT" button, hidden until all required parameters
    ## have been supplied
    hidden(div(id = "display_compute_CHHR",
    hr(),
    br(),
    fluidRow(
      column(3),
      column(6,
        actionButton("compute_CHHR",
                     "Compute CHHR",
                     width = "100%")),
      column(2, checkboxInput("Archive_CHHR", "Archive inputs", FALSE)),
      column(1)
    )
    )),

    br(), br()

    )
  )


## // Local Variables:
## // ess-indent-offset: 2
## // End:
