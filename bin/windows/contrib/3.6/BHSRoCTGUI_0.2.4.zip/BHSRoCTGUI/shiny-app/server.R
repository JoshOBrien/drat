
shinyServer(function(input, output, session) {

  temp_dir <- tempdir()
  on.exit({
    unlink(dir(temp_dir, full.names = TRUE), recursive = TRUE, force = TRUE)
  })

  ## Immediately set session end callbacks
  session$onSessionEnded(function() {
    ## Delete all files in temp directory when sesson ends
    ## https://stackoverflow.com/a/50061166
    TD <- tempdir()
    if (dir.exists(TD)) {
      unlink(normalizePath(dir(TD, full.names = TRUE)),
             recursive = TRUE)
    }
    ## Close session when browser window is closed:
    ## https://stackoverflow.com/a/45590324/980833
    stopApp()
  })

  ## Once, when the app first launches, briefly visit and then leave
  ## the "Map" tab, in order to get it to start rendering.
  ##
  ## (This would not be necessary if somebody were to address the
  ## following issue: https://github.com/rstudio/leaflet/issues/659.)
  observeEvent(input$upload_CHHR_shp, {
    hideTab(inputId = "tab_being_displayed", target = "Map")
    updateTabsetPanel(session, inputId = "tab_being_displayed",
                      selected = "Map")
    shinyjs::delay(250, # Firefox needs just 1 ms; Chrome needs 250 ms
      updateTabsetPanel(session, inputId = "tab_being_displayed",
                        selected = "Estimate CHHR"))
    showTab(inputId = "tab_being_displayed", target = "Map")
  }, once = TRUE, ignoreNULL = FALSE)


  ##-----------------------------------##
  ## Initialize reactiveValues objects ##
  ##-----------------------------------##
  RV <-
    reactiveValues(temp_dir = temp_dir,
                   PTS_GDB_path = "~",
                   PTS_GDB_path_valid = FALSE,
                   PTS_GDB_layer = "",
                   PTS_SHP_path = "",
                   PTS = "",
                   PTS_ID_column = "",
                   PTS_is = "",       # "shp" or "gdb"
                   POLY_search_dir = "~",
                   CHHR_GDB_path = "~",
                   CHHR_GDB_path_valid = FALSE,
                   CHHR_GDB_layer = "",
                   CHHR_SHP_path = "",
                   CHHR = "",
                   CHHR_is = "",       # "shp" or "gdb"
                   ALLOTS_GDB_path = "~",
                   ALLOTS_GDB_path_valid = FALSE,
                   ALLOTS_GDB_layer = "",
                   ALLOTS_SHP_path = "",
                   ALLOTS = "",
                   ALLOTS_ID_column = "",
                   ALLOTS_is = "",     # "shp" or "gdb"
                   HAB_search_dir = "~",
                   HAB_file_path = "",
                   HAB_image = "",   # Hab raster, poss. downsampled
                   HAB_raster_type = "",
                   HAB_is_categorical = logical(0),
                   HAB_pref_file_path = "",
                   RFP = numeric(0), # Ram foray probability
                   EFP = numeric(0), # Ewe foray probability
                   RFD_path = "",    # Ram foray dist distribution
                   EFD_path = "",    # Ewe foray dist distribution
                   ram_foray_pref_image = "",
                   ewe_foray_pref_image = "",
                   MAP_tiles = FALSE,
                   res_RoCT = FALSE,
                   res_CHHR = FALSE)
  ## On which tabs have all required inputs been supplied?
  OK <-
    reactiveValues(All = FALSE, # Ready for compute_ROCT()?
                   CHHR = FALSE,
                   Allotments = FALSE,
                   Habitat = FALSE,
                   Demography = FALSE,
                   Behavior = FALSE)
  OKHR <-
    reactiveValues(All = FALSE, # Ready for compute_CHHR()?
                   Data = FALSE)


  ##-----------------------##
  ##  CHHR ESTIMATION TAB  ##
  ##-----------------------##
  ## server/CHHRdata.R
  source(file.path("server", "CHHRdata.R"), local = TRUE)
  ## server/CHHRconfig.R
  source(file.path("server", "CHHRconfig.R"), local = TRUE)
  ## server/CHHRcompute.R
  source(file.path("server", "CHHRcompute.R"), local = TRUE)

  ##------------------------##
  ##  RoCT ESTIMATION TAB   ##
  ##------------------------##
  ## server/CHHR.R
  source(file.path("server", "CHHR.R"), local = TRUE)
  ## server/Allotments.R
  source(file.path("server", "Allotments.R"), local = TRUE)
  ## server/Habitat.R
  source(file.path("server", "Habitat.R"), local = TRUE)
  ## server/BehaviorUI.R
  source(file.path("server", "Behavior.R"), local = TRUE)
  ## server/Demography.R
  source(file.path("server", "Demography.R"), local = TRUE)
  ## server/RoCT.R
  source(file.path("server", "RoCT.R"), local = TRUE)

  ##--------------------##
  ##   LEAFLET MAP TAB  ##
  ##--------------------##
  ## server/Map.R
  source(file.path("server", "Map.R"), local = TRUE)


})


## // Local Variables:
## // ess-indent-offset: 2
## // End:
