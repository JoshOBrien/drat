This directory contains the data and parameters used in estimating a
CHHR polygon whose shapefile has been saved to its parent
directory. It also contains an R script that may be used to reproduce
the analysis.

In addition to this "README.txt" file, the directory contains:

- A *.gpkg file containing the bighorn sheep location point layer.

- "parameters.txt", a text file that records all input parameters.

- "runscript.R", an R script that may be used to reproduce the
  archived analysis, when executed from the directory containing this
  file.

