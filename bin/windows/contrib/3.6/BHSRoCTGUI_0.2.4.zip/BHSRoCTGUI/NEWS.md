## RoCT-GUI-v15

- The value set by the "Minimum Points per Animal" input on the
  "Configure CHHR Estimator" tab is now actually used as
  advertised. Up to RoCT-GUI-v14, the user-selected value was not
  being passed along via the `minObs=` parameter to
  `BHSkde::kdeHerd()`, and the Tool always instead fell back on the
  parameter's default value of `minObs=5`.

- The "Ram foray probability" and "Ewe foray probability" inputs (on
  the "Input foray behavior" sidebar tab), which only accepted values
  between 0.00 and 1.00 have been replaced with "Ram foray frequency"
  and "Ewe foray frequency" inputs that accept any non-negative
  value. This allows users to input foray frequencies greater than one
  foray per year.
  
- Location data uploaded to the CHHR estimation tab must use a
  coordinate reference system with units of meters. The Tool now tests
  whether such data has been supplied and warns users if the supplied
  coordinates us an unaccepted CRS (e.g. WGS84 long-lat coordinates).

- All polygon features are now checked for topological validity and,
  if they are invalid (due, e.g., to self-intersection), an attempt is
  made to fix the problem. R's spatial packages apply more stringent
  topological validity standards than does ArcGIS. Fortunately, for
  all invalid polygons so far tested, the added code is able to make
  the polygons valid.

- Added missing library() calls to the "parameters.txt" files that are
  written to the directories used to archive successful CHHR
  estimation and RoC analyses. These text files had each been missing
  one or two lines loading R package required to reproduce the
  analyses.

- Upon completion of a RoC analysis, when the ram and ewe foray
  preference surfaces are added to the leaflet map, the map is now
  recentered and (if needed) resized to include the entire extents of
  the surfaces. (Previously, it was only centered to include the CHHR
  and allotments.)
