Param(
    [string]$INITDIR = "",
    [string]$FILTER = "All Files (*.*)|*.*"
    )


Add-Type -AssemblyName System.Windows.Forms
$f = new-object Windows.Forms.OpenFileDialog
$f.InitialDirectory=$INITDIR.Trim('"')
$f.Filter = $FILTER 
$f.ShowHelp = $true
$f.Multiselect = $true

## Replaced with following 4 lines, 2020-01-21.
## [void]$f.ShowDialog()
##
## Next three lines added to get file explorer to always open on top
## https://www.reddit.com/r/PowerShell/comments/6k2vbj/folderbrowserdialog_not_on_top/
$Topmost = New-Object System.Windows.Forms.Form
$Topmost.TopMost = $true
[void]$f.ShowDialog($Topmost)

if ($f.Multiselect) { $f.FileNames } else { $f.FileName }

