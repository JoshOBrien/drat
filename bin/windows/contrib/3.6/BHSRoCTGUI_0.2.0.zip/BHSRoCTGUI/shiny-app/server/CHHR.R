##---------------------------##
##  CHHR UPLOAD TAB: SERVER  ##
##---------------------------##

## Handle CHHR file type selection
observeEvent(input$CHHR_file_type, {
  toggle(id = "upload_CHHR_shp",
         condition = input$CHHR_file_type == "shp")
  toggle(id = "upload_CHHR_gdb",
         condition = input$CHHR_file_type == "gdb")
})


##------------------------------------------------------------------------------
## Shapefile layer upload
##------------------------------------------------------------------------------

observeEvent(input$upload_CHHR_shp, {
  filePath <- fileChooser(RV$POLY_search_dir)
  if (is_valid_SHP(filePath)) {
    XX <- st_read_WGS84(filePath)
    if (all(st_geometry_type(XX) %in% c("POLYGON", "MULTIPOLYGON"))) {
      RV$CHHR_is <- "SHP"
      RV$CHHR_SHP_path <- filePath
      RV$POLY_search_dir <- dirname(filePath)
      RV$CHHR <- XX
      ## Clear out GDB inputs
      RV$CHHR_GDB_path <- "~"
      RV$CHHR_GDB_layer <- ""
      RV$CHHR_GDB_path_valid <- FALSE
      OK$CHHR <- TRUE
    } else {
      msg <- "CHHR needs to be a POLYGON feature class"
      shinyalert(title = "Invalid spatial input",
                 text = msg,
                 type = "error")
    }
  }
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## GDB layer upload
##------------------------------------------------------------------------------

## GDB directory selection
observeEvent(input$select_CHHR_GDB_path, {
  filePath <- choose.dir(default = RV$POLY_search_dir,
                         caption = "Choose a directory...")
  if (is_GDB_with_polygons(filePath)) {
    RV$CHHR_GDB_path <- filePath
    RV$CHHR_GDB_path_valid <- TRUE
    RV$POLY_search_dir <- dirname(filePath)
  } else {
  }
}, ignoreInit = TRUE)
## GDB layer selection (conditional drop-down selector)
observeEvent(RV$CHHR_GDB_path, {
  toggle("select_CHHR_GDB_layer", condition = is_GDB(RV$CHHR_GDB_path))
  if (is_GDB(RV$CHHR_GDB_path)) {
    updateSelectInput(session, "select_CHHR_GDB_layer",
                      choices = poly_layer_names(RV$CHHR_GDB_path))
  }
}, ignoreInit = TRUE)
## GDB layer upload
observeEvent(input$select_CHHR_GDB_layer, {
  gdb <- RV$CHHR_GDB_path
  layerName <- input$select_CHHR_GDB_layer
  if (is_valid_GDB_layer(gdb, layerName)) {
    RV$CHHR_is <- "GDB"
    RV$CHHR_GDB_layer <- layerName
    RV$CHHR <- st_read_WGS84(gdb, layerName)
    ## Clear out SHP input
    RV$CHHR_SHP_path <- ""
    OK$CHHR <- TRUE
  }
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Report info on currently loaded layer (Shapefile or GDB)
##------------------------------------------------------------------------------

observeEvent(RV$CHHR, {
  toggle("CHHR_info", condition = RV$CHHR_is %in% c("SHP", "GDB"))
  output$CHHR_info <-
    renderPrint(spatialLayerSummary(RV, "CHHR", RV$CHHR_is))
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Conditionally hide/show check marks
##------------------------------------------------------------------------------

## Successfully selected a GDB
observeEvent({RV$CHHR_GDB_path; input$CHHR_file_type}, {
  toggle("dash_CHHR_GDB_path",
         condition = {
           !RV$CHHR_GDB_path_valid & (input$CHHR_file_type == "gdb")
         })
  toggle("check_CHHR_GDB_path",
         condition = {
           RV$CHHR_GDB_path_valid & (input$CHHR_file_type == "gdb")
         })
})

## Successfully uploaded a GDB or shapefile layer
observeEvent({RV$CHHR_is; input$CHHR_file_type; RV$CHHR_GDB_path}, {
  toggle("dash_CHHR_shp",
         condition = (RV$CHHR_is != "SHP") & (input$CHHR_file_type == "shp"))
  toggle("check_CHHR_shp",
         condition = (RV$CHHR_is == "SHP") & (input$CHHR_file_type == "shp"))
  toggle("dash_CHHR_GDB_layer",
         condition = (RV$CHHR_is != "GDB") & (input$CHHR_file_type == "gdb") &
           (RV$CHHR_GDB_path != "~"))
  toggle("check_CHHR_GDB_layer",
         condition = (RV$CHHR_is == "GDB") & (input$CHHR_file_type == "gdb"))
}, ignoreInit = TRUE)


## // Local Variables:
## // ess-indent-offset: 2
## // End:
