##-----------------------------------##
##   ALLOTMENTS UPLOAD TAB: SERVER   ##
##-----------------------------------##

## Handle allotments file type selection
output$ALLOTS_file_type_selected <- renderText(input$ALLOTS_file_type)
observeEvent(input$ALLOTS_file_type, {
  toggle(id = "upload_ALLOTS_shp",
         condition = input$ALLOTS_file_type == "shp")
  toggle(id = "upload_ALLOTS_gdb",
         condition = input$ALLOTS_file_type == "gdb")
})


##------------------------------------------------------------------------------
## Shapefile layer upload
##------------------------------------------------------------------------------

observeEvent(input$upload_ALLOTS_shp, {
  filePath <- fileChooser(RV$POLY_search_dir)
  if (is_valid_SHP(filePath)) {
    RV$ALLOTS_is <- "SHP"
    RV$ALLOTS_SHP_path <- filePath
    RV$POLY_search_dir <- dirname(filePath)
    RV$ALLOTS <- st_read_WGS84(filePath)
    RV$ALLOTS_GDB_path <- "~"
    RV$ALLOTS_GDB_layer <- ""
    RV$ALLOTS_ID_column <- ""
    OK$Allotments <- FALSE
  } else {
  }
})


##------------------------------------------------------------------------------
## GDB layer upload
##------------------------------------------------------------------------------

## GDB directory selection
observeEvent(input$select_ALLOTS_GDB_path, {
  filePath <- choose.dir(default = RV$POLY_search_dir,
                         caption = "Choose a directory...")
  if (is_GDB(filePath)) {
    RV$ALLOTS_GDB_path <- filePath
    RV$POLY_search_dir <- dirname(filePath)
  } else {
  }
})
## GDB layer selection (conditional drop-down selector)
observeEvent(RV$ALLOTS_GDB_path, {
  toggle("select_ALLOTS_GDB_layer", condition = is_GDB(RV$ALLOTS_GDB_path))
  if (is_GDB(RV$ALLOTS_GDB_path)) {
    updateSelectInput(session, "select_ALLOTS_GDB_layer",
                      choices = poly_layer_names(RV$ALLOTS_GDB_path))
  }
})
## GDB layer upload
observeEvent(input$select_ALLOTS_GDB_layer, {
  gdb <- RV$ALLOTS_GDB_path
  layerName <- input$select_ALLOTS_GDB_layer
  if (is_valid_GDB_layer(gdb, layerName)) {
    RV$ALLOTS_is <- "GDB"
    RV$ALLOTS_GDB_layer <- layerName
    RV$ALLOTS <- st_read_WGS84(gdb, layerName)
    RV$ALLOTS_SHP_path <- ""
    RV$ALLOTS_ID_column <- ""
    OK$Allotments <- FALSE
  }
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Allotment ID-column selection (both Shapefile & GDB layers)
##------------------------------------------------------------------------------

## Display Allotment ID-column selector when Allotment layer is loaded
observeEvent(RV$ALLOTS, {
  toggle("ALLOTS_ID_column", condition = is_sf(RV$ALLOTS))
  if (is_sf(RV$ALLOTS)) {
    updateSelectInput(session, "ALLOTS_ID_column",
                      choices = names(RV$ALLOTS))
  }
})
## Register choice of ID-column in RV
observeEvent(input$ALLOTS_ID_column, {
  RV$ALLOTS_ID_column <- input$ALLOTS_ID_column
  OK$Allotments <- TRUE
}, ignoreInit = TRUE)
## Hide ID-column selector when you are not on appropriate shp/gdb tab
observeEvent({RV$ALLOTS_is; input$ALLOTS_file_type}, {
  toggle("ALLOTS_ID_column", condition = {
    identical(RV$ALLOTS_is, toupper(input$ALLOTS_file_type))
  })
})


##------------------------------------------------------------------------------
## Report info on currently loaded layer (Shapefile or GDB)
##------------------------------------------------------------------------------

observeEvent(RV$ALLOTS, {
  toggle("ALLOTS_info", condition = RV$ALLOTS_is %in% c("SHP", "GDB"))
  output$ALLOTS_info <-
    renderPrint(spatialLayerSummary(RV, "ALLOTS", RV$ALLOTS_is))
}, ignoreInit = TRUE)


##------------------------------------------------------------------------------
## Conditionally hide/show check marks
##------------------------------------------------------------------------------

## Successfully uploaded a shapefile layer
observeEvent({RV$ALLOTS_is; input$ALLOTS_file_type}, {
  toggle("dash_ALLOTS_shp",
         condition = (RV$ALLOTS_is != "SHP") & (input$ALLOTS_file_type == "shp"))
  toggle("check_ALLOTS_shp",
         condition = (RV$ALLOTS_is == "SHP") & (input$ALLOTS_file_type == "shp"))
})
## Successfully selected a GDB
observeEvent({RV$ALLOTS_GDB_path; input$ALLOTS_file_type}, {
  toggle("dash_ALLOTS_GDB_path",
         condition = {
           !is_GDB(RV$ALLOTS_GDB_path) & (input$ALLOTS_file_type == "gdb")
         })
  toggle("check_ALLOTS_GDB_path",
         condition = {
           is_GDB(RV$ALLOTS_GDB_path) & (input$ALLOTS_file_type == "gdb")
         })
})
## Successfully uploaded a GDB layer
observeEvent({RV$ALLOTS_is; input$ALLOTS_file_type; RV$ALLOTS_GDB_path}, {
  toggle("dash_ALLOTS_GDB_layer",
         condition = (RV$ALLOTS_is != "GDB") & (input$ALLOTS_file_type == "gdb") &
           (RV$ALLOTS_GDB_path != "~"))
  toggle("check_ALLOTS_GDB_layer",
         condition = (RV$ALLOTS_is == "GDB") & (input$ALLOTS_file_type == "gdb"))
}, ignoreInit = TRUE)
## Successfully selected an Allotment ID column
observeEvent({RV$ALLOTS_ID_column; RV$ALLOTS_is; input$ALLOTS_file_type}, {
  toggle("dash_ALLOTS_ID_column",
         condition = {
           !nchar(RV$ALLOTS_ID_column) &
             identical(RV$ALLOTS_is, toupper(input$ALLOTS_file_type))
         })
  toggle("check_ALLOTS_ID_column",
         condition = {
           nchar(RV$ALLOTS_ID_column) &
             identical(RV$ALLOTS_is, toupper(input$ALLOTS_file_type))
         })
})



## // Local Variables:
## // ess-indent-offset: 2
## // End:
