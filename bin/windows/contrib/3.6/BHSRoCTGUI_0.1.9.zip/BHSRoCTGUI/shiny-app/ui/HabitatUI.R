##---------------------##
## HABITAT UPLOAD TAB  ##
##---------------------##
tabPanel("Habitat",
  useShinyjs(),
  useShinyalert(),
  fluidPage(
    br(), br(), br(),
    ## Habitat GeoTiff upload
    fluidRowWidgetCheck(
      actionButton("upload_HAB_tif",
                   "Upload habitat raster GeoTiff",
                          width = "100%"),
      span(greyDash("dash_HAB_tif"),
           greenCheck("check_HAB_tif"))
    ),

    ## Display info about loaded Habitat
    fluidRow(
      br(),
      column(12, align = "center",
        div(align = "left", verbatimTextOutput("HAB_info"))
        )
    ),

    hr(),

    hidden(div(id = "set_hab_prefs",
    fluidRow(
      column(4,
        radioButtons(
          "HAB_raster_type", "Habitat raster pixel values represent:",
          choiceValues = c("class_file", "class_interactive", "preference"),
          choiceNames =
            list(HTML("Habitat <B>classes</B>, with class preferences from a CSV file"),
                 HTML("Habitat <B>classes</B>, with class preferences entered interactively"),
                 HTML("Habitat <B>preferences</B>")),
          selected = character(0))),
      column(5,
             br(), br(),
             ## (CASE 1) Offer to habitat preferences file
             hidden(actionButton("upload_HAB_pref_csv",
                                 "Upload habitat preference file",
                                 width = "100%")),
             ## (CASE 2) Render hab pref handsontable
             rHandsontableOutput("hot_HAB_pref")),
      column(1,
             span(greyDash("dash_HAB_pref", yShift = -40),
                  greenCheck("check_HAB_pref", yShift = -40))),
      column(2)
    )
    )),

    br()
  ))


## // Local Variables:
## // ess-indent-offset: 2
## // End:
