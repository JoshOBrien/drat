library(shinyjs)
library(shiny)
library(shinyFiles) ## shinyFileChoose, shinyFilesButton, parseFilePaths
library(shinyWidgets)
library(exiftoolr)
library(stringi)
library(fs)

server <- function(input, output, session) {

    RV <- reactiveValues(out_path = NULL)

    volumes <- c("Desktop" = path(path_home(), "Desktop"),
                 "Home" = path_home(),
                 "C:/" = "C:")
    shinyFileChoose(input,
                    id = "file_selection",
                    roots = volumes,
                    session = session,
                    defaultRoot = "Desktop",
                    filetypes = c("JPG", "jpg", "JPEG", "jpeg"))

    ##---------------------------------------------------------##
    ## (0) Prepare box with printed version of selected files. ##
    ##---------------------------------------------------------##
    output$imagefile_paths <- renderPrint({
        ## data.frame w/ columns: "name", "size", "type", & "datapath"
        files <- data.frame(parseFilePaths(roots = volumes,
                                           input$file_selection))
        ii <- grep("_ann\\.", as.character(files$datapath), invert = TRUE)
        files <- files[ii, ]
        if(nrow(files)) {
            ## files <- files[, c("datapath", "name")]
            files <- files["datapath"]
            colnames(files) <- "file_paths"
            {
                write.table(files, col.names = FALSE, row.names = FALSE)
            }
        } else {
            "No files selected"
        }
    })

    ##----------------------------------------------------------##
    ## (1a) Conditionally Show/Hide output file selection panel ##
    ##----------------------------------------------------------##
    observeEvent(input$file_selection,
    {
        files <- data.frame(parseFilePaths(roots = volumes,
                                           input$file_selection))
        ii <- grep("_ann\\.", as.character(files$datapath), invert = TRUE)
        files <- files[ii, ]
        if(nrow(files)) {
            show("outfileSelection")
            show("selectedFileDisplay")
        } else {
            hide("outfileSelection")
            hide("selectedFileDisplay")
        }
    })
    ##----------------------------------------------------------##
    ## (1a) Conditionally show/hide coordinate extraction panel ##
    ##----------------------------------------------------------##
    observeEvent({RV$out_path; input$file_selection},
    {
        files <- data.frame(parseFilePaths(roots = volumes,
                                           input$file_selection))
        ii <- grep("_ann\\.", as.character(files$datapath), invert = TRUE)
        files <- files[ii, ]
        if(!is.null(RV$out_path) & nrow(files)) {
            show("coordinateExtraction")
        } else {
            hide("coordinateExtraction")
        }
    })

    ##-----------------------------------------------------##
    ## (2) Select path to output file.                     ##
    ##-----------------------------------------------------##
    observeEvent(input$save,
    {
      vols <- c("Desktop" = path(path_home(), "Desktop"),
                "Home" = path_home(),
                "C:/" = "C:")
      shinyFileSave(input,
                    id = "save",
                    roots = vols,
                    session = session,
                    defaultRoot = "Desktop")
      fileinfo <- parseSavePath(vols, input$save)
      if (nrow(fileinfo) > 0) {
          RV$out_path <- as.character(fileinfo[["datapath"]])
          output$outfile_path <- renderPrint(RV$out_path)
      }
    })

    ##-------------------------------------##
    ## (3) Extract coords on button click. ##
    ##-------------------------------------##
    observeEvent(input$do_extract,
    {
        ## Read meta info from selected files
        files <- parseFilePaths(roots = volumes, input$file_selection)
        image_files <- as.character(files$datapath)
        exifinfo <- exif_read(image_files)

        ## Process selected meta info tags for output
        exif_tags <- c("SourceFile", "GPSLatitude",
                       "GPSLongitude", "UserComment")
        res <- exifinfo[exif_tags]
        x <- split_UserComment(res[["UserComment"]])
        res[["UserComment"]] <- NULL
        res <- cbind(res, x)
        res[["SourceFile"]] <- basename(res[["SourceFile"]])
        write.csv(res, RV$out_path, row.names = FALSE)

        ## Inform user of sucesss
        sendSweetAlert(
            session = session,
            title = sprintf("Coordinates written to file '%s'.", RV$out_path),
            type = "success")

    })
}


