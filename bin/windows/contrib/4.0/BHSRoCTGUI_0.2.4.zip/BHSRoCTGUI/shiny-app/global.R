library(curl)     ## has_internet()
