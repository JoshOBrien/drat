##-----------------------##
##  CHHR UPLOAD TAB: UI  ##
##-----------------------##
tabPanel("1. Load CHHR",
  useShinyjs(),
  useShinyalert(),
  fluidPage(theme = "radioButtonBoxes.css",
    fluidRow(
      column(1),
      column(10, align = "center",
        ## ## Application title
        ## titlePanel("CHHR Input"),

        ## CHHR file type selection
        radioButtonBoxes(inputId = "CHHR_file_type", label = "",
                         choices = c("CHHR from shapefile" = "shp",
                                     "CHHR from GDB" = "gdb"),
                         selected = character(0))
        ),
      column(1),
      br(), br(), br()
    ),
    ## CHHR shapefile upload
    fluidRowWidgetCheck(
      hidden(actionButton("upload_CHHR_shp",
                          "Upload CHHR shapefile",
                          width = "100%")),
      span(greyDash("dash_CHHR_shp"),
           greenCheck("check_CHHR_shp"))
    ),


    hidden(div(id = "upload_CHHR_gdb",
      ## CHHR GDB directory selection
      fluidRowWidgetCheck(
        actionButton("select_CHHR_GDB_path",
                     "Select GDB containing CHHR feature class",
                     width = "100%"),
        span(greyDash("dash_CHHR_GDB_path"),
             greenCheck("check_CHHR_GDB_path"))
      ),
      ## CHHR GDB layer selection
      fluidRowWidgetCheck(
        selectizeInput("select_CHHR_GDB_layer", label = "",
                       choices = "", selected = "",
                       options = list(
                         placeholder = "Select CHHR feature class",
                         onInitialize=I('function() { this.setValue(""); }')),
                       width = "100%"),
        span(greyDash("dash_CHHR_GDB_layer", yShift = -12),
             greenCheck("check_CHHR_GDB_layer", yShift = -12))
      ))),
    ## Display info about loaded CHHR
    fluidRow(
      br(),
      column(12, align = "center",
        div(align = "left", verbatimTextOutput("CHHR_info"))
        )
    )
    ))


## // Local Variables:
## // ess-indent-offset: 2
## // End:
