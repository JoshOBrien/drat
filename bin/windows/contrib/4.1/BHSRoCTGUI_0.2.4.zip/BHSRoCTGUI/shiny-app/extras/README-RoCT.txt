This directory contains the data and parameters used in the Risk of
Contact analysis whose results are stored in its parent directory,
along with an R script that may be used to reproduce the analysis. In
addition to this "README.txt" file, the directory contains:

- Two *.gpkg files that contain the CHHR and allotments vector layers.

- A *.tiff file containing the habitat raster layer.

- Three *.csv files that store the foray distance distribution and
  habitat preference tables.

- A "parameters.txt" file that records all additional input parameters
  using the human-readable YAML data-serialization format.

- "runscript.R", an R script that may be used to reproduce the
  archived analysis, when executed from the directory containing this
  file.

